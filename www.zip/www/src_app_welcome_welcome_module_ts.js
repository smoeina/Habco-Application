(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_welcome_welcome_module_ts"],{

/***/ 9241:
/*!***************************************************!*\
  !*** ./src/app/welcome/welcome-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WelcomePageRoutingModule": () => (/* binding */ WelcomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _welcome_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./welcome.page */ 3297);




const routes = [
    {
        path: '',
        component: _welcome_page__WEBPACK_IMPORTED_MODULE_0__.WelcomePage
    }
];
let WelcomePageRoutingModule = class WelcomePageRoutingModule {
};
WelcomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], WelcomePageRoutingModule);



/***/ }),

/***/ 2526:
/*!*******************************************!*\
  !*** ./src/app/welcome/welcome.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WelcomePageModule": () => (/* binding */ WelcomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _welcome_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./welcome-routing.module */ 9241);
/* harmony import */ var _welcome_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./welcome.page */ 3297);







let WelcomePageModule = class WelcomePageModule {
};
WelcomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _welcome_routing_module__WEBPACK_IMPORTED_MODULE_0__.WelcomePageRoutingModule
        ],
        declarations: [_welcome_page__WEBPACK_IMPORTED_MODULE_1__.WelcomePage]
    })
], WelcomePageModule);



/***/ }),

/***/ 3297:
/*!*****************************************!*\
  !*** ./src/app/welcome/welcome.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WelcomePage": () => (/* binding */ WelcomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_welcome_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./welcome.page.html */ 2553);
/* harmony import */ var _welcome_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./welcome.page.scss */ 2447);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);





let WelcomePage = class WelcomePage {
    constructor(router) {
        this.router = router;
        this.viewEntered = false;
        this.sliderOpts = null;
    }
    ionViewDidEnter() {
        this.viewEntered = true;
    }
    ngOnInit() {
        this.sliderOpts = {
            effect: 'slide',
            initialSlide: 0,
        };
    }
    clickLoginButton() {
        this.router.navigate(['login']);
    }
};
WelcomePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
WelcomePage.propDecorators = {
    slider: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewChild, args: ['slider',] }]
};
WelcomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-welcome',
        template: _raw_loader_welcome_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_welcome_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], WelcomePage);



/***/ }),

/***/ 2447:
/*!*******************************************!*\
  !*** ./src/app/welcome/welcome.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".heading {\n  text-align: center;\n}\n\nh1, h2 {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 25px;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 25px;\n}\n\nion-button {\n  font-family: \"PlusJakarta-bold\";\n  position: relative;\n  margin-left: 20%;\n  width: 60%;\n  height: 50px;\n  margin-right: 20%;\n}\n\np {\n  margin: 0 10% 0 10%;\n}\n\n.footer {\n  margin: 5px 0 0 0;\n  text-align: center;\n}\n\nion-slides {\n  margin-top: 10%;\n  --bullet-background: red;\n  height: 60%;\n  margin-bottom: 10%;\n  padding-bottom: 30px;\n}\n\nimg {\n  height: 170px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlbGNvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0Usa0JBQUE7QUFBRjs7QUFJQTtFQUNFLHdDQUFBO0VBQ0EsZUFBQTtBQURGOztBQUdBO0VBQ0UsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGdCQUFBO0FBQUY7O0FBSUE7RUFDRSwrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0QsWUFBQTtFQUNDLGlCQUFBO0FBREY7O0FBR0E7RUFDRSxtQkFBQTtBQUFGOztBQUVBO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUNBO0VBQ0UsZUFBQTtFQUNBLHdCQUFBO0VBQ0EsV0FBQTtFQUNGLGtCQUFBO0VBQ0Esb0JBQUE7QUFFQTs7QUFBRTtFQUVFLGFBQUE7QUFFSiIsImZpbGUiOiJ3ZWxjb21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uaGVhZGluZ3tcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG5cclxufVxyXG5oMSxoMntcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhLWJvbGQnLCBjdXJzaXZlO1xyXG4gIGZvbnQtc2l6ZTogMjVweDtcclxufVxyXG5we1xyXG4gIGNvbG9yOiAjODY4Njg2ZGM7XHJcbiAgZm9udC1mYW1pbHk6ICdRYW5lbGFzVWx0cmFMaWdodCc7XHJcbiAgbWFyZ2luLXRvcDogMjVweDtcclxufVxyXG5cclxuXHJcbmlvbi1idXR0b257XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBtYXJnaW4tbGVmdDogMjAlO1xyXG4gIHdpZHRoOiA2MCU7XHJcblx0aGVpZ2h0OiA1MHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMjAlO1xyXG59XHJcbnB7XHJcbiAgbWFyZ2luOiAwIDEwJSAwIDEwJTtcclxufVxyXG4uZm9vdGVye1xyXG4gIG1hcmdpbjo1cHggMCAwIDA7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbmlvbi1zbGlkZXMge1xyXG4gIG1hcmdpbi10b3A6IDEwJTtcclxuICAtLWJ1bGxldC1iYWNrZ3JvdW5kOiByZWQ7XHJcbiAgaGVpZ2h0OiA2MCU7XHJcbm1hcmdpbi1ib3R0b206IDEwJTtcclxucGFkZGluZy1ib3R0b206IDMwcHg7fVxyXG5cclxuICBpbWd7XHJcblxyXG4gICAgaGVpZ2h0OjE3MHB4O1xyXG4gIH1cclxuXHJcblxyXG4iXX0= */");

/***/ }),

/***/ 2553:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/welcome/welcome.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\r\n<ion-content>\r\n\r\n  <ion-slides mode=\"md\" pager=\"true\"  *ngIf=\"viewEntered\" [options]=\"sliderOpts\"  #slider>\r\n\r\n\r\n    <ion-slide>\r\n      <div class=\"center\" style=\"clear:both;display: block; width: 100%;\">\r\n        <div style=\"text-align: center;\">\r\n      <table style=\"width: 100%;\">\r\n\r\n        <tr>\r\n          <td>\r\n            <div style=\"text-align: center;\">\r\n            <img class=\"slider-image\" src=\"/assets/Welcome-Page-Slider-1.png\" />\r\n            </div>\r\n          </td>\r\n        </tr>\r\n        <tr>\r\n          <td class=\"green\">\r\n            <div style=\"text-align: center; margin-top: 10%;\">\r\n            <h2>     What is the Habco?</h2>\r\n            <p><b>Habco</b> is an application for improving social healthcare</p>\r\n            </div>\r\n          </td>\r\n        </tr>\r\n\r\n      </table>\r\n        </div>\r\n    </div>\r\n    </ion-slide>\r\n\r\n\r\n    <ion-slide>\r\n      <div class=\"center\" style=\"clear:both;display: block; width: 100%;\">\r\n        <div style=\"text-align: center;\">\r\n      <table style=\"width: 100%;\">\r\n\r\n        <tr>\r\n          <td>\r\n            <div style=\"text-align: center;\">\r\n            <img class=\"slider-image\" src=\"/assets/Welcome-Page-Slider-2.png\" />\r\n            </div>\r\n          </td>\r\n        </tr>\r\n        <tr>\r\n          <td class=\"green\">\r\n            <div style=\"text-align: center; margin-top: 10%;\">\r\n            <h2>What does habco do?</h2>\r\n            <p><b>Habco</b> connects doctors, nurses and drug Stores for <b>you.</b></p>\r\n            </div>\r\n          </td>\r\n        </tr>\r\n\r\n      </table>\r\n        </div>\r\n    </div>\r\n    </ion-slide>\r\n    <ion-slide>\r\n      <div class=\"center\" style=\"clear:both;display: block; width: 100%;\">\r\n        <div style=\"text-align: center;\">\r\n      <table style=\"width: 100%;\">\r\n\r\n        <tr>\r\n          <td>\r\n            <div style=\"text-align: center;\">\r\n            <img class=\"slider-image\" src=\"/assets/welcome-3.png\" />\r\n            </div>\r\n          </td>\r\n        </tr>\r\n        <tr>\r\n          <td class=\"green\">\r\n            <div style=\"text-align: center; margin-top: 10%;\">\r\n            <h2>Why should I use Habco?</h2>\r\n            <p><b>Habco</b> respects your time.</p>\r\n            </div>\r\n          </td>\r\n        </tr>\r\n\r\n      </table>\r\n        </div>\r\n    </div>\r\n    </ion-slide>\r\n\r\n  </ion-slides>\r\n\r\n\r\n\r\n\r\n\r\n\r\n  <ion-button shape=\"round\" expand=\"block\" fill=\"solid\" routerLink=\"../register\" >\r\n    Get Started\r\n  </ion-button>\r\n<!--\r\n  <div class=\"footer\">\r\n    <p>Already have account? <a (click)=\"clickLoginButton()\">Login</a></p>\r\n  </div> -->\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_welcome_welcome_module_ts.js.map