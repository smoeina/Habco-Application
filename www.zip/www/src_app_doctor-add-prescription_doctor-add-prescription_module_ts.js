(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_doctor-add-prescription_doctor-add-prescription_module_ts"],{

/***/ 3096:
/*!***********************************************************************************!*\
  !*** ./src/app/doctor-add-prescription/doctor-add-prescription-routing.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DoctorAddPrescriptionPageRoutingModule": () => (/* binding */ DoctorAddPrescriptionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _doctor_add_prescription_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./doctor-add-prescription.page */ 7098);




const routes = [
    {
        path: '',
        component: _doctor_add_prescription_page__WEBPACK_IMPORTED_MODULE_0__.DoctorAddPrescriptionPage
    }
];
let DoctorAddPrescriptionPageRoutingModule = class DoctorAddPrescriptionPageRoutingModule {
};
DoctorAddPrescriptionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DoctorAddPrescriptionPageRoutingModule);



/***/ }),

/***/ 741:
/*!***************************************************************************!*\
  !*** ./src/app/doctor-add-prescription/doctor-add-prescription.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DoctorAddPrescriptionPageModule": () => (/* binding */ DoctorAddPrescriptionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _doctor_add_prescription_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./doctor-add-prescription-routing.module */ 3096);
/* harmony import */ var _doctor_add_prescription_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./doctor-add-prescription.page */ 7098);







let DoctorAddPrescriptionPageModule = class DoctorAddPrescriptionPageModule {
};
DoctorAddPrescriptionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _doctor_add_prescription_routing_module__WEBPACK_IMPORTED_MODULE_0__.DoctorAddPrescriptionPageRoutingModule
        ],
        declarations: [_doctor_add_prescription_page__WEBPACK_IMPORTED_MODULE_1__.DoctorAddPrescriptionPage]
    })
], DoctorAddPrescriptionPageModule);



/***/ }),

/***/ 7098:
/*!*************************************************************************!*\
  !*** ./src/app/doctor-add-prescription/doctor-add-prescription.page.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DoctorAddPrescriptionPage": () => (/* binding */ DoctorAddPrescriptionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_doctor_add_prescription_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./doctor-add-prescription.page.html */ 4551);
/* harmony import */ var _doctor_add_prescription_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./doctor-add-prescription.page.scss */ 2837);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../error-controller.service */ 4898);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _doctor_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../doctor-service.service */ 5268);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);




/* eslint-disable object-shorthand */
/* eslint-disable @typescript-eslint/dot-notation */

/* eslint-disable @typescript-eslint/prefer-for-of */
/* eslint-disable @typescript-eslint/naming-convention */




let DoctorAddPrescriptionPage = class DoctorAddPrescriptionPage {
    constructor(doctorService, http, ErrorCont, loadingController) {
        this.doctorService = doctorService;
        this.http = http;
        this.ErrorCont = ErrorCont;
        this.loadingController = loadingController;
        this.patient_names_ids = {};
        this.app_token = '';
        this.prescription = '';
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.app_token = localStorage.getItem('app-token');
        for (let i = 0; i < this.doctorService.patients_list.length; i++) {
            this.patient_names_ids[this.doctorService.patients_list[i].user.fname.toString() + ' ' +
                this.doctorService.patients_list[i].user.lname.toString()] = this.doctorService.patients_list[i].id;
        }
    }
    // http://localhost:8000/habco/prescription/patient/26
    submit_prescription() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers: headers };
            console.log(this.selected_patient.value);
            loading.present();
            this.http.post('https://habco.rshayanfar.ir/habco/prescription/patient' + this.selected_patient.value, { text: this.prescription_field.value }, options).toPromise().then(resp => {
                console.log(resp);
            }).catch(error => {
                console.log('Error');
                this.ErrorCont.showError(error);
                loading.dismiss();
            });
        });
    }
};
DoctorAddPrescriptionPage.ctorParameters = () => [
    { type: _doctor_service_service__WEBPACK_IMPORTED_MODULE_3__.DoctorServiceService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController }
];
DoctorAddPrescriptionPage.propDecorators = {
    selected_patient: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['selected_patient',] }],
    prescription_field: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['prescription',] }]
};
DoctorAddPrescriptionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-doctor-add-prescription',
        template: _raw_loader_doctor_add_prescription_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_doctor_add_prescription_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DoctorAddPrescriptionPage);



/***/ }),

/***/ 2837:
/*!***************************************************************************!*\
  !*** ./src/app/doctor-add-prescription/doctor-add-prescription.page.scss ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-textarea {\n  font-family: \"HelloKetta\";\n  font-size: 30px;\n}\n\nion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 16px;\n}\n\nion-card {\n  margin-top: 20%;\n  font-family: \"Gilroy\", cursive;\n}\n\nion-button {\n  margin-left: 30%;\n  margin-right: 30%;\n  width: 40%;\n  font-family: \"Gilroy-bold\", cursive;\n}\n\nion-card-subtitle {\n  font-family: \"Gilroy-bold\";\n}\n\nion-select-option {\n  font-family: \"Gilroy\";\n}\n\nion-select {\n  font-family: \"Gilroy\";\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRvY3Rvci1hZGQtcHJlc2NyaXB0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLHlCQUFBO0VBQ0EsZUFBQTtBQUFGOztBQUVBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxlQUFBO0VBQ0EsOEJBQUE7QUFFRjs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0VBQ0EsbUNBQUE7QUFFRjs7QUFDQTtFQUNFLDBCQUFBO0FBRUY7O0FBQ0E7RUFDRSxxQkFBQTtBQUVGOztBQUNBO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0FBRUYiLCJmaWxlIjoiZG9jdG9yLWFkZC1wcmVzY3JpcHRpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmlvbi10ZXh0YXJlYXtcclxuICBmb250LWZhbWlseTogJ0hlbGxvS2V0dGEnO1xyXG4gIGZvbnQtc2l6ZTozMHB4O1xyXG59XHJcbmlvbi10aXRsZXtcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhLWJvbGQnLCBjdXJzaXZlO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG5pb24tY2FyZHtcclxuICBtYXJnaW4tdG9wOiAyMCU7XHJcbiAgZm9udC1mYW1pbHk6ICdHaWxyb3knLCBjdXJzaXZlO1xyXG5cclxufVxyXG5pb24tYnV0dG9ue1xyXG4gIG1hcmdpbi1sZWZ0OiAzMCU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAzMCU7XHJcbiAgd2lkdGg6IDQwJTtcclxuICBmb250LWZhbWlseTogJ0dpbHJveS1ib2xkJywgY3Vyc2l2ZTtcclxuXHJcbn1cclxuaW9uLWNhcmQtc3VidGl0bGV7XHJcbiAgZm9udC1mYW1pbHk6ICdHaWxyb3ktYm9sZCc7XHJcblxyXG59XHJcbmlvbi1zZWxlY3Qtb3B0aW9ue1xyXG4gIGZvbnQtZmFtaWx5OiAnR2lscm95JztcclxuXHJcbn1cclxuaW9uLXNlbGVjdHtcclxuICBmb250LWZhbWlseTogJ0dpbHJveSc7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 4551:
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/doctor-add-prescription/doctor-add-prescription.page.html ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"doctor-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Add new prescription</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n\n  <div *ngFor=\"let item of patient_names_ids | keyvalue\">\n\n\n  </div>\n  <ion-card>\n    <ion-card-header>\n      <ion-card-subtitle>Patient:\n        <ion-item>\n          <ion-select #selected_patient  multiple=\"false\" placeholder=\"Select Patient\"\n          *ngFor=\"let item of patient_names_ids | keyvalue\" >\n            <ion-select-option value=\"{{item.value}}\">{{item.key}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-card-subtitle>\n    </ion-card-header>\n\n    <ion-card-content>\n      <ion-card-subtitle>Text:</ion-card-subtitle>\n      <ion-textarea #prescription placeholder=\"      You should care yourself...\">\n      </ion-textarea>\n      <ion-button (click)=\"submit_prescription()\">\n        <ion-icon slot=\"icon-only\" name=\"add-circle\"></ion-icon>\n        Submit\n      </ion-button>\n    </ion-card-content>\n  </ion-card>\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_doctor-add-prescription_doctor-add-prescription_module_ts.js.map