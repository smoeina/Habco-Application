(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_nurse-upload-page_nurse-upload-page_module_ts"],{

/***/ 6191:
/*!***********************************************************************!*\
  !*** ./src/app/nurse-upload-page/nurse-upload-page-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NurseUploadPagePageRoutingModule": () => (/* binding */ NurseUploadPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _nurse_upload_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nurse-upload-page.page */ 6496);




const routes = [
    {
        path: '',
        component: _nurse_upload_page_page__WEBPACK_IMPORTED_MODULE_0__.NurseUploadPagePage
    }
];
let NurseUploadPagePageRoutingModule = class NurseUploadPagePageRoutingModule {
};
NurseUploadPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NurseUploadPagePageRoutingModule);



/***/ }),

/***/ 4672:
/*!***************************************************************!*\
  !*** ./src/app/nurse-upload-page/nurse-upload-page.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NurseUploadPagePageModule": () => (/* binding */ NurseUploadPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _nurse_upload_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nurse-upload-page-routing.module */ 6191);
/* harmony import */ var _nurse_upload_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nurse-upload-page.page */ 6496);







let NurseUploadPagePageModule = class NurseUploadPagePageModule {
};
NurseUploadPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _nurse_upload_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.NurseUploadPagePageRoutingModule
        ],
        declarations: [_nurse_upload_page_page__WEBPACK_IMPORTED_MODULE_1__.NurseUploadPagePage]
    })
], NurseUploadPagePageModule);



/***/ }),

/***/ 6496:
/*!*************************************************************!*\
  !*** ./src/app/nurse-upload-page/nurse-upload-page.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NurseUploadPagePage": () => (/* binding */ NurseUploadPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_nurse_upload_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./nurse-upload-page.page.html */ 7218);
/* harmony import */ var _nurse_upload_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nurse-upload-page.page.scss */ 2100);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../error-controller.service */ 4898);



/* eslint-disable @typescript-eslint/naming-convention */






let NurseUploadPagePage = class NurseUploadPagePage {
    constructor(http, error_controller, alertController, router, loadingController) {
        this.http = http;
        this.error_controller = error_controller;
        this.alertController = alertController;
        this.router = router;
        this.loadingController = loadingController;
        this.app_token = '';
        this.cv_uploaded = false;
        this.certification_uploaded = false;
    }
    ngOnInit() {
        this.app_token = localStorage.getItem('app-token');
    }
    cv_file_changed(fileChangeEvent) {
        this.cv_file = fileChangeEvent.target.files[0];
        console.log('File Loaded');
        const fileReader = new FileReader();
        fileReader.readAsDataURL(this.cv_file);
        fileReader.onload = () => {
            console.log(fileReader.result);
            this.cv_base64 = fileReader.result;
        };
        this.cv_uploaded = true;
    }
    certification_file_changed(fileChangeEvent) {
        this.certification_file = fileChangeEvent.target.files[0];
        console.log('File Loaded');
        const fileReader = new FileReader();
        fileReader.readAsDataURL(this.certification_file);
        fileReader.onload = () => {
            console.log(fileReader.result);
            this.certification_base64 = fileReader.result;
        };
        this.certification_uploaded = true;
    }
    showAlert(header, subHeader, message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header,
                cssClass: 'my-custom-class',
                subHeader,
                message,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    upload_clicked() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            console.log(this.terms);
            if (this.terms.checked === false) {
                this.error_controller.showError('Please Accept our terms...');
                return 0;
            }
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers };
            if (this.certification_uploaded && this.cv_uploaded) {
                this.http.post('https://habco.rshayanfar.ir/habco/document', { file: this.cv_base64.split(',')[1], file_type: 'application/pdf', type: 'cv' }, options).toPromise().then(resp => {
                    console.log(resp);
                }).catch(error => {
                    console.log('Error');
                    loading.dismiss();
                    this.error_controller.showError(error);
                });
                ;
                this.http.post('https://habco.rshayanfar.ir/habco/document', { file: this.certification_base64.split(',')[1], file_type: 'application/pdf', type: 'document' }, options).toPromise().then(resp => {
                    console.log(resp);
                }).catch(error => {
                    console.log('Error');
                    loading.dismiss();
                    this.error_controller.showError(error);
                });
                ;
                this.http.patch('https://habco.rshayanfar.ir/habco/user', { fname: this.fname.value,
                    lname: this.lname.value }, options).toPromise().then(resp => {
                    console.log(resp);
                }).catch(error => {
                    loading.dismiss();
                    this.error_controller.showError(error);
                });
                console.log(this.proficiency.value);
                this.http.put('https://habco.rshayanfar.ir/habco/nurse', { specialization: this.proficiency.value }, options).toPromise().then(resp => {
                    console.log(resp);
                    loading.dismiss();
                    this.showAlert('Done', 'Upload Information Success', 'Wait till our supervisors check your info.');
                    this.router.navigate(['nurse-home-page']);
                }).catch(error => {
                    loading.dismiss();
                    this.error_controller.showError(error);
                });
            }
            else {
                loading.dismiss();
                this.error_controller.showErrorMessage('Please Upload your CV and Certification file...');
            }
            loading.dismiss();
        });
    }
};
NurseUploadPagePage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController }
];
NurseUploadPagePage.propDecorators = {
    cv: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['cv',] }],
    fname: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['fname',] }],
    lname: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['lname',] }],
    proficiency: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['proficiency',] }],
    terms: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['terms',] }]
};
NurseUploadPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-nurse-upload-page',
        template: _raw_loader_nurse_upload_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_nurse_upload_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], NurseUploadPagePage);



/***/ }),

/***/ 2100:
/*!***************************************************************!*\
  !*** ./src/app/nurse-upload-page/nurse-upload-page.page.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-title {\n  font-family: PlusJakarta-bold;\n  font-size: 15px;\n}\n\nion-input {\n  font-family: \"QanelasUltraLight\";\n  font-size: 15px;\n}\n\n.inputs_devision {\n  margin-top: 10%;\n}\n\nion-item {\n  font-family: PlusJakarta-bold;\n  --border-width: 2px;\n  --border-radius: 8px;\n  width: 80%;\n  position: relative;\n  margin-left: 10%;\n  margin-right: 10%;\n  margin-top: 4px;\n}\n\n.Quest {\n  font-size: 11px;\n  margin-bottom: 5%;\n}\n\nion-button {\n  font-family: \"PlusJakarta-bold\";\n  position: relative;\n  margin-left: 25%;\n  width: 50%;\n  height: 50px;\n  margin-right: 25%;\n  margin-top: 5%;\n  margin-bottom: 15%;\n  border-radius: 15%;\n}\n\n.accept_terms {\n  font-family: QanelasUltraLight;\n  font-size: 16px;\n  margin-left: 5%;\n}\n\np {\n  display: inline-block;\n  margin-left: 4px;\n}\n\nion-checkbox {\n  margin-top: 4px;\n}\n\nion-label {\n  font-size: 10px;\n  font-family: QanelasUltraLight;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51cnNlLXVwbG9hZC1wYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDZCQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUVBO0VBQ0UsZ0NBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0FBQ0Y7O0FBQ0E7RUFDRSw2QkFBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQUVGOztBQUFBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBR0Y7O0FBREE7RUFDRSwrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0QsWUFBQTtFQUNDLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFJRjs7QUFGQTtFQUNFLDhCQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUFLRjs7QUFIQTtFQUNFLHFCQUFBO0VBQ0EsZ0JBQUE7QUFNRjs7QUFKQTtFQUNFLGVBQUE7QUFPRjs7QUFMQTtFQUNFLGVBQUE7RUFDQSw4QkFBQTtBQVFGIiwiZmlsZSI6Im51cnNlLXVwbG9hZC1wYWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10aXRsZXtcclxuICBmb250LWZhbWlseTogUGx1c0pha2FydGEtYm9sZDtcclxuICBmb250LXNpemU6IDE1cHg7XHJcblxyXG59XHJcbmlvbi1pbnB1dHtcclxuICBmb250LWZhbWlseTogXCJRYW5lbGFzVWx0cmFMaWdodFwiO1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxuXHJcbn1cclxuLmlucHV0c19kZXZpc2lvbntcclxuICBtYXJnaW4tdG9wOiAxMCU7XHJcbn1cclxuaW9uLWl0ZW17XHJcbiAgZm9udC1mYW1pbHk6UGx1c0pha2FydGEtYm9sZDtcclxuICAtLWJvcmRlci13aWR0aDogMnB4O1xyXG4gIC0tYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gIHdpZHRoOiA4MCU7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG1hcmdpbi1sZWZ0OiAxMCU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMCU7XHJcbiAgbWFyZ2luLXRvcDogNHB4O1xyXG59XHJcbi5RdWVzdHtcclxuICBmb250LXNpemU6IDExcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogNSU7XHJcbn1cclxuaW9uLWJ1dHRvbntcclxuICBmb250LWZhbWlseTogXCJQbHVzSmFrYXJ0YS1ib2xkXCI7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG1hcmdpbi1sZWZ0OiAyNSU7XHJcbiAgd2lkdGg6IDUwJTtcclxuXHRoZWlnaHQ6IDUwcHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyNSU7XHJcbiAgbWFyZ2luLXRvcDogNSU7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTUlO1xyXG4gIGJvcmRlci1yYWRpdXM6IDE1JTtcclxufVxyXG4uYWNjZXB0X3Rlcm1ze1xyXG4gIGZvbnQtZmFtaWx5OlFhbmVsYXNVbHRyYUxpZ2h0IDtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDUlO1xyXG59XHJcbnB7XHJcbiAgZGlzcGxheTppbmxpbmUtYmxvY2s7XHJcbiAgbWFyZ2luLWxlZnQ6IDRweDtcclxufVxyXG5pb24tY2hlY2tib3h7XHJcbiAgbWFyZ2luLXRvcDogNHB4O1xyXG59XHJcbmlvbi1sYWJlbHtcclxuICBmb250LXNpemU6IDEwcHg7XHJcbiAgZm9udC1mYW1pbHk6UWFuZWxhc1VsdHJhTGlnaHQ7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 7218:
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/nurse-upload-page/nurse-upload-page.page.html ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"nurse-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Personal Information</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"inputs_devision\">\n    <ion-title class=\"Quest\">Please complete your personal information.</ion-title>\n<ion-item>\n    <ion-label position='floating'>\n      <ion-icon name=\"person\"></ion-icon>\n      First Name</ion-label>\n    <ion-input type=\"text\" placeholder=\"John\" #fname></ion-input>\n</ion-item>\n<ion-item>\n  <ion-label position='floating'>\n    <ion-icon name=\"person\"></ion-icon>\n    Last Name</ion-label>\n  <ion-input type=\"text\" placeholder=\"Hopkins\"  #lname></ion-input>\n</ion-item>\n<ion-item>\n  <ion-label position='floating'>\n    <ion-icon name=\"library\"></ion-icon>\n    Your Proficiency:</ion-label>\n  <ion-input type=\"text\" placeholder=\"Expert Nurse\"  #proficiency></ion-input>\n</ion-item>\n\n<ion-item>\n  <ion-label position='floating'>\n    <ion-icon name=\"library\"></ion-icon>\n    Upload Your CV</ion-label>\n  <ion-input accept=\"application/pdf\" type=\"file\" placeholder=\"CV\" #cv (change)=\"cv_file_changed($event)\"></ion-input>\n</ion-item>\n<ion-item>\n  <ion-label position='floating'>\n    <ion-icon name=\"ribbon\"></ion-icon>\n    Upload your Certification:</ion-label>\n  <ion-input accept=\"application/pdf\" type=\"file\" placeholder=\"Certification\" #certification (change)=\"certification_file_changed($event)\"></ion-input>\n</ion-item>\n<div class=\"accept_terms\">\n  <ion-checkbox color=\"primary\" #terms></ion-checkbox>\n  <p>I agree to the terms of service</p>\n\n  <span style=\"color: rgb(221, 16, 16);visibility: hidden;\">Please accept terms of the service</span>\n\n</div>\n\n<div style=\"margin-top: 10%;\">\n  <ion-button (click)=\"upload_clicked()\">\n    Upload\n  </ion-button>\n</div>\n\n  </div>\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_nurse-upload-page_nurse-upload-page_module_ts.js.map