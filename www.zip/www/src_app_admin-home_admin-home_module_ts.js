(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_admin-home_admin-home_module_ts"],{

/***/ 7756:
/*!*********************************************************!*\
  !*** ./src/app/admin-home/admin-home-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminHomePageRoutingModule": () => (/* binding */ AdminHomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _admin_home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./admin-home.page */ 8153);




const routes = [
    {
        path: '',
        component: _admin_home_page__WEBPACK_IMPORTED_MODULE_0__.AdminHomePage
    }
];
let AdminHomePageRoutingModule = class AdminHomePageRoutingModule {
};
AdminHomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AdminHomePageRoutingModule);



/***/ }),

/***/ 3591:
/*!*************************************************!*\
  !*** ./src/app/admin-home/admin-home.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminHomePageModule": () => (/* binding */ AdminHomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _admin_home_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./admin-home-routing.module */ 7756);
/* harmony import */ var _admin_home_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./admin-home.page */ 8153);







let AdminHomePageModule = class AdminHomePageModule {
};
AdminHomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _admin_home_routing_module__WEBPACK_IMPORTED_MODULE_0__.AdminHomePageRoutingModule
        ],
        declarations: [_admin_home_page__WEBPACK_IMPORTED_MODULE_1__.AdminHomePage]
    })
], AdminHomePageModule);



/***/ }),

/***/ 8153:
/*!***********************************************!*\
  !*** ./src/app/admin-home/admin-home.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminHomePage": () => (/* binding */ AdminHomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_admin_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./admin-home.page.html */ 9220);
/* harmony import */ var _admin_home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./admin-home.page.scss */ 6311);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../error-controller.service */ 4898);



/* eslint-disable @typescript-eslint/dot-notation */
/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/naming-convention */





let AdminHomePage = class AdminHomePage {
    constructor(router, http, loadingController, ErrorCont) {
        this.router = router;
        this.http = http;
        this.loadingController = loadingController;
        this.ErrorCont = ErrorCont;
        this.dict = { 'true': true, 'false': false, '': false };
        this.profile_is_complete = false;
        this.habco_id = '';
        // eslint-disable-next-line @typescript-eslint/naming-convention
        this.app_token = '';
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
    }
    doctors_clicked() {
        this.router.navigate(['admin-doctors']);
    }
    nurses_clicked() {
        this.router.navigate(['admin-nurses']);
    }
    drugstores_clicked() {
        this.router.navigate(['admin-drugstores']);
    }
};
AdminHomePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService }
];
AdminHomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-admin-home',
        template: _raw_loader_admin_home_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_admin_home_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AdminHomePage);



/***/ }),

/***/ 6311:
/*!*************************************************!*\
  !*** ./src/app/admin-home/admin-home.page.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".qr-code {\n  text-align: center;\n  align-items: center;\n  margin-top: 7%;\n  margin-left: 20%;\n  margin-right: 20%;\n  width: 60%;\n}\n\nh1 {\n  font-family: \"PlusJakarta-bold\";\n  font-size: 15px;\n  text-align: center;\n  font-weight: 100;\n}\n\nh2 {\n  font-family: \"PlusJakarta\";\n  font-size: 13px;\n  text-align: center;\n  font-weight: 100;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 4%;\n  text-align: center;\n}\n\nion-content {\n  --ion-background-color: linear-gradient(to top, #34e67e, #abf853 80%);\n}\n\n.welcome-border {\n  text-align: center;\n  background-color: white;\n  margin-right: 10%;\n  margin-left: 10%;\n  padding-bottom: 10%;\n  border-style: groove;\n  background: rgba(255, 255, 255, 0.7);\n  box-shadow: 2px 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 6px solid rgba(255, 255, 255, 0.3);\n  margin-top: 10%;\n}\n\n.profile-status-messsage {\n  text-align: left;\n  margin-left: 10%;\n  font-size: 15px;\n}\n\n.profile-status {\n  border-style: groove;\n  background: rgba(255, 255, 255, 0.7);\n  box-shadow: 2px 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 6px solid rgba(255, 255, 255, 0.3);\n  margin-left: 10%;\n  margin-right: 10%;\n  margin-top: 5%;\n}\n\n.item {\n  border-style: groove;\n  background: rgba(255, 255, 255, 0.7);\n  box-shadow: 2px 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 6px solid rgba(255, 255, 255, 0.3);\n  height: 40%;\n  width: 40%;\n  margin: 8px 5px 0px 3px;\n  padding-bottom: 6%;\n}\n\n.flex-container {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  height: 40%;\n  margin-left: 5%;\n  margin-right: 5%;\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n\n.item-title {\n  margin-top: 25%;\n  font-size: 12px;\n  padding-bottom: 5%;\n}\n\n.sec_flex-container {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  margin-left: 10%;\n  margin-right: 10%;\n  margin-top: 10px;\n}\n\n.image {\n  height: 60%;\n  width: 60%;\n  margin-left: 20%;\n  margin-right: 20%;\n  margin-bottom: 4px;\n  text-align: center;\n}\n\n.logout {\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  height: 30%;\n  width: 40%;\n  margin: 5px 0px 0px 3px;\n  padding-bottom: 2%;\n}\n\nion-toolbar {\n  --background: #abf853;\n}\n\nion-title {\n  font-family: AquireBold;\n  font-size: 25px;\n}\n\n.welcome-border-habco {\n  border-style: groove;\n  background: rgba(255, 255, 255, 0.7);\n  box-shadow: 2px 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 6px solid rgba(255, 255, 255, 0.3);\n  margin-right: 10%;\n  margin-left: 10%;\n  padding-bottom: 5%;\n  margin-top: 10%;\n  font-family: AquireBold;\n}\n\n.habco_id {\n  font-family: AquireBold;\n  font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkbWluLWhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtBQUFGOztBQUdBO0VBQ0UsK0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUFGOztBQUVBO0VBQ0UsMEJBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUNBO0VBQ0UsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQUVGOztBQUVBO0VBQ0UscUVBQUE7QUFDRjs7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxvQkFBQTtFQUNFLG9DQUFBO0VBRUosa0RBQUE7RUFDQSw0QkFBQTtFQUNBLG9DQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtFQUNBLGVBQUE7QUFDQTs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBRUY7O0FBQUE7RUFDRSxvQkFBQTtFQUNBLG9DQUFBO0VBRUYsa0RBQUE7RUFDQSw0QkFBQTtFQUNBLG9DQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBRUY7O0FBQ0E7RUFDRSxvQkFBQTtFQUNBLG9DQUFBO0VBRUYsa0RBQUE7RUFDQSw0QkFBQTtFQUNBLG9DQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtFQUNFLFdBQUE7RUFDQSxVQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUNBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFFRjs7QUFBQTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFHRjs7QUFEQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFJRjs7QUFEQTtFQUNFLFdBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFJRjs7QUFEQTtFQUNFLG9DQUFBO0VBQ0EsZ0RBQUE7RUFDQSw0QkFBQTtFQUNBLG9DQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQ0FBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQUlGOztBQUZBO0VBQ0UscUJBQUE7QUFLRjs7QUFGQTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtBQUtGOztBQUhBO0VBQ0Usb0JBQUE7RUFDQSxvQ0FBQTtFQUVGLGtEQUFBO0VBQ0EsNEJBQUE7RUFDQSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsMENBQUE7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFFRixlQUFBO0VBQ0EsdUJBQUE7QUFJQTs7QUFGQTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtBQUtGIiwiZmlsZSI6ImFkbWluLWhvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5xci1jb2Rle1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIG1hcmdpbi10b3A6IDclO1xyXG4gIG1hcmdpbi1sZWZ0OiAyMCU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyMCU7XHJcbiAgd2lkdGg6IDYwJTtcclxufVxyXG5cclxuaDF7XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgZm9udC13ZWlnaHQ6IDEwMDtcclxufVxyXG5oMntcclxuICBmb250LWZhbWlseTogXCJQbHVzSmFrYXJ0YVwiO1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgZm9udC13ZWlnaHQ6IDEwMDtcclxufVxyXG5we1xyXG4gIGNvbG9yOiAjODY4Njg2ZGM7XHJcbiAgZm9udC1mYW1pbHk6ICdRYW5lbGFzVWx0cmFMaWdodCc7XHJcbiAgbWFyZ2luLXRvcDogNCU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxufVxyXG5cclxuaW9uLWNvbnRlbnR7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbGluZWFyLWdyYWRpZW50KHRvIHRvcCwgIzM0ZTY3ZSwgI2FiZjg1MyA4MCUpO1xyXG59XHJcbi53ZWxjb21lLWJvcmRlcntcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICBwYWRkaW5nLWJvdHRvbTogMTAlO1xyXG4gIGJvcmRlci1zdHlsZTpncm9vdmU7XHJcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjcgKTtcclxuXHJcbmJveC1zaGFkb3c6IDJweCA4cHggMzJweCAwIHJnYmEoIDMxLCAzOCwgMTM1LCAwLjM3ICk7XHJcbmJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuLXdlYmtpdC1iYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDIuNXB4ICk7XHJcbmJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbmJvcmRlcjogNnB4IHNvbGlkIHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuMyApO1xyXG5tYXJnaW4tdG9wOiAxMCU7XHJcbn1cclxuLnByb2ZpbGUtc3RhdHVzLW1lc3NzYWdle1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbn1cclxuLnByb2ZpbGUtc3RhdHVze1xyXG4gIGJvcmRlci1zdHlsZTpncm9vdmU7XHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC43ICk7XHJcblxyXG5ib3gtc2hhZG93OiAycHggOHB4IDMycHggMCByZ2JhKCAzMSwgMzgsIDEzNSwgMC4zNyApO1xyXG5iYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDIuNXB4ICk7XHJcbi13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG5ib3JkZXI6IDZweCBzb2xpZCByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjMgKTtcclxuICBtYXJnaW4tbGVmdDogMTAlO1xyXG4gIG1hcmdpbi1yaWdodDogMTAlO1xyXG4gIG1hcmdpbi10b3A6IDUlO1xyXG4gIH1cclxuXHJcbi5pdGVte1xyXG4gIGJvcmRlci1zdHlsZTpncm9vdmU7XHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC43ICk7XHJcblxyXG5ib3gtc2hhZG93OiAycHggOHB4IDMycHggMCByZ2JhKCAzMSwgMzgsIDEzNSwgMC4zNyApO1xyXG5iYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDIuNXB4ICk7XHJcbi13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG5ib3JkZXI6IDZweCBzb2xpZCByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjMgKTtcclxuICBoZWlnaHQ6IDQwJTtcclxuICB3aWR0aDogNDAlO1xyXG4gIG1hcmdpbjo4cHggNXB4IDBweCAzcHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDYlO1xyXG59XHJcbi5mbGV4LWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmbGV4LXdyYXA6d3JhcDtcclxuICBoZWlnaHQ6IDQwJTtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcbi5pdGVtLXRpdGxle1xyXG4gIG1hcmdpbi10b3A6IDI1JTtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDUlO1xyXG59XHJcbi5zZWNfZmxleC1jb250YWluZXIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZmxleC13cmFwOndyYXA7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDEwJTtcclxuICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG4uaW1hZ2V7XHJcbiAgaGVpZ2h0OiA2MCU7XHJcbiAgd2lkdGg6IDYwJTtcclxuICBtYXJnaW4tbGVmdDogMjAlO1xyXG4gIG1hcmdpbi1yaWdodDogMjAlO1xyXG4gIG1hcmdpbi1ib3R0b206IDRweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG59XHJcbi5sb2dvdXR7XHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC42ICk7XHJcbiAgYm94LXNoYWRvdzogMCA4cHggMzJweCAwIHJnYmEoIDMxLCAzOCwgMTM1LCAwLjM3ICk7XHJcbiAgYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4gIC13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSggMjU1LCAyNTUsIDI1NSwgMC4xOCApO1xyXG4gIGhlaWdodDogMzAlO1xyXG4gIHdpZHRoOiA0MCU7XHJcbiAgbWFyZ2luOjVweCAwcHggMHB4IDNweDtcclxuICBwYWRkaW5nLWJvdHRvbTogMiU7XHJcbn1cclxuaW9uLXRvb2xiYXIge1xyXG4gIC0tYmFja2dyb3VuZDogI2FiZjg1MztcclxuXHJcbn1cclxuaW9uLXRpdGxle1xyXG4gIGZvbnQtZmFtaWx5OkFxdWlyZUJvbGQgO1xyXG4gIGZvbnQtc2l6ZTogMjVweDtcclxufVxyXG4ud2VsY29tZS1ib3JkZXItaGFiY297XHJcbiAgYm9yZGVyLXN0eWxlOmdyb292ZTtcclxuICBiYWNrZ3JvdW5kOiByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjcgKTtcclxuXHJcbmJveC1zaGFkb3c6IDJweCA4cHggMzJweCAwIHJnYmEoIDMxLCAzOCwgMTM1LCAwLjM3ICk7XHJcbmJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuLXdlYmtpdC1iYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDIuNXB4ICk7XHJcbmJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbmJvcmRlcjogNnB4IHNvbGlkIHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuMyApO1xyXG4gIG1hcmdpbi1yaWdodDogMTAlO1xyXG4gIG1hcmdpbi1sZWZ0OiAxMCU7XHJcbiAgcGFkZGluZy1ib3R0b206IDUlO1xyXG5cclxubWFyZ2luLXRvcDogMTAlO1xyXG5mb250LWZhbWlseTpBcXVpcmVCb2xkIDtcclxufVxyXG4uaGFiY29faWR7XHJcbiAgZm9udC1mYW1pbHk6QXF1aXJlQm9sZCA7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 9220:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin-home/admin-home.page.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n    <ion-header>\n      <ion-toolbar>\n        <ion-title>Habco</ion-title>\n      </ion-toolbar>\n    </ion-header>\n\n    <ion-content>\n      <ion-fab horizontal=\"end\" vertical=\"top\" slot=\"fixed\" edge>\n        <ion-fab-button>\n          <ion-icon name=\"add\"></ion-icon>\n        </ion-fab-button>\n        <ion-fab-list>\n          <ion-fab-button color=\"light\">\n            <ion-icon name=\"logo-facebook\"></ion-icon>\n          </ion-fab-button>\n          <ion-fab-button color=\"light\">\n            <ion-icon name=\"logo-twitter\"></ion-icon>\n          </ion-fab-button>\n          <ion-fab-button color=\"light\">\n            <ion-icon name=\"logo-vimeo\"></ion-icon>\n          </ion-fab-button>\n        </ion-fab-list>\n      </ion-fab>\n        <div class='welcome-border'>\n\n          <h2>Welcome ,you are logged in as <h1>Admin</h1> </h2>\n        </div>\n\n\n  <div class=\"flex-container\" >\n\n    <div class =\"item\" (click)=\"doctors_clicked()\">\n      <div class=\"image\">\n        <img src=\"/assets/Doctor-user-homepage.png\" alt=\"\">\n\n      </div>\n      <h1 class=\"item-title\">Doctors</h1>\n\n    </div>\n\n\n    <div class =\"item\">\n      <div class=\"image\">\n        <img src=\"/assets/nurse.png\" alt=\"\" (click)=\"nurses_clicked()\">\n      </div>\n      <h1 class=\"item-title\">Nurses\n      </h1>\n    </div>\n    <div class =\"item\" (click)=\"drugstores_clicked()\">\n      <div class=\"image\" >\n        <img src=\"/assets/Drugstore.png\" alt=\"\">\n      </div>\n      <h1 class=\"item-title\">Drug Stores\n      </h1>\n    </div>\n  </div>\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_admin-home_admin-home_module_ts.js.map