(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_doctor-home-page_doctor-home-page_module_ts"],{

/***/ 914:
/*!*********************************************************************!*\
  !*** ./src/app/doctor-home-page/doctor-home-page-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DoctorHomePagePageRoutingModule": () => (/* binding */ DoctorHomePagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _doctor_home_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./doctor-home-page.page */ 4266);




const routes = [
    {
        path: '',
        component: _doctor_home_page_page__WEBPACK_IMPORTED_MODULE_0__.DoctorHomePagePage
    }
];
let DoctorHomePagePageRoutingModule = class DoctorHomePagePageRoutingModule {
};
DoctorHomePagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DoctorHomePagePageRoutingModule);



/***/ }),

/***/ 6036:
/*!*************************************************************!*\
  !*** ./src/app/doctor-home-page/doctor-home-page.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DoctorHomePagePageModule": () => (/* binding */ DoctorHomePagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _doctor_home_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./doctor-home-page-routing.module */ 914);
/* harmony import */ var _doctor_home_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./doctor-home-page.page */ 4266);







let DoctorHomePagePageModule = class DoctorHomePagePageModule {
};
DoctorHomePagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _doctor_home_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.DoctorHomePagePageRoutingModule
        ],
        declarations: [_doctor_home_page_page__WEBPACK_IMPORTED_MODULE_1__.DoctorHomePagePage]
    })
], DoctorHomePagePageModule);



/***/ }),

/***/ 4266:
/*!***********************************************************!*\
  !*** ./src/app/doctor-home-page/doctor-home-page.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DoctorHomePagePage": () => (/* binding */ DoctorHomePagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_doctor_home_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./doctor-home-page.page.html */ 9108);
/* harmony import */ var _doctor_home_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./doctor-home-page.page.scss */ 8705);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../error-controller.service */ 4898);
/* harmony import */ var _doctor_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../doctor-service.service */ 5268);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);




/* eslint-disable @typescript-eslint/dot-notation */
/* eslint-disable object-shorthand */

/* eslint-disable @typescript-eslint/naming-convention */




let DoctorHomePagePage = class DoctorHomePagePage {
    constructor(router, http, doctor_service, ErrorCont) {
        this.router = router;
        this.http = http;
        this.doctor_service = doctor_service;
        this.ErrorCont = ErrorCont;
        // eslint-disable-next-line quote-props
        this.dict = { 'true': true, 'false': false, '': false, 1: true, 0: false };
        // eslint-disable-next-line @typescript-eslint/naming-convention
        this.profile_is_complete = this.dict[localStorage.getItem('profile_completed')];
        this.cv_accepted = false;
        this.document_accepted = false;
        this.app_token = '';
        this.patients_number = 0;
        this.prescriptions_number = 0;
    }
    edit_button_clicked() {
        this.router.navigate(['doctor-upload']);
    }
    logout_clicked() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers: headers };
            this.http.delete('https://habco.rshayanfar.ir/habco/token', options).toPromise().then(resp => {
                localStorage.removeItem('app-token');
                this.router.navigate(['welcome']);
            }).catch(error => {
                this.ErrorCont.showError(error);
            });
        });
    }
    doc_and_cv_status() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers: headers };
            this.http.get('https://habco.rshayanfar.ir/habco/user', options).toPromise().then(resp => {
                localStorage.setItem('user_id', resp['data']['id']);
            }).catch(error => {
                this.ErrorCont.showError(error);
            });
            if (localStorage.getItem('user_id')) {
                this.http.get('https://habco.rshayanfar.ir/habco/doctor/' +
                    localStorage.getItem('user_id').toString(), options).toPromise().then(resp => {
                    this.cv_id = resp['data']['cv_id'];
                    this.document_id = resp['data']['document_id'];
                    this.http.get('https://habco.rshayanfar.ir/habco/document/' + this.document_id, options).toPromise().then(rest => {
                        this.document_accepted = this.dict[rest['data']['verified']];
                    }).catch(error => {
                        this.ErrorCont.showError(error);
                    });
                    this.http.get('https://habco.rshayanfar.ir/habco/document/' + this.cv_id, options).toPromise().then(response => {
                        this.cv_accepted = this.dict[response['data']['verified']];
                    }).catch(error => {
                        this.ErrorCont.showError(error);
                    });
                }).catch(error => {
                    this.ErrorCont.showError(error);
                });
            }
        });
    }
    get_patients() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers: headers };
            this.http.get('https://habco.rshayanfar.ir/habco/patient', options).toPromise().then(resp => {
                this.doctor_service.patients_list = resp['data'];
                this.patients_number = this.doctor_service.patients_list.length;
            }).catch(error => {
                this.ErrorCont.showError(error);
            });
        });
    }
    get_prescriptions() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers: headers };
            this.http.get('https://habco.rshayanfar.ir/habco/prescription', options).toPromise().then(resp => {
                console.log(resp);
                this.doctor_service.prescriptions_list = resp['data'];
                this.prescriptions_number = this.doctor_service.prescriptions_list.length;
            }).catch(error => {
                this.ErrorCont.showError(error);
            });
        });
    }
    ionViewWillEnter() {
        this.app_token = localStorage.getItem('app-token');
        this.doc_and_cv_status();
        this.get_patients();
        this.get_prescriptions();
    }
    patients_clicked() {
        this.router.navigate(['doctor-patients-page']);
    }
    prescriptions_clicked() {
        this.router.navigate(['doctor-prescriptions-page']);
    }
    ngOnInit() {
    }
};
DoctorHomePagePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _doctor_service_service__WEBPACK_IMPORTED_MODULE_3__.DoctorServiceService },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService }
];
DoctorHomePagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-doctor-home-page',
        template: _raw_loader_doctor_home_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_doctor_home_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DoctorHomePagePage);



/***/ }),

/***/ 8705:
/*!*************************************************************!*\
  !*** ./src/app/doctor-home-page/doctor-home-page.page.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("h1 {\n  font-family: \"PlusJakarta-bold\";\n  font-size: 15px;\n  text-align: center;\n  font-weight: 100;\n}\n\nh2 {\n  font-family: \"PlusJakarta\";\n  font-size: 13px;\n  text-align: center;\n  font-weight: 100;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 4%;\n  text-align: center;\n}\n\nion-content {\n  --ion-background-color: linear-gradient(to top, #34e67e, #abf853 80%);\n}\n\n.welcome-border {\n  background-color: white;\n  margin-right: 10%;\n  margin-left: 10%;\n  padding-bottom: 10%;\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  margin-top: 10%;\n}\n\n.profile-status-messsage {\n  text-align: left;\n  margin-left: 10%;\n  font-size: 15px;\n}\n\n.profile-status {\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  margin-left: 10%;\n  margin-right: 10%;\n  margin-top: 5%;\n}\n\n.item {\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  height: 40%;\n  width: 40%;\n  margin: 8px 5px 0px 3px;\n  padding-bottom: 6%;\n}\n\n.flex-container {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  height: 40%;\n  margin-left: 5%;\n  margin-right: 5%;\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n\n.item-title {\n  margin-top: 3px;\n}\n\n.sec_flex-container {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  margin-left: 10%;\n  margin-right: 10%;\n  margin-top: 10px;\n}\n\n.image {\n  height: 40px;\n  width: 40px;\n  margin-bottom: 4px;\n  text-align: center;\n  margin-left: 27%;\n}\n\n.logout {\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  height: 30%;\n  width: 40%;\n  margin: 5px 0px 0px 3px;\n  padding-bottom: 2%;\n}\n\nion-toolbar {\n  --background: #abf853;\n}\n\nion-title {\n  font-family: AquireBold;\n  font-size: 25px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRvY3Rvci1ob21lLXBhZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UsK0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUFGOztBQUVBO0VBQ0UsMEJBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUNBO0VBQ0UsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQUVGOztBQUVBO0VBQ0UscUVBQUE7QUFDRjs7QUFDQTtFQUNFLHVCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esb0NBQUE7RUFDRixnREFBQTtFQUNBLDRCQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQkFBQTtFQUNBLDJDQUFBO0VBQ0EsZUFBQTtBQUVBOztBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFHRjs7QUFEQTtFQUNFLG9DQUFBO0VBQ0EsZ0RBQUE7RUFDQSw0QkFBQTtFQUNBLG9DQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBSUY7O0FBREE7RUFDRSxvQ0FBQTtFQUNBLGdEQUFBO0VBQ0EsNEJBQUE7RUFDQSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsMkNBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUFJRjs7QUFGQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBS0Y7O0FBSEE7RUFDRSxlQUFBO0FBTUY7O0FBSEE7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBTUY7O0FBSEE7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQU1GOztBQUpBO0VBQ0Usb0NBQUE7RUFDQSxnREFBQTtFQUNBLDRCQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQkFBQTtFQUNBLDJDQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0FBT0Y7O0FBTEE7RUFDRSxxQkFBQTtBQVFGOztBQUxBO0VBQ0UsdUJBQUE7RUFDQSxlQUFBO0FBUUYiLCJmaWxlIjoiZG9jdG9yLWhvbWUtcGFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaDF7XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgZm9udC13ZWlnaHQ6IDEwMDtcclxufVxyXG5oMntcclxuICBmb250LWZhbWlseTogXCJQbHVzSmFrYXJ0YVwiO1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgZm9udC13ZWlnaHQ6IDEwMDtcclxufVxyXG5we1xyXG4gIGNvbG9yOiAjODY4Njg2ZGM7XHJcbiAgZm9udC1mYW1pbHk6ICdRYW5lbGFzVWx0cmFMaWdodCc7XHJcbiAgbWFyZ2luLXRvcDogNCU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxufVxyXG5cclxuaW9uLWNvbnRlbnR7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbGluZWFyLWdyYWRpZW50KHRvIHRvcCwgIzM0ZTY3ZSwgI2FiZjg1MyA4MCUpO1xyXG59XHJcbi53ZWxjb21lLWJvcmRlcntcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBtYXJnaW4tcmlnaHQ6IDEwJTtcclxuICBtYXJnaW4tbGVmdDogMTAlO1xyXG4gIHBhZGRpbmctYm90dG9tOiAxMCU7XHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC42ICk7XHJcbmJveC1zaGFkb3c6IDAgOHB4IDMycHggMCByZ2JhKCAzMSwgMzgsIDEzNSwgMC4zNyApO1xyXG5iYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDIuNXB4ICk7XHJcbi13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG5ib3JkZXI6IDFweCBzb2xpZCByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjE4ICk7XHJcbm1hcmdpbi10b3A6IDEwJTtcclxufVxyXG4ucHJvZmlsZS1zdGF0dXMtbWVzc3NhZ2V7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxuICBtYXJnaW4tbGVmdDogMTAlO1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG4ucHJvZmlsZS1zdGF0dXN7XHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC42ICk7XHJcbiAgYm94LXNoYWRvdzogMCA4cHggMzJweCAwIHJnYmEoIDMxLCAzOCwgMTM1LCAwLjM3ICk7XHJcbiAgYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4gIC13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSggMjU1LCAyNTUsIDI1NSwgMC4xOCApO1xyXG4gIG1hcmdpbi1sZWZ0OiAxMCU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMCU7XHJcbiAgbWFyZ2luLXRvcDogNSU7XHJcbiAgfVxyXG5cclxuLml0ZW17XHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC42ICk7XHJcbiAgYm94LXNoYWRvdzogMCA4cHggMzJweCAwIHJnYmEoIDMxLCAzOCwgMTM1LCAwLjM3ICk7XHJcbiAgYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4gIC13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSggMjU1LCAyNTUsIDI1NSwgMC4xOCApO1xyXG4gIGhlaWdodDogNDAlO1xyXG4gIHdpZHRoOiA0MCU7XHJcbiAgbWFyZ2luOjhweCA1cHggMHB4IDNweDtcclxuICBwYWRkaW5nLWJvdHRvbTogNiU7XHJcbn1cclxuLmZsZXgtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGZsZXgtd3JhcDp3cmFwO1xyXG4gIGhlaWdodDogNDAlO1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIG1hcmdpbi10b3A6IDBweDtcclxuICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbn1cclxuLml0ZW0tdGl0bGV7XHJcbiAgbWFyZ2luLXRvcDogM3B4O1xyXG5cclxufVxyXG4uc2VjX2ZsZXgtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGZsZXgtd3JhcDp3cmFwO1xyXG4gIG1hcmdpbi1sZWZ0OiAxMCU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMCU7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG5cclxuLmltYWdle1xyXG4gIGhlaWdodDogNDBweDtcclxuICB3aWR0aDogNDBweDtcclxuICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIG1hcmdpbi1sZWZ0OiAyNyU7XHJcbn1cclxuLmxvZ291dHtcclxuICBiYWNrZ3JvdW5kOiByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjYgKTtcclxuICBib3gtc2hhZG93OiAwIDhweCAzMnB4IDAgcmdiYSggMzEsIDM4LCAxMzUsIDAuMzcgKTtcclxuICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDIuNXB4ICk7XHJcbiAgLXdlYmtpdC1iYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDIuNXB4ICk7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjE4ICk7XHJcbiAgaGVpZ2h0OiAzMCU7XHJcbiAgd2lkdGg6IDQwJTtcclxuICBtYXJnaW46NXB4IDBweCAwcHggM3B4O1xyXG4gIHBhZGRpbmctYm90dG9tOiAyJTtcclxufVxyXG5pb24tdG9vbGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjYWJmODUzO1xyXG5cclxufVxyXG5pb24tdGl0bGV7XHJcbiAgZm9udC1mYW1pbHk6QXF1aXJlQm9sZCA7XHJcbiAgZm9udC1zaXplOiAyNXB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 9108:
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/doctor-home-page/doctor-home-page.page.html ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Habco</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-fab horizontal=\"end\" vertical=\"top\" slot=\"fixed\" edge>\n    <ion-fab-button>\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n    <ion-fab-list>\n      <ion-fab-button color=\"light\">\n        <ion-icon name=\"logo-facebook\"></ion-icon>\n      </ion-fab-button>\n      <ion-fab-button color=\"light\">\n        <ion-icon name=\"logo-twitter\"></ion-icon>\n      </ion-fab-button>\n      <ion-fab-button color=\"light\">\n        <ion-icon name=\"logo-vimeo\"></ion-icon>\n      </ion-fab-button>\n    </ion-fab-list>\n  </ion-fab>\n    <div class='welcome-border'>\n\n      <h2>Welcome ,you are logged in as a <h1>Doctor</h1> </h2>\n    </div>\n\n    <div class='profile-status' (click)=\"edit_button_clicked()\">\n      <h1 class=\"profile-status-messsage\">Your profile status:</h1>\n      <div>\n        <h2 class=\"profile-status-messsage\">Your cv status:\n          <div class=\"incomplete\" *ngIf=\"!cv_accepted\">\n            <div style=\"text-align: left;font-size:13px;margin-top:10px\">\n              <b style=\"color: rgb(199, 40, 40);\">Not accepted yet</b>\n\n            </div>\n          </div>\n          <div class=\"complete\" *ngIf=\"cv_accepted\">\n            <div style=\"text-align: left;font-size:13px;margin-top:10px\">\n              <ion-icon slot=\"end\" name=\"checkmark-circle\" style=\"color: green;margin-right:4px;\"></ion-icon>\n              <b style=\"color: rgb(14, 165, 64);\">Accepted</b>\n\n            </div>\n\n\n          </div>\n        </h2>\n\n        <h2 class=\"profile-status-messsage\">Your document status:\n          <div class=\"incomplete\" *ngIf=\"!document_accepted\">\n            <div style=\"text-align: left;font-size:13px;margin-top:10px\">\n              <b style=\"color: rgb(199, 40, 40);\">Not accepted yet</b>\n\n            </div>\n            <div style=\"text-align: center; margin-right:7%;\">\n\n            <h2 style=\"text-align: center;font-size:12px;\">Click here to complete your profile</h2>\n            </div>\n          </div>\n          <div class=\"complete\" *ngIf=\"document_accepted\">\n            <div style=\"text-align: left;font-size:13px;margin-top:10px\">\n              <ion-icon slot=\"end\" name=\"checkmark-circle\" style=\"color: green;margin-right:4px;\"></ion-icon>\n              <b style=\"color: rgb(14, 165, 64);\">Accepted</b>\n\n            </div>\n            <div style=\"text-align: center;margin-right:8%;\">\n              <h2 style=\"text-align: center;font-size:12px;\">Click <a>here</a> to change your profile and upload your cv</h2>\n\n            </div>\n\n          </div>\n        </h2>\n      </div>\n\n    </div>\n\n    <div class=\"flex-container\">\n\n      <div class =\"item\" (click)=\"patients_clicked()\">\n        <ion-badge color=\"tertiary\">{{this.patients_number}}</ion-badge>\n\n        <div class=\"image\">\n\n          <img src=\"/assets/patient-logo.png\" alt=\"\">\n        </div>\n        <h1 style=\"font-size: 11px;margin-top:3px;\">My Patients</h1>\n      </div>\n\n      <div class =\"item\" (click)=\"prescriptions_clicked()\" >\n        <ion-badge color=\"tertiary\">{{this.prescriptions_number}}</ion-badge>\n        <div class=\"image\">\n          <img src=\"/assets/prescription-logo.png\" alt=\"\">\n        </div>\n        <h1 style=\"font-size: 11px;margin-top:3px;\">Prescriptions\n        </h1>\n      </div>\n\n      <div class =\"logout\" (click)=\"logout_clicked()\">\n        <div class=\"image\">\n          <img src=\"/assets/logout.png\" alt=\"\">\n        </div>\n        <h1 style=\"font-size: 11px;margin-top:3px;\">Logout\n        </h1>\n      </div>\n    </div>\n\n</ion-content>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_doctor-home-page_doctor-home-page_module_ts.js.map