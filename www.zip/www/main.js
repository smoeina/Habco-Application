(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["main"],{

/***/ 8255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 8255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);



const routes = [
    {
        path: '',
        redirectTo: 'welcome',
        pathMatch: 'full'
    },
    {
        path: 'welcome',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_welcome_welcome_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./welcome/welcome.module */ 2526)).then(m => m.WelcomePageModule)
    },
    {
        path: 'login',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./login/login.module */ 107)).then(m => m.LoginPageModule)
    },
    {
        path: 'register',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_register_register_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./register/register.module */ 8723)).then(m => m.RegisterPageModule)
    },
    {
        path: 'sms-verification',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_sms-verification_sms-verification_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./sms-verification/sms-verification.module */ 3917)).then(m => m.SmsVerificationPageModule)
    },
    {
        path: 'doctor-upload',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_doctor-upload_doctor-upload_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./doctor-upload/doctor-upload.module */ 366)).then(m => m.DoctorUploadPageModule)
    },
    {
        path: 'doctor-home-page',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_doctor-home-page_doctor-home-page_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./doctor-home-page/doctor-home-page.module */ 6036)).then(m => m.DoctorHomePagePageModule)
    },
    {
        path: 'user-home-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_user-home-page_user-home-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./user-home-page/user-home-page.module */ 4737)).then(m => m.UserHomePagePageModule)
    },
    {
        path: 'patient-edit-info',
        loadChildren: () => Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./patient-edit-info/patient-edit-info.module */ 9652)).then(m => m.PatientEditInfoPageModule)
    },
    {
        path: 'user-doctors-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_user-doctors-page_user-doctors-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./user-doctors-page/user-doctors-page.module */ 9545)).then(m => m.UserDoctorsPagePageModule)
    },
    {
        path: 'user-nurses-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_user-nurses-page_user-nurses-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./user-nurses-page/user-nurses-page.module */ 3759)).then(m => m.UserNursesPagePageModule)
    },
    {
        path: 'doctor-patients-page',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_doctor-patients-page_doctor-patients-page_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./doctor-patients-page/doctor-patients-page.module */ 1415)).then(m => m.DoctorPatientsPagePageModule)
    },
    {
        path: 'doctor-prescriptions-page',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_doctor-prescriptions-page_doctor-prescriptions-page_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./doctor-prescriptions-page/doctor-prescriptions-page.module */ 4318)).
            then(m => m.DoctorPrescriptionsPagePageModule)
    },
    {
        path: 'doctor-add-prescription',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_doctor-add-prescription_doctor-add-prescription_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./doctor-add-prescription/doctor-add-prescription.module */ 741)).then(m => m.DoctorAddPrescriptionPageModule)
    },
    {
        path: 'nurse-home-page',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_nurse-home-page_nurse-home-page_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./nurse-home-page/nurse-home-page.module */ 2562)).then(m => m.NurseHomePagePageModule)
    },
    {
        path: 'nurse-patients-page',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_nurse-patients-page_nurse-patients-page_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./nurse-patients-page/nurse-patients-page.module */ 1278)).then(m => m.NursePatientsPagePageModule)
    },
    {
        path: 'nurse-add-prescription-page',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_nurse-add-prescription-page_nurse-add-prescription-page_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./nurse-add-prescription-page/nurse-add-prescription-page.module */ 5079)).
            then(m => m.NurseAddPrescriptionPagePageModule)
    },
    {
        path: 'nurse-upload-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_nurse-upload-page_nurse-upload-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./nurse-upload-page/nurse-upload-page.module */ 4672)).then(m => m.NurseUploadPagePageModule)
    },
    {
        path: 'nurse-prescription-page',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_nurse-prescription-page_nurse-prescription-page_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./nurse-prescription-page/nurse-prescription-page.module */ 6009)).then(m => m.NursePrescriptionPagePageModule)
    },
    {
        path: 'user-prescriptions-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_user-prescriptions-page_user-prescriptions-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./user-prescriptions-page/user-prescriptions-page.module */ 8549)).then(m => m.UserPrescriptionsPagePageModule)
    },
    {
        path: 'user-doctors-all-doctors',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_user-doctors-all-doctors_user-doctors-all-doctors_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./user-doctors-all-doctors/user-doctors-all-doctors.module */ 7296)).then(m => m.UserDoctorsAllDoctorsPageModule)
    },
    {
        path: 'user-doctors-my-doctors',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_user-doctors-my-doctors_user-doctors-my-doctors_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./user-doctors-my-doctors/user-doctors-my-doctors.module */ 3461)).then(m => m.UserDoctorsMyDoctorsPageModule)
    },
    {
        path: 'user-drugstores-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_user-drugstores-page_user-drugstores-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./user-drugstores-page/user-drugstores-page.module */ 197)).then(m => m.UserDrugstoresPagePageModule)
    },
    {
        path: 'drugstore-home-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_drugstore-home-page_drugstore-home-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./drugstore-home-page/drugstore-home-page.module */ 9706)).then(m => m.DrugstoreHomePagePageModule)
    },
    {
        path: 'drugstore-edit-info',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_drugstore-edit-info_drugstore-edit-info_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./drugstore-edit-info/drugstore-edit-info.module */ 7002)).then(m => m.DrugstoreEditInfoPageModule)
    },
    {
        path: 'drugstore-prescriptions-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_drugstore-prescriptions-page_drugstore-prescriptions-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./drugstore-prescriptions-page/drugstore-prescriptions-page.module */ 1570)).
            then(m => m.DrugstorePrescriptionsPagePageModule)
    },
    {
        path: 'drugstore-drugs-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_drugstore-drugs-page_drugstore-drugs-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./drugstore-drugs-page/drugstore-drugs-page.module */ 2354)).then(m => m.DrugstoreDrugsPagePageModule)
    },
    {
        path: 'drugstore-edit-info',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_drugstore-edit-info_drugstore-edit-info_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./drugstore-edit-info/drugstore-edit-info.module */ 7002)).then(m => m.DrugstoreEditInfoPageModule)
    },
    {
        path: 'admin-home',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_admin-home_admin-home_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./admin-home/admin-home.module */ 3591)).then(m => m.AdminHomePageModule)
    },
    {
        path: 'admin-nurses',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_admin-nurses_admin-nurses_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./admin-nurses/admin-nurses.module */ 6743)).then(m => m.AdminNursesPageModule)
    },
    {
        path: 'admin-doctors',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_admin-doctors_admin-doctors_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./admin-doctors/admin-doctors.module */ 4290)).then(m => m.AdminDoctorsPageModule)
    },
    {
        path: 'admin-drugstores',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_admin-drugstores_admin-drugstores_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./admin-drugstores/admin-drugstores.module */ 3207)).then(m => m.AdminDrugstoresPageModule)
    },
    {
        path: 'admin-see-info',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_admin-see-info_admin-see-info_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./admin-see-info/admin-see-info.module */ 6913)).then(m => m.AdminSeeInfoPageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./app.component.html */ 1106);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 3069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let AppComponent = class AppComponent {
    constructor(route) {
        this.route = route;
    }
};
AppComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _patient_edit_info_patient_edit_info_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./patient-edit-info/patient-edit-info.module */ 9652);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ 9075);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ion-intl-tel-input */ 6662);
/* harmony import */ var _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/http/ngx */ 8589);













let AppModule = class AppModule {
    constructor() {
    }
};
AppModule.ctorParameters = () => [];
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent],
        entryComponents: [],
        imports: [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__.BrowserModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClientModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule.forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_2__.AppRoutingModule, ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_10__.IonIntlTelInputModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule, _patient_edit_info_patient_edit_info_module__WEBPACK_IMPORTED_MODULE_0__.PatientEditInfoPageModule],
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClientModule, _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_3__.HTTP, { provide: _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicRouteStrategy }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 2891:
/*!*********************************!*\
  !*** ./src/app/auth.service.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./error-controller.service */ 4898);

/* eslint-disable arrow-body-style */
/* eslint-disable quote-props */
/* eslint-disable object-shorthand */
/* eslint-disable @typescript-eslint/naming-convention */




let AuthService = class AuthService {
    constructor(http, ErrorCont) {
        this.http = http;
        this.ErrorCont = ErrorCont;
        this.my_dict = { 'Yes': true, 'No': false, 'YES': true, 'NO': false, 'MALE': 'male', 'FEMALE': 'female', 'Male': 'male', 'Female': 'female' };
        this.otp_token = '';
        this.app_token = '';
    }
    register(email, phone, type) {
        console.log({ 'email': email,
            'phone': phone,
            'role': type });
        return this.http.post('https://habco.rshayanfar.ir/habco/user', { 'email': email,
            'phone': phone,
            'role': type });
    }
    login(phone_number) {
        return this.http.post('https://habco.rshayanfar.ir/habco/login-token', { 'phone': phone_number });
    }
    sendValidationCode(OTP) {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'Authorization': 'Bearer ' + this.otp_token
        });
        const options = { headers: headers };
        console.log(headers);
        console.log('INE:' + 'Bearer ' + this.otp_token);
        console.log({ otp: OTP });
        return this.http.post('https://habco.rshayanfar.ir/habco/token', { otp: OTP }, options);
    }
    Edit_information(first_name, last_name, address, covidRecord, gender, age, respiratory, infectious, cardiovascular, cancer, immunological, diabetes, infectiousArea, pet) {
        this.app_token = localStorage.getItem('app-token');
        console.log(this.app_token);
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': 'Bearer ' + this.app_token
        });
        const options = { headers: headers };
        console.log(this.my_dict[gender]);
        console.log(first_name);
        console.log(last_name);
        console.log(age);
        console.log(address);
        this.http.patch('https://habco.rshayanfar.ir/habco/user', { fname: first_name,
            lname: last_name, address: address, age: age, gender: this.my_dict[gender] }, options).toPromise().then(resp => {
            console.log(resp);
        }).catch(error => {
            this.ErrorCont.showError(error);
        });
        console.log({ covid_19: this.my_dict[covidRecord],
            respiratory: this.my_dict[respiratory], infectious: this.my_dict[infectious],
            vascular: this.my_dict[cardiovascular], cancer: this.my_dict[cancer],
            imuloical: this.my_dict[immunological], diabetes: this.my_dict[diabetes],
            dangerous_area: this.my_dict[infectiousArea], pet: this.my_dict[pet], med_staff: false });
        this.http.patch('https://habco.rshayanfar.ir/habco/patient', { covid_19: this.my_dict[covidRecord],
            respiratory: this.my_dict[respiratory], infectious: this.my_dict[infectious],
            vascular: this.my_dict[cardiovascular], cancer: this.my_dict[cancer],
            imuloical: this.my_dict[immunological], diabetes: this.my_dict[diabetes],
            dangerous_area: this.my_dict[infectiousArea], pet: this.my_dict[pet], med_staff: false }, options).toPromise().then(resp => {
            console.log(resp);
        }).catch(error => {
            console.log(error.toString());
            this.ErrorCont.showError(error);
        });
        ;
        return this.http.get('https://habco.rshayanfar.ir/habco/patient/me', options);
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_0__.ErrorControllerService }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 4898:
/*!*********************************************!*\
  !*** ./src/app/error-controller.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ErrorControllerService": () => (/* binding */ ErrorControllerService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 476);




let ErrorControllerService = class ErrorControllerService {
    constructor(loadingController, alertController) {
        this.loadingController = loadingController;
        this.alertController = alertController;
    }
    showError(errorMessage) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Error',
                message: errorMessage.error.message,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    ;
    showErrorMessage(errorMessage) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Error',
                message: errorMessage,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    ;
};
ErrorControllerService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.AlertController }
];
ErrorControllerService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], ErrorControllerService);



/***/ }),

/***/ 1122:
/*!***********************************************************************!*\
  !*** ./src/app/patient-edit-info/patient-edit-info-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PatientEditInfoPageRoutingModule": () => (/* binding */ PatientEditInfoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _patient_edit_info_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./patient-edit-info.page */ 4581);




const routes = [
    {
        path: '',
        component: _patient_edit_info_page__WEBPACK_IMPORTED_MODULE_0__.PatientEditInfoPage
    }
];
let PatientEditInfoPageRoutingModule = class PatientEditInfoPageRoutingModule {
};
PatientEditInfoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PatientEditInfoPageRoutingModule);



/***/ }),

/***/ 9652:
/*!***************************************************************!*\
  !*** ./src/app/patient-edit-info/patient-edit-info.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PatientEditInfoPageModule": () => (/* binding */ PatientEditInfoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _patient_edit_info_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./patient-edit-info-routing.module */ 1122);
/* harmony import */ var _patient_edit_info_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./patient-edit-info.page */ 4581);







let PatientEditInfoPageModule = class PatientEditInfoPageModule {
};
PatientEditInfoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _patient_edit_info_routing_module__WEBPACK_IMPORTED_MODULE_0__.PatientEditInfoPageRoutingModule
        ],
        declarations: [_patient_edit_info_page__WEBPACK_IMPORTED_MODULE_1__.PatientEditInfoPage]
    })
], PatientEditInfoPageModule);



/***/ }),

/***/ 4581:
/*!*************************************************************!*\
  !*** ./src/app/patient-edit-info/patient-edit-info.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PatientEditInfoPage": () => (/* binding */ PatientEditInfoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_patient_edit_info_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./patient-edit-info.page.html */ 2504);
/* harmony import */ var _patient_edit_info_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./patient-edit-info.page.scss */ 6415);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth.service */ 2891);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 476);







let PatientEditInfoPage = class PatientEditInfoPage {
    constructor(authService, loadingController, alertController, router) {
        this.authService = authService;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.router = router;
    }
    ngOnInit() {
    }
    segmentChanged(ev) {
        console.log('Segment changed', ev);
    }
    showError(errorMessage) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Error in sending data',
                message: errorMessage.error,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    onClickSubmit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            console.log('jens');
            console.log(this.gender);
            this.authService.Edit_information(this.firstName.value, this.lastName.value, this.address.value, this.covidRecord, this.gender, this.age, this.respiratory, this.infectious, this.cardiovascular, this.cancer, this.immunological, this.diabetes, this.infectiousArea, this.pet)
                .toPromise().then(resp => {
                console.log(resp);
                loading.dismiss();
                this.router.navigate(['user-home-page']);
            }).catch(error => {
                console.log(error);
                loading.dismiss();
                this.showError(error);
            });
            ;
        });
    }
    cancelClicked() {
        this.router.navigate(['user-home-page']);
    }
};
PatientEditInfoPage.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router }
];
PatientEditInfoPage.propDecorators = {
    firstName: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['firstName',] }],
    lastName: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['lastName',] }],
    address: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['address',] }]
};
PatientEditInfoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-patient-edit-info',
        template: _raw_loader_patient_edit_info_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_patient_edit_info_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PatientEditInfoPage);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 4608);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-action-sheet.entry.js": [
		7321,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		6108,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		1489,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		305,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		5830,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		7757,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-button_2.entry.js": [
		392,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		6911,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		937,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		8695,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		6034,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		8837,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		4195,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		1709,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		5931,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		4513,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		8056,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		862,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		7509,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		6272,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		1855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		8708,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-popover.entry.js": [
		3527,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		4694,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		9222,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5277,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		9921,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		3122,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		1602,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5174,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		7895,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		6164,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		7162,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1374,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		7896,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		5043,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		7802,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		9072,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		2191,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		801,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		7110,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		431,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 3069:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 6415:
/*!***************************************************************!*\
  !*** ./src/app/patient-edit-info/patient-edit-info.page.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("h1 {\n  margin-top: 10%;\n  font-family: \"PlusJakarta-bold\";\n  margin-left: 5%;\n  font-size: 30px;\n}\n\nh2 {\n  font-family: \"PlusJakarta-bold\";\n  margin-top: 30px;\n  margin-left: 5%;\n}\n\np {\n  font-family: \"PlusJakarta-bold\";\n  margin-top: 15px;\n  margin-left: 5%;\n}\n\nion-select {\n  font-family: \"PlusJakarta-bold\";\n  width: 40%;\n  margin-left: 10%;\n  margin-right: 30%;\n}\n\nion-button {\n  width: 60%;\n  margin-right: 20%;\n  margin-left: 20%;\n  font-family: \"PlusJakarta-bold\";\n  margin-top: 10%;\n}\n\nion-input {\n  font-family: \"QanelasUltraLight\";\n  background-color: #F1F1F1;\n  margin-left: 12%;\n  margin-right: 12%;\n  width: 76%;\n  border-radius: 20px;\n  margin-top: 5px;\n  --padding-start: 10px;\n}\n\nion-textArea {\n  font-family: \"QanelasUltraLight\";\n  background-color: #F1F1F1;\n  margin-left: 12%;\n  margin-right: 12%;\n  width: 76%;\n  border-radius: 20px;\n  margin-top: 5px;\n  --padding-start: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhdGllbnQtZWRpdC1pbmZvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSwrQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBQ0E7RUFDRSwrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUVGOztBQUFBO0VBQ0UsK0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFHRjs7QUFEQTtFQUNFLCtCQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFJRjs7QUFEQTtFQUNFLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsK0JBQUE7RUFDQSxlQUFBO0FBSUY7O0FBRkE7RUFDRSxnQ0FBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtBQUtGOztBQUhBO0VBQ0UsZ0NBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7QUFNRiIsImZpbGUiOiJwYXRpZW50LWVkaXQtaW5mby5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJoMXtcclxuICBtYXJnaW4tdG9wOiAxMCU7XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxuICBmb250LXNpemU6IDMwcHg7XHJcbn1cclxuaDJ7XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDUlO1xyXG59XHJcbnB7XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDUlO1xyXG59XHJcbmlvbi1zZWxlY3R7XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIHdpZHRoOiA0MCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDMwJTtcclxufVxyXG5cclxuaW9uLWJ1dHRvbntcclxuICB3aWR0aDogNjAlO1xyXG4gIG1hcmdpbi1yaWdodDogMjAlO1xyXG4gIG1hcmdpbi1sZWZ0OiAyMCU7XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIG1hcmdpbi10b3A6IDEwJTtcclxufVxyXG5pb24taW5wdXR7XHJcbiAgZm9udC1mYW1pbHk6IFwiUWFuZWxhc1VsdHJhTGlnaHRcIjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjFGMUYxO1xyXG4gIG1hcmdpbi1sZWZ0OiAxMiU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMiU7XHJcbiAgd2lkdGg6IDc2JTtcclxuICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gIG1hcmdpbi10b3A6IDVweDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XHJcbn1cclxuaW9uLXRleHRBcmVhe1xyXG4gIGZvbnQtZmFtaWx5OiBcIlFhbmVsYXNVbHRyYUxpZ2h0XCI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI0YxRjFGMTtcclxuICBtYXJnaW4tbGVmdDogMTIlO1xyXG4gIG1hcmdpbi1yaWdodDogMTIlO1xyXG4gIHdpZHRoOiA3NiU7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xyXG59XHJcblxyXG4iXX0= */");

/***/ }),

/***/ 1106:
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<meta http-equiv=\"Content-Security-Policy\" content=\"default-src *; style-src 'self' 'unsafe-inline'; script-src * 'unsafe-inline' 'unsafe-eval'\">\n<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n");

/***/ }),

/***/ 2504:
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/patient-edit-info/patient-edit-info.page.html ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"user-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Edit Information</ion-title>\n  </ion-toolbar>\n<ion-progress-bar type=\"indeterminate\" reversed=\"true\" value='35' bufferValue='0.5'></ion-progress-bar>\n\n</ion-header>\n\n<ion-content>\n\n    <div class=\"title\">\n      <h1>\n        Personal profile\n      </h1>\n\n    </div>\n    <div>\n      <p>Enter your first name</p>\n      <ion-input type=\"text\" placeholder=\"Darya\" #firstName></ion-input>\n    </div>\n    <div>\n      <p>Enter your last name</p>\n      <ion-input type=\"text\" placeholder=\"Zare\" #lastName></ion-input>\n    </div>\n    <div>\n      <p>Enter your Address:</p>\n      <ion-textarea type=\"text\" placeholder=\"Tehran, Heravi square...\" #address></ion-textarea>\n    </div>\n    <div style=\"background-color: #FAFAFA;\">\n      <p>Please Specify your gender:</p>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [(ngModel)]=\"this.gender\">\n        <ion-segment-button value=\"Female\">\n          <ion-label>Female</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"Male\">\n          <ion-label>Male</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <div>\n      <p>How Old Are You?</p>\n      <ion-select placeholder=\"25\" [(ngModel)]=\"this.age\">\n        <ion-select-option *ngFor=\"let number of [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139]\">{{number}}</ion-select-option>\n    </ion-select>\n    </div>\n\n\n\n    <form #userdata = \"ngForm\" (ngSubmit) = \"onClickSubmit()\" >\n    <div style=\"background-color: #FAFAFA;\">\n      <p><br>1.have you gotten covid 19?</p>\n      <ion-segment #covidHistory (ionChange)=\"segmentChanged($event)\" [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"covidRecord\">\n        <ion-segment-button value=\"Yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"No\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <div style=\"background-color: #FAFAFA;\">\n      <p>2.Did you have respiratory disease?</p>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"respiratory\">\n        <ion-segment-button value=\"Yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"No\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <div style=\"background-color: #FAFAFA;\">\n      <p>3.Did you have infectious disease?</p>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"infectious\">\n        <ion-segment-button value=\"Yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"No\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <div style=\"background-color: #FAFAFA;\">\n      <p>3.Did you have cardiovascular disease?</p>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"cardiovascular\">\n        <ion-segment-button value=\"Yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"No\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <div style=\"background-color: #FAFAFA;\">\n      <p>4.Did you have cancer before?</p>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"cancer\">\n        <ion-segment-button value=\"Yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"No\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <div style=\"background-color: #FAFAFA;\">\n      <p>5.Did you have immunological disease?</p>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"immunological\">\n        <ion-segment-button value=\"Yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"No\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <div style=\"background-color: #FAFAFA;\">\n      <p>6.Did you have Diabetes before?</p>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"diabetes\">\n        <ion-segment-button value=\"Yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"No\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <div style=\"background-color: #FAFAFA;\">\n      <p>7.Are you a member of the medical staff?</p>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"medical\">\n        <ion-segment-button value=\"Yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"No\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <div style=\"background-color: #FAFAFA;\">\n      <p>8.Have you ever lived in a high-risk infectious area? </p>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"infectiousArea\">\n        <ion-segment-button value=\"Yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"No\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <div style=\"background-color: #FAFAFA;\">\n      <p>9.Do you have a pet?</p>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [ngModelOptions]=\"{standalone: true}\" [(ngModel)]=\"pet\">\n        <ion-segment-button value=\"Yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"No\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </div>\n    <ion-button expand=\"block\" shape='round' clearInput type =\"submit\" value = \"submit\">Submit/Edit</ion-button>\n\n    </form>\n\n</ion-content>\n");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map