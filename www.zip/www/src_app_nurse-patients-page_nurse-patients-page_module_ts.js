(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_nurse-patients-page_nurse-patients-page_module_ts"],{

/***/ 9719:
/*!***************************************************************************!*\
  !*** ./src/app/nurse-patients-page/nurse-patients-page-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NursePatientsPagePageRoutingModule": () => (/* binding */ NursePatientsPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _nurse_patients_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nurse-patients-page.page */ 2609);




const routes = [
    {
        path: '',
        component: _nurse_patients_page_page__WEBPACK_IMPORTED_MODULE_0__.NursePatientsPagePage
    }
];
let NursePatientsPagePageRoutingModule = class NursePatientsPagePageRoutingModule {
};
NursePatientsPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NursePatientsPagePageRoutingModule);



/***/ }),

/***/ 1278:
/*!*******************************************************************!*\
  !*** ./src/app/nurse-patients-page/nurse-patients-page.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NursePatientsPagePageModule": () => (/* binding */ NursePatientsPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _nurse_patients_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nurse-patients-page-routing.module */ 9719);
/* harmony import */ var _nurse_patients_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nurse-patients-page.page */ 2609);







let NursePatientsPagePageModule = class NursePatientsPagePageModule {
};
NursePatientsPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _nurse_patients_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.NursePatientsPagePageRoutingModule
        ],
        declarations: [_nurse_patients_page_page__WEBPACK_IMPORTED_MODULE_1__.NursePatientsPagePage]
    })
], NursePatientsPagePageModule);



/***/ }),

/***/ 2609:
/*!*****************************************************************!*\
  !*** ./src/app/nurse-patients-page/nurse-patients-page.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NursePatientsPagePage": () => (/* binding */ NursePatientsPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_nurse_patients_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./nurse-patients-page.page.html */ 5191);
/* harmony import */ var _nurse_patients_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nurse-patients-page.page.scss */ 2294);
/* harmony import */ var _nurse_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../nurse.service */ 337);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);






let NursePatientsPagePage = class NursePatientsPagePage {
    constructor(dc, modalController) {
        this.dc = dc;
        this.modalController = modalController;
        this.myDict = { true: 'Yes', false: 'No', null: 'Not filled yet' };
    }
    ngOnInit() {
    }
};
NursePatientsPagePage.ctorParameters = () => [
    { type: _nurse_service__WEBPACK_IMPORTED_MODULE_2__.NurseService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController }
];
NursePatientsPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-nurse-patients-page',
        template: _raw_loader_nurse_patients_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_nurse_patients_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], NursePatientsPagePage);



/***/ }),

/***/ 2294:
/*!*******************************************************************!*\
  !*** ./src/app/nurse-patients-page/nurse-patients-page.page.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("h1, ion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 17px;\n}\n\nh2, ion-list-header {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 13px;\n}\n\nh3 {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 10px;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 15px;\n}\n\n.profile {\n  text-align: center;\n  background-color: white;\n  margin-right: 5%;\n  margin-left: 5%;\n  margin-top: 4%;\n  margin-bottom: 4%;\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(108, 235, 58, 0.6);\n  backdrop-filter: blur(1.2px);\n  -webkit-backdrop-filter: blur(1.2px);\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  border-radius: 7%;\n}\n\nion-item {\n  border-radius: 5%;\n}\n\nion-searchbar {\n  border-radius: 20px;\n}\n\nion-list-header {\n  font-size: 15px;\n}\n\n.answer {\n  font-family: \"QanelasUltraLight\";\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51cnNlLXBhdGllbnRzLXBhZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBQUY7O0FBRUE7RUFDRSx3Q0FBQTtFQUNBLGVBQUE7QUFDRjs7QUFDQTtFQUNFLHdDQUFBO0VBQ0EsZUFBQTtBQUVGOztBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGdCQUFBO0FBR0Y7O0FBREE7RUFDRSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBRUEsb0NBQUE7RUFDQSxnREFBQTtFQUNBLDRCQUFBO0VBQ0Esb0NBQUE7RUFDQSwyQ0FBQTtFQUNBLGlCQUFBO0FBR0Y7O0FBQUE7RUFDRSxpQkFBQTtBQUdGOztBQURBO0VBQ0UsbUJBQUE7QUFJRjs7QUFGQTtFQUNFLGVBQUE7QUFLRjs7QUFIQTtFQUNFLGdDQUFBO0FBTUYiLCJmaWxlIjoibnVyc2UtcGF0aWVudHMtcGFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaDEsaW9uLXRpdGxle1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxN3B4O1xyXG59XHJcbmgyLGlvbi1saXN0LWhlYWRlcntcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhLWJvbGQnLCBjdXJzaXZlO1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxufVxyXG5oM3tcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhLWJvbGQnLCBjdXJzaXZlO1xyXG4gIGZvbnQtc2l6ZTogMTBweDtcclxufVxyXG5we1xyXG4gIGNvbG9yOiAjODY4Njg2ZGM7XHJcbiAgZm9udC1mYW1pbHk6ICdRYW5lbGFzVWx0cmFMaWdodCc7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4ucHJvZmlsZXtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgbWFyZ2luLXRvcDogNCU7XHJcbiAgbWFyZ2luLWJvdHRvbTogNCU7XHJcblxyXG4gIGJhY2tncm91bmQ6IHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuNiApO1xyXG4gIGJveC1zaGFkb3c6IDAgOHB4IDMycHggMCByZ2JhKDEwOCwgMjM1LCA1OCwgMC42KTtcclxuICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDEuMnB4ICk7XHJcbiAgLXdlYmtpdC1iYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDEuMnB4ICk7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSggMjU1LCAyNTUsIDI1NSwgMC4xOCApO1xyXG4gIGJvcmRlci1yYWRpdXM6IDclO1xyXG5cclxufVxyXG5pb24taXRlbXtcclxuICBib3JkZXItcmFkaXVzOiA1JTtcclxufVxyXG5pb24tc2VhcmNoYmFye1xyXG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbn1cclxuaW9uLWxpc3QtaGVhZGVye1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG4uYW5zd2Vye1xyXG4gIGZvbnQtZmFtaWx5OiAnUWFuZWxhc1VsdHJhTGlnaHQnO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 5191:
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/nurse-patients-page/nurse-patients-page.page.html ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"nurse-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Patients</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen>\n\n\n\n  <ion-list>\n\n  <div *ngFor=\"let patient of this.dc.patients_list\">\n\n    <ion-card>\n      <ion-item style=\"font-family: PlusJakarta-bold;\">\n\n        <ion-label style=\"text-align: center;font-family: PlusJakarta-bold; \">\n          <ion-avatar slot=\"start\" style=\"text-align: center;margin-left:35%;\n          margin-right:30%; margin-bottom:7px;font-family:PlusJakarta \">\n          <img src=\"https://ui-avatars.com/api/background=17D7A0&color=fff?name={{patient.user.fname}}+{{patient.user.lname}}?\">\n        </ion-avatar>\n        {{patient.user.fname}} {{patient.user.lname}}</ion-label>\n      </ion-item>\n      <ion-card-content>\n        <h2>Covid Record: <div class=\"answer\">{{myDict[patient.covid_19]}}</div></h2>\n        <h2>Cancer Record: <div class=\"answer\">{{myDict[patient.cancer]}}</div></h2>\n        <h2>Being in dangerous area Record: <div class=\"answer\">{{myDict[patient.dangerous_area]}}</div></h2>\n        <h2>Diabetes Record: <div class=\"answer\">{{myDict[patient.diabetes]}}</div></h2>\n        <h2>Immunological disease Record: <div class=\"answer\">{{myDict[patient.imuloical]}}</div></h2>\n        <h2>Living in infectious area: <div class=\"answer\">{{myDict[patient.infectious]}}</div></h2>\n        <h2>Having pet Record: <div class=\"answer\">{{myDict[patient.pet]}}</div></h2>\n        <h2>Respiratory disease Record: <div class=\"answer\">{{myDict[patient.respiratory]}}</div></h2>\n        <h2>Vascular disease Record: <div class=\"answer\">{{myDict[patient.vascular]}}</div></h2>\n\n      </ion-card-content>\n    </ion-card>\n\n\n\n\n  </div>\n\n</ion-list>\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_nurse-patients-page_nurse-patients-page_module_ts.js.map