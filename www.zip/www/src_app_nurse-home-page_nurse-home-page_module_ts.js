(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_nurse-home-page_nurse-home-page_module_ts"],{

/***/ 5251:
/*!*******************************************************************!*\
  !*** ./src/app/nurse-home-page/nurse-home-page-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NurseHomePagePageRoutingModule": () => (/* binding */ NurseHomePagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _nurse_home_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nurse-home-page.page */ 1736);




const routes = [
    {
        path: '',
        component: _nurse_home_page_page__WEBPACK_IMPORTED_MODULE_0__.NurseHomePagePage
    }
];
let NurseHomePagePageRoutingModule = class NurseHomePagePageRoutingModule {
};
NurseHomePagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NurseHomePagePageRoutingModule);



/***/ }),

/***/ 2562:
/*!***********************************************************!*\
  !*** ./src/app/nurse-home-page/nurse-home-page.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NurseHomePagePageModule": () => (/* binding */ NurseHomePagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _nurse_home_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nurse-home-page-routing.module */ 5251);
/* harmony import */ var _nurse_home_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nurse-home-page.page */ 1736);







let NurseHomePagePageModule = class NurseHomePagePageModule {
};
NurseHomePagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _nurse_home_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.NurseHomePagePageRoutingModule
        ],
        declarations: [_nurse_home_page_page__WEBPACK_IMPORTED_MODULE_1__.NurseHomePagePage]
    })
], NurseHomePagePageModule);



/***/ }),

/***/ 1736:
/*!*********************************************************!*\
  !*** ./src/app/nurse-home-page/nurse-home-page.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NurseHomePagePage": () => (/* binding */ NurseHomePagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_nurse_home_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./nurse-home-page.page.html */ 1426);
/* harmony import */ var _nurse_home_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nurse-home-page.page.scss */ 3405);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _nurse_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../nurse.service */ 337);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../error-controller.service */ 4898);



/* eslint-disable @typescript-eslint/dot-notation */
/* eslint-disable object-shorthand */
/* eslint-disable @typescript-eslint/naming-convention */






let NurseHomePagePage = class NurseHomePagePage {
    constructor(router, http, nurse_service, ErrorCont) {
        this.router = router;
        this.http = http;
        this.nurse_service = nurse_service;
        this.ErrorCont = ErrorCont;
        // eslint-disable-next-line quote-props
        this.dict = { 'true': true, 'false': false, '': false, 1: true, 0: false };
        // eslint-disable-next-line @typescript-eslint/naming-convention
        this.profile_is_complete = this.dict[localStorage.getItem('profile_completed')];
        this.cv_accepted = false;
        this.document_accepted = false;
        this.app_token = '';
        this.patients_number = 0;
        this.prescriptions_number = 0;
    }
    edit_button_clicked() {
        this.router.navigate(['nurse-upload-page']);
    }
    logout_clicked() {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.app_token,
        });
        const options = { headers: headers };
        this.http.delete('https://habco.rshayanfar.ir/habco/token', options).toPromise().then(resp => {
            localStorage.removeItem('app-token');
            this.router.navigate(['welcome']);
        }).catch(error => {
            this.ErrorCont.showError(error);
        });
        ;
    }
    doc_and_cv_status() {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.app_token,
        });
        const options = { headers: headers };
        this.http.get('https://habco.rshayanfar.ir/habco/user', options).toPromise().then(resp => {
            localStorage.setItem('user_id', resp['data']['id']);
        }).catch(error => {
            this.ErrorCont.showError(error);
        });
        if (localStorage.getItem('user_id')) {
            this.http.get('https://habco.rshayanfar.ir/habco/nurse/'
                + localStorage.getItem('user_id').toString(), options).toPromise().then(resp => {
                this.cv_id = resp['data']['cv_id'];
                this.document_id = resp['data']['document_id'];
                this.http.get('https://habco.rshayanfar.ir/habco/document/' + this.document_id, options).toPromise().then(rest => {
                    this.document_accepted = this.dict[rest['data']['verified']];
                }).catch(error => {
                    this.ErrorCont.showError(error);
                });
                this.http.get('https://habco.rshayanfar.ir/habco/document/' + this.cv_id, options).toPromise().then(response => {
                    this.cv_accepted = this.dict[response['data']['verified']];
                }).catch(error => {
                    this.ErrorCont.showError(error);
                });
            }).catch(error => {
                this.ErrorCont.showError(error);
            });
        }
    }
    get_patients() {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.app_token,
        });
        const options = { headers: headers };
        this.http.get('https://habco.rshayanfar.ir/habco/patient', options).toPromise().then(resp => {
            this.nurse_service.patients_list = resp['data'];
            this.patients_number = this.nurse_service.patients_list.length;
        }).catch(error => {
            this.ErrorCont.showError(error);
        });
    }
    get_prescriptions() {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.app_token,
        });
        const options = { headers: headers };
        this.http.get('https://habco.rshayanfar.ir/habco/prescription', options).toPromise().then(resp => {
            console.log(resp);
            this.nurse_service.prescriptions_list = resp['data'];
            this.prescriptions_number = this.nurse_service.prescriptions_list.length;
        }).catch(error => {
            this.ErrorCont.showError(error);
        });
    }
    ionViewWillEnter() {
        this.app_token = localStorage.getItem('app-token');
        this.doc_and_cv_status();
        this.get_patients();
        this.get_prescriptions();
    }
    patients_clicked() {
        this.router.navigate(['nurse-patients-page']);
    }
    prescriptions_clicked() {
        this.router.navigate(['nurse-prescription-page']);
    }
    ngOnInit() {
    }
};
NurseHomePagePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _nurse_service__WEBPACK_IMPORTED_MODULE_2__.NurseService },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_3__.ErrorControllerService }
];
NurseHomePagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-nurse-home-page',
        template: _raw_loader_nurse_home_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_nurse_home_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], NurseHomePagePage);



/***/ }),

/***/ 3405:
/*!***********************************************************!*\
  !*** ./src/app/nurse-home-page/nurse-home-page.page.scss ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("h1 {\n  font-family: \"PlusJakarta-bold\";\n  font-size: 15px;\n  text-align: center;\n  font-weight: 100;\n}\n\nh2 {\n  font-family: \"PlusJakarta\";\n  font-size: 13px;\n  text-align: center;\n  font-weight: 100;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 4%;\n  text-align: center;\n}\n\nion-content {\n  --ion-background-color: linear-gradient(to top, #34e67e, #abf853 80%);\n}\n\n.welcome-border {\n  background-color: white;\n  margin-right: 10%;\n  margin-left: 10%;\n  padding-bottom: 10%;\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  margin-top: 10%;\n}\n\n.profile-status-messsage {\n  text-align: left;\n  margin-left: 10%;\n  font-size: 15px;\n}\n\n.profile-status {\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  margin-left: 10%;\n  margin-right: 10%;\n  margin-top: 5%;\n}\n\n.item {\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  height: 40%;\n  width: 40%;\n  margin: 8px 5px 0px 3px;\n  padding-bottom: 6%;\n}\n\n.flex-container {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  height: 40%;\n  margin-left: 5%;\n  margin-right: 5%;\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n\n.item-title {\n  margin-top: 3px;\n}\n\n.sec_flex-container {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  margin-left: 10%;\n  margin-right: 10%;\n  margin-top: 10px;\n}\n\n.image {\n  height: 40px;\n  width: 40px;\n  margin-bottom: 4px;\n  text-align: center;\n  margin-left: 27%;\n}\n\n.logout {\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  height: 30%;\n  width: 40%;\n  margin: 5px 0px 0px 3px;\n  padding-bottom: 2%;\n}\n\nion-toolbar {\n  --background: #abf853;\n}\n\nion-title {\n  font-family: AquireBold;\n  font-size: 25px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51cnNlLWhvbWUtcGFnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRSwrQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBQUY7O0FBRUE7RUFDRSwwQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxnQkFBQTtFQUNBLGdDQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBRUY7O0FBRUE7RUFDRSxxRUFBQTtBQUNGOztBQUNBO0VBQ0UsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxvQ0FBQTtFQUNGLGdEQUFBO0VBQ0EsNEJBQUE7RUFDQSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsMkNBQUE7RUFDQSxlQUFBO0FBRUE7O0FBQUE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUdGOztBQURBO0VBQ0Usb0NBQUE7RUFDQSxnREFBQTtFQUNBLDRCQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQkFBQTtFQUNBLDJDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFJRjs7QUFEQTtFQUNFLG9DQUFBO0VBQ0EsZ0RBQUE7RUFDQSw0QkFBQTtFQUNBLG9DQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQ0FBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQUlGOztBQUZBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFLRjs7QUFIQTtFQUNFLGVBQUE7QUFNRjs7QUFIQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFNRjs7QUFIQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBTUY7O0FBSkE7RUFDRSxvQ0FBQTtFQUNBLGdEQUFBO0VBQ0EsNEJBQUE7RUFDQSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsMkNBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUFPRjs7QUFMQTtFQUNFLHFCQUFBO0FBUUY7O0FBTEE7RUFDRSx1QkFBQTtFQUNBLGVBQUE7QUFRRiIsImZpbGUiOiJudXJzZS1ob21lLXBhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmgxe1xyXG4gIGZvbnQtZmFtaWx5OiBcIlBsdXNKYWthcnRhLWJvbGRcIjtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtd2VpZ2h0OiAxMDA7XHJcbn1cclxuaDJ7XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGFcIjtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtd2VpZ2h0OiAxMDA7XHJcbn1cclxucHtcclxuICBjb2xvcjogIzg2ODY4NmRjO1xyXG4gIGZvbnQtZmFtaWx5OiAnUWFuZWxhc1VsdHJhTGlnaHQnO1xyXG4gIG1hcmdpbi10b3A6IDQlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbn1cclxuXHJcbmlvbi1jb250ZW50e1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byB0b3AsICMzNGU2N2UsICNhYmY4NTMgODAlKTtcclxufVxyXG4ud2VsY29tZS1ib3JkZXJ7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICBwYWRkaW5nLWJvdHRvbTogMTAlO1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuNiApO1xyXG5ib3gtc2hhZG93OiAwIDhweCAzMnB4IDAgcmdiYSggMzEsIDM4LCAxMzUsIDAuMzcgKTtcclxuYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4td2Via2l0LWJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuYm9yZGVyLXJhZGl1czogMTBweDtcclxuYm9yZGVyOiAxcHggc29saWQgcmdiYSggMjU1LCAyNTUsIDI1NSwgMC4xOCApO1xyXG5tYXJnaW4tdG9wOiAxMCU7XHJcbn1cclxuLnByb2ZpbGUtc3RhdHVzLW1lc3NzYWdle1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbn1cclxuLnByb2ZpbGUtc3RhdHVze1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuNiApO1xyXG4gIGJveC1zaGFkb3c6IDAgOHB4IDMycHggMCByZ2JhKCAzMSwgMzgsIDEzNSwgMC4zNyApO1xyXG4gIGJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuICAtd2Via2l0LWJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuMTggKTtcclxuICBtYXJnaW4tbGVmdDogMTAlO1xyXG4gIG1hcmdpbi1yaWdodDogMTAlO1xyXG4gIG1hcmdpbi10b3A6IDUlO1xyXG4gIH1cclxuXHJcbi5pdGVte1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuNiApO1xyXG4gIGJveC1zaGFkb3c6IDAgOHB4IDMycHggMCByZ2JhKCAzMSwgMzgsIDEzNSwgMC4zNyApO1xyXG4gIGJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuICAtd2Via2l0LWJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuMTggKTtcclxuICBoZWlnaHQ6IDQwJTtcclxuICB3aWR0aDogNDAlO1xyXG4gIG1hcmdpbjo4cHggNXB4IDBweCAzcHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDYlO1xyXG59XHJcbi5mbGV4LWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmbGV4LXdyYXA6d3JhcDtcclxuICBoZWlnaHQ6IDQwJTtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcbi5pdGVtLXRpdGxle1xyXG4gIG1hcmdpbi10b3A6IDNweDtcclxuXHJcbn1cclxuLnNlY19mbGV4LWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmbGV4LXdyYXA6d3JhcDtcclxuICBtYXJnaW4tbGVmdDogMTAlO1xyXG4gIG1hcmdpbi1yaWdodDogMTAlO1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcbi5pbWFnZXtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW4tbGVmdDogMjclO1xyXG59XHJcbi5sb2dvdXR7XHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC42ICk7XHJcbiAgYm94LXNoYWRvdzogMCA4cHggMzJweCAwIHJnYmEoIDMxLCAzOCwgMTM1LCAwLjM3ICk7XHJcbiAgYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4gIC13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSggMjU1LCAyNTUsIDI1NSwgMC4xOCApO1xyXG4gIGhlaWdodDogMzAlO1xyXG4gIHdpZHRoOiA0MCU7XHJcbiAgbWFyZ2luOjVweCAwcHggMHB4IDNweDtcclxuICBwYWRkaW5nLWJvdHRvbTogMiU7XHJcbn1cclxuaW9uLXRvb2xiYXIge1xyXG4gIC0tYmFja2dyb3VuZDogI2FiZjg1MztcclxuXHJcbn1cclxuaW9uLXRpdGxle1xyXG4gIGZvbnQtZmFtaWx5OkFxdWlyZUJvbGQgO1xyXG4gIGZvbnQtc2l6ZTogMjVweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 1426:
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/nurse-home-page/nurse-home-page.page.html ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Habco</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-fab horizontal=\"end\" vertical=\"top\" slot=\"fixed\" edge>\n    <ion-fab-button>\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n    <ion-fab-list>\n      <ion-fab-button color=\"light\">\n        <ion-icon name=\"logo-facebook\"></ion-icon>\n      </ion-fab-button>\n      <ion-fab-button color=\"light\">\n        <ion-icon name=\"logo-twitter\"></ion-icon>\n      </ion-fab-button>\n      <ion-fab-button color=\"light\">\n        <ion-icon name=\"logo-vimeo\"></ion-icon>\n      </ion-fab-button>\n    </ion-fab-list>\n  </ion-fab>\n    <div class='welcome-border'>\n\n      <h2>Welcome ,you are logged in as a <h1>Nurse</h1> </h2>\n    </div>\n\n    <div class='profile-status' (click)=\"edit_button_clicked()\">\n      <h1 class=\"profile-status-messsage\">Your profile status:</h1>\n      <div>\n        <h2 class=\"profile-status-messsage\">Your cv status:\n          <div class=\"incomplete\" *ngIf=\"!cv_accepted\">\n            <div style=\"text-align: left;font-size:13px;margin-top:10px\">\n              <b style=\"color: rgb(199, 40, 40);\">Not accepted yet</b>\n\n            </div>\n          </div>\n          <div class=\"complete\" *ngIf=\"cv_accepted\">\n            <div style=\"text-align: left;font-size:13px;margin-top:10px\">\n              <ion-icon slot=\"end\" name=\"checkmark-circle\" style=\"color: green;margin-right:4px;\"></ion-icon>\n              <b style=\"color: rgb(14, 165, 64);\">Accepted</b>\n\n            </div>\n\n\n          </div>\n        </h2>\n\n        <h2 class=\"profile-status-messsage\">Your document status:\n          <div class=\"incomplete\" *ngIf=\"!document_accepted\">\n            <div style=\"text-align: left;font-size:13px;margin-top:10px\">\n              <b style=\"color: rgb(199, 40, 40);\">Not accepted yet</b>\n\n            </div>\n            <div style=\"text-align: center; margin-right:7%;\">\n\n            <h2 style=\"text-align: center;font-size:12px;\">Click here to complete your profile</h2>\n            </div>\n          </div>\n          <div class=\"complete\" *ngIf=\"document_accepted\">\n            <div style=\"text-align: left;font-size:13px;margin-top:10px\">\n              <ion-icon slot=\"end\" name=\"checkmark-circle\" style=\"color: green;margin-right:4px;\"></ion-icon>\n              <b style=\"color: rgb(14, 165, 64);\">Accepted</b>\n\n            </div>\n            <div style=\"text-align: center;margin-right:8%;\">\n              <h2 style=\"text-align: center;font-size:12px;\">Click <a>here</a> to change your profile and upload your cv</h2>\n\n            </div>\n\n          </div>\n        </h2>\n      </div>\n\n    </div>\n\n    <div class=\"flex-container\">\n\n      <div class =\"item\" (click)=\"patients_clicked()\">\n        <ion-badge color=\"tertiary\">{{this.patients_number}}</ion-badge>\n\n        <div class=\"image\">\n\n          <img src=\"/assets/patient-logo.png\" alt=\"\">\n        </div>\n        <h1 style=\"font-size: 11px;margin-top:3px;\">My Patients</h1>\n      </div>\n\n      <div class =\"item\" (click)=\"prescriptions_clicked()\" >\n        <ion-badge color=\"tertiary\">{{this.prescriptions_number}}</ion-badge>\n        <div class=\"image\">\n          <img src=\"/assets/prescription-logo.png\" alt=\"\">\n        </div>\n        <h1 style=\"font-size: 11px;margin-top:3px;\">Prescriptions\n        </h1>\n      </div>\n\n      <div class =\"logout\" (click)=\"logout_clicked()\">\n        <div class=\"image\">\n          <img src=\"/assets/logout.png\" alt=\"\">\n        </div>\n        <h1 style=\"font-size: 11px;margin-top:3px;\">Logout\n        </h1>\n      </div>\n    </div>\n\n</ion-content>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_nurse-home-page_nurse-home-page_module_ts.js.map