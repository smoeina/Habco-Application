(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_user-nurses-page_user-nurses-page_module_ts"],{

/***/ 5147:
/*!*********************************************************************!*\
  !*** ./src/app/user-nurses-page/user-nurses-page-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserNursesPagePageRoutingModule": () => (/* binding */ UserNursesPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _user_nurses_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-nurses-page.page */ 5150);




const routes = [
    {
        path: '',
        component: _user_nurses_page_page__WEBPACK_IMPORTED_MODULE_0__.UserNursesPagePage
    }
];
let UserNursesPagePageRoutingModule = class UserNursesPagePageRoutingModule {
};
UserNursesPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UserNursesPagePageRoutingModule);



/***/ }),

/***/ 3759:
/*!*************************************************************!*\
  !*** ./src/app/user-nurses-page/user-nurses-page.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserNursesPagePageModule": () => (/* binding */ UserNursesPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _user_nurses_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-nurses-page-routing.module */ 5147);
/* harmony import */ var _user_nurses_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-nurses-page.page */ 5150);







let UserNursesPagePageModule = class UserNursesPagePageModule {
};
UserNursesPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _user_nurses_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserNursesPagePageRoutingModule
        ],
        declarations: [_user_nurses_page_page__WEBPACK_IMPORTED_MODULE_1__.UserNursesPagePage]
    })
], UserNursesPagePageModule);



/***/ }),

/***/ 5150:
/*!***********************************************************!*\
  !*** ./src/app/user-nurses-page/user-nurses-page.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserNursesPagePage": () => (/* binding */ UserNursesPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_user_nurses_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./user-nurses-page.page.html */ 6668);
/* harmony import */ var _user_nurses_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-nurses-page.page.scss */ 750);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../error-controller.service */ 4898);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);



/* eslint-disable @typescript-eslint/dot-notation */

/* eslint-disable @typescript-eslint/naming-convention */




let UserNursesPagePage = class UserNursesPagePage {
    constructor(router, http, errorController, alertController) {
        this.router = router;
        this.http = http;
        this.errorController = errorController;
        this.alertController = alertController;
        this.app_token = '';
        this.have_my_nurse = false;
        this.have_of_nurses = false;
    }
    ngOnInit() {
        this.app_token = localStorage.getItem('app-token');
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            Authorization: 'Bearer ' + this.app_token,
        });
        const options = { headers };
        this.http.get('https://habco.rshayanfar.ir/habco/nurse', options).toPromise().then(resp => {
            console.log(resp);
            this.nurses_list = resp['data'];
            if (this.nurses_list.length > 0) {
                this.have_of_nurses = true;
            }
            console.log(this.nurses_list);
        }).catch(error => {
            console.log('Error');
            this.errorController.showError(error);
        });
        this.http.get('https://habco.rshayanfar.ir/habco/patient/nurse', options).toPromise().then(resp => {
            console.log(resp);
            this.my_nurses = resp['data'];
            if (this.my_nurses.length > 0) {
                this.have_my_nurse = true;
            }
        }).catch(error => {
            console.log('Error');
            this.errorController.showError(error);
        });
    }
    select_nurse(nurse) {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.app_token,
        });
        const options = { headers };
        console.log(this.app_token);
        this.alertController.create({
            header: 'Confirm Alert',
            subHeader: 'Select Doctor',
            message: 'Are you sure? you want Select ' + nurse.lname + ' as your doctor?',
            buttons: [
                {
                    text: 'No',
                    handler: () => {
                        console.log('I care about humanity');
                    }
                },
                {
                    text: 'Yes',
                    handler: () => {
                        this.http.post('https://habco.rshayanfar.ir/habco/patient/nurse/' + nurse.id, {}, options).toPromise().then(resp => {
                            console.log(resp);
                            this.http.get('https://habco.rshayanfar.ir/habco/patient/nurse', options).toPromise().then(response => {
                                console.log(response);
                                this.my_nurses = response['data'];
                            }).catch(error => {
                                console.log('Error');
                                this.errorController.showError(error);
                            });
                        }).catch(error => {
                            console.log('Error');
                            this.errorController.showError(error);
                        });
                    }
                }
            ]
        }).then(res => {
            res.present();
        });
    }
    whats_app_clicked(nurse) {
        window.open('https://wa.me/' + nurse.user.phone);
    }
};
UserNursesPagePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController }
];
UserNursesPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-user-nurses-page',
        template: _raw_loader_user_nurses_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_user_nurses_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], UserNursesPagePage);



/***/ }),

/***/ 750:
/*!*************************************************************!*\
  !*** ./src/app/user-nurses-page/user-nurses-page.page.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 17px;\n}\n\nh2, ion-list-header {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 13px;\n}\n\nh3 {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 10px;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 15px;\n}\n\n.profile {\n  text-align: center;\n  margin-right: 5%;\n  margin-left: 5%;\n  margin-top: 4%;\n  margin-bottom: 4%;\n  border-style: groove;\n  background: rgba(255, 255, 255, 0.7);\n  box-shadow: 2px 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 3px solid rgba(255, 255, 255, 0.3);\n}\n\nion-item {\n  border-radius: 5%;\n}\n\nion-list-header {\n  font-size: 15px;\n}\n\nion-content {\n  --ion-background-color: linear-gradient(to top, #34e67e, #abf853 80%);\n}\n\nion-toolbar {\n  --background: #abf853;\n}\n\nh1 {\n  font-family: \"PlusJakarta\", cursive;\n  font-size: 17px;\n  margin-top: 10%;\n  width: 80%;\n  margin-left: 10%;\n  margin-right: 10%;\n}\n\nion-list {\n  border-bottom-color: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItbnVyc2VzLXBhZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBQ0E7RUFDRSx3Q0FBQTtFQUNBLGVBQUE7QUFFRjs7QUFBQTtFQUNFLHdDQUFBO0VBQ0EsZUFBQTtBQUdGOztBQURBO0VBQ0UsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGdCQUFBO0FBSUY7O0FBRkE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0VBQ0Esb0NBQUE7RUFFRixrREFBQTtFQUNBLDRCQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0FBSUE7O0FBREE7RUFDRSxpQkFBQTtBQUlGOztBQURBO0VBQ0UsZUFBQTtBQUlGOztBQUZBO0VBQ0UscUVBQUE7QUFLRjs7QUFIQTtFQUNFLHFCQUFBO0FBTUY7O0FBSEE7RUFDRSxtQ0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFNRjs7QUFKQTtFQUNFLGdDQUFBO0FBT0YiLCJmaWxlIjoidXNlci1udXJzZXMtcGFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdGl0bGV7XHJcbiAgZm9udC1mYW1pbHk6ICdQbHVzSmFrYXJ0YS1ib2xkJywgY3Vyc2l2ZTtcclxuICBmb250LXNpemU6IDE3cHg7XHJcbn1cclxuaDIsaW9uLWxpc3QtaGVhZGVye1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG59XHJcbmgze1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxMHB4O1xyXG59XHJcbnB7XHJcbiAgY29sb3I6ICM4Njg2ODZkYztcclxuICBmb250LWZhbWlseTogJ1FhbmVsYXNVbHRyYUxpZ2h0JztcclxuICBtYXJnaW4tdG9wOiAxNXB4O1xyXG59XHJcbi5wcm9maWxle1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxuICBtYXJnaW4tdG9wOiA0JTtcclxuICBtYXJnaW4tYm90dG9tOiA0JTtcclxuICBib3JkZXItc3R5bGU6Z3Jvb3ZlO1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuNyApO1xyXG5cclxuYm94LXNoYWRvdzogMnB4IDhweCAzMnB4IDAgcmdiYSggMzEsIDM4LCAxMzUsIDAuMzcgKTtcclxuYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4td2Via2l0LWJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuYm9yZGVyLXJhZGl1czogMTBweDtcclxuYm9yZGVyOiAzcHggc29saWQgcmdiYSggMjU1LCAyNTUsIDI1NSwgMC4zICk7XHJcblxyXG59XHJcbmlvbi1pdGVte1xyXG4gIGJvcmRlci1yYWRpdXM6IDUlO1xyXG59XHJcblxyXG5pb24tbGlzdC1oZWFkZXJ7XHJcbiAgZm9udC1zaXplOiAxNXB4O1xyXG59XHJcbmlvbi1jb250ZW50e1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byB0b3AsICMzNGU2N2UsICNhYmY4NTMgODAlKTtcclxufVxyXG5pb24tdG9vbGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjYWJmODUzO1xyXG5cclxufVxyXG5oMXtcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhJywgY3Vyc2l2ZTtcclxuICBmb250LXNpemU6IDE3cHg7XHJcbiAgbWFyZ2luLXRvcDogMTAlO1xyXG4gIHdpZHRoOiA4MCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDEwJTtcclxufVxyXG5pb24tbGlzdHtcclxuICBib3JkZXItYm90dG9tLWNvbG9yOiB0cmFuc3BhcmVudDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 6668:
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/user-nurses-page/user-nurses-page.page.html ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"user-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Nurses</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen>\n\n  <ion-list>\n    <ion-list-header>\n      My Nurses\n    </ion-list-header>\n    <h1 *ngIf=\"!this.have_my_nurse\">You have not select a nurse yet</h1>\n\n\n    <div *ngFor=\"let nurse of this.my_nurses\">\n      <div class=\"profile\">\n        <ion-item lines=\"none\" no-lines>\n          <ion-avatar slot=\"start\">\n            <img src=\"https://ui-avatars.com/api/background=17D7A0&color=fff?name={{nurse.user.fname}}+{{nurse.user.lname}}?\">\n          </ion-avatar>\n          <ion-label>\n            <h2>{{nurse.user.fname}} {{nurse.user.lname}}</h2>\n            <h3>{{nurse.specialization}}</h3>\n          </ion-label>\n          <ion-icon name=\"chatbubbles-sharp\" slot=\"end\" (click)=\"whats_app_clicked(nurse)\"></ion-icon>\n        </ion-item>\n      </div>\n    </div>\n  </ion-list>\n\n\n\n\n\n\n\n  <ion-list>\n    <ion-list-header>\n      All Nurses\n    </ion-list-header>\n    <h1 *ngIf=\"!this.have_of_nurses\">There is not any nurse in database :(</h1>\n\n    <div *ngFor=\"let nurse of this.nurses_list\">\n      <div class=\"profile\">\n        <ion-item lines=\"none\" no-lines>\n          <ion-avatar slot=\"start\">\n            <img src=\"https://ui-avatars.com/api/background=17D7A0&color=fff?name={{nurse.fname}}+{{nurse.lname}}?\">\n          </ion-avatar>\n          <ion-label>\n            <h2>{{nurse.fname}} {{nurse.lname}}</h2>\n            <h3>{{nurse.specialization}}</h3>\n          </ion-label>\n          <ion-icon name=\"add-circle\" slot=\"end\" #nurse_selected\n           (click)=\"select_nurse(nurse)\"></ion-icon>\n        </ion-item>\n      </div>\n    </div>\n  </ion-list>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_user-nurses-page_user-nurses-page_module_ts.js.map