(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_sms-verification_sms-verification_module_ts"],{

/***/ 25:
/*!*********************************************************************!*\
  !*** ./src/app/sms-verification/sms-verification-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SmsVerificationPageRoutingModule": () => (/* binding */ SmsVerificationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _sms_verification_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sms-verification.page */ 1530);




const routes = [
    {
        path: '',
        component: _sms_verification_page__WEBPACK_IMPORTED_MODULE_0__.SmsVerificationPage
    }
];
let SmsVerificationPageRoutingModule = class SmsVerificationPageRoutingModule {
};
SmsVerificationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SmsVerificationPageRoutingModule);



/***/ }),

/***/ 3917:
/*!*************************************************************!*\
  !*** ./src/app/sms-verification/sms-verification.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SmsVerificationPageModule": () => (/* binding */ SmsVerificationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _sms_verification_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sms-verification-routing.module */ 25);
/* harmony import */ var _sms_verification_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sms-verification.page */ 1530);







let SmsVerificationPageModule = class SmsVerificationPageModule {
};
SmsVerificationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _sms_verification_routing_module__WEBPACK_IMPORTED_MODULE_0__.SmsVerificationPageRoutingModule,
        ],
        declarations: [_sms_verification_page__WEBPACK_IMPORTED_MODULE_1__.SmsVerificationPage]
    })
], SmsVerificationPageModule);



/***/ }),

/***/ 1530:
/*!***********************************************************!*\
  !*** ./src/app/sms-verification/sms-verification.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SmsVerificationPage": () => (/* binding */ SmsVerificationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_sms_verification_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./sms-verification.page.html */ 7209);
/* harmony import */ var _sms_verification_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sms-verification.page.scss */ 3674);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../error-controller.service */ 4898);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../auth.service */ 2891);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);




/* eslint-disable @typescript-eslint/dot-notation */

/* eslint-disable @typescript-eslint/naming-convention */



let SmsVerificationPage = class SmsVerificationPage {
    constructor(authService, loadingController, router, alertController, ErrorController) {
        this.authService = authService;
        this.loadingController = loadingController;
        this.router = router;
        this.alertController = alertController;
        this.ErrorController = ErrorController;
        this.OTP = {
            first: '',
            second: '',
            third: '',
            forth: '',
        };
    }
    ngOnInit() {
    }
    checkCode() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            if (this.first_otp.value.length === 1 && this.second_otp.value.length === 1 &&
                this.third_otp.value.length === 1 && this.forth_otp.value.length === 1) {
                this.authService.sendValidationCode(this.first_otp.value.toString() + this.second_otp.value.toString()
                    + this.third_otp.value.toString() + this.forth_otp.value.toString()).toPromise().then(resp => {
                    console.log(resp);
                    loading.dismiss();
                    console.log(resp['data']['user']);
                    localStorage.setItem('user', resp['data']['user']);
                    console.log('app-token' + resp['data']['appToken']);
                    localStorage.setItem('app-token', resp['data']['appToken']);
                    if (resp['data']['user']['role'] === 'doctor') {
                        this.router.navigate(['doctor-home-page']);
                    }
                    if (resp['data']['user']['role'] === 'patient') {
                        this.router.navigate(['user-home-page']);
                    }
                    if (resp['data']['user']['role'] === 'nurse') {
                        this.router.navigate(['nurse-home-page']);
                    }
                    if (resp['data']['user']['role'] === 'admin') {
                        this.router.navigate(['admin-home']);
                    }
                    if (resp['data']['user']['role'] === 'pharmacist') {
                        this.router.navigate(['drugstore-home-page']);
                    }
                }).catch(error => {
                    console.log(error.error);
                    loading.dismiss();
                    this.ErrorController.showError(error);
                });
            }
            else {
                yield loading.dismiss();
            }
        });
    }
    otpController(event, next, prev, index) {
        if (index === 4) {
            this.checkCode();
        }
        if (event.target.value.length < 1 && prev) {
            prev.setFocus();
        }
        else if (next && event.target.value.length > 0) {
            next.setFocus();
        }
        else {
            return 0;
        }
    }
    clickLoginButton() {
        this.router.navigate(['login']);
    }
};
SmsVerificationPage.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService }
];
SmsVerificationPage.propDecorators = {
    first_otp: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['otp1',] }],
    second_otp: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['otp2',] }],
    third_otp: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['otp3',] }],
    forth_otp: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['otp4',] }]
};
SmsVerificationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-sms-verification',
        template: _raw_loader_sms_verification_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_sms_verification_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SmsVerificationPage);



/***/ }),

/***/ 3674:
/*!*************************************************************!*\
  !*** ./src/app/sms-verification/sms-verification.page.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".x {\n  display: inline-block;\n  width: 5vw;\n  margin: 2%;\n  border-radius: 50%;\n  --background:#e1e1e1;\n  text-align: center;\n  position: relative;\n  padding-bottom: 20%;\n  height: 5vw;\n}\n\n.SMS {\n  margin-top: 10%;\n  text-align: center;\n}\n\nh1, h2 {\n  font-family: \"PlusJakarta-bold\";\n  font-size: 25px;\n  text-align: center;\n  font-weight: 100;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 25px;\n  text-align: center;\n}\n\nimg {\n  text-align: center;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n  width: 40%;\n  margin-top: 15%;\n}\n\nion-input {\n  font-family: \"PlusJakarta-bold\";\n  text-align: center;\n  color: var(--ion-color-primary) !important;\n  font-weight: 700;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNtcy12ZXJpZmljYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7RUFDQSxVQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBRUE7RUFFRSxlQUFBO0VBQ0Esa0JBQUE7QUFBRjs7QUFLQTtFQUNFLCtCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFGRjs7QUFJQTtFQUNFLGdCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FBREY7O0FBSUE7RUFDRSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUFERjs7QUFHQTtFQUNFLCtCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGdCQUFBO0FBQUYiLCJmaWxlIjoic21zLXZlcmlmaWNhdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIueHtcclxuICBkaXNwbGF5OmlubGluZS1ibG9jaztcclxuICB3aWR0aDo1dnc7XHJcbiAgbWFyZ2luOjIlO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAtLWJhY2tncm91bmQ6I2UxZTFlMTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHBhZGRpbmctYm90dG9tOiAyMCU7XHJcbiAgaGVpZ2h0OiA1dnc7XHJcbiAgfVxyXG5cclxuLlNNU3tcclxuXHJcbiAgbWFyZ2luLXRvcDogMTAlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbn1cclxuXHJcblxyXG5oMSxoMntcclxuICBmb250LWZhbWlseTogXCJQbHVzSmFrYXJ0YS1ib2xkXCI7XHJcbiAgZm9udC1zaXplOiAyNXB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBmb250LXdlaWdodDogMTAwO1xyXG59XHJcbnB7XHJcbiAgY29sb3I6ICM4Njg2ODZkYztcclxuICBmb250LWZhbWlseTogJ1FhbmVsYXNVbHRyYUxpZ2h0JztcclxuICBtYXJnaW4tdG9wOiAyNXB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbn1cclxuaW1ne1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBtYXJnaW4tbGVmdDogYXV0bztcclxuICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgd2lkdGg6IDQwJTtcclxuICBtYXJnaW4tdG9wOiAxNSU7XHJcbn1cclxuaW9uLWlucHV0e1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCc7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGNvbG9yOnZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAhaW1wb3J0YW50O1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 7209:
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sms-verification/sms-verification.page.html ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n\n  <img src=\"/assets/sms-verification.png\" alt=\"\">\n  <h1>SMS Verification</h1>\n  <p>Please Enter the OTP code</p>\n  <div class=\"SMS\">\n\n    <ion-row >\n      <ion-col>\n       <ion-input class=\"x\" #otp1 required=\"true\" maxLength=\"1\" [(ngModel)] =\"OTP.first\" (keyup)=\"otpController($event,otp2,'',1)\">\n       </ion-input>\n       <ion-input class=\"x\" #otp2 required=\"true\" maxLength=\"1\" [(ngModel)]=\"OTP.second\" (keyup)=\"otpController($event,otp3,otp1,2)\">\n       </ion-input>\n       <ion-input class=\"x\" #otp3 required=\"true\" maxLength=\"1\" [(ngModel)]=\"OTP.third\"  (keyup)=\"otpController($event,otp4,otp2,3)\">\n       </ion-input>\n\n       <ion-input class=\"x\" #otp4 required=\"true\" maxLength=\"1\" [(ngModel)]=\"OTP.forth\"  (keyup)=\"otpController($event,'',otp3,4)\">\n      </ion-input>\n\n      </ion-col>\n    </ion-row>\n    <p>Did you write your number wrong?<a (click)=\"clickLoginButton()\">Login</a></p>\n\n  </div>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_sms-verification_sms-verification_module_ts.js.map