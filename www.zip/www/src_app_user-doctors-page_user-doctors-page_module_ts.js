(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_user-doctors-page_user-doctors-page_module_ts"],{

/***/ 223:
/*!***********************************************************************!*\
  !*** ./src/app/user-doctors-page/user-doctors-page-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDoctorsPagePageRoutingModule": () => (/* binding */ UserDoctorsPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _user_doctors_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-doctors-page.page */ 4062);




const routes = [
    {
        path: '',
        component: _user_doctors_page_page__WEBPACK_IMPORTED_MODULE_0__.UserDoctorsPagePage
    }
];
let UserDoctorsPagePageRoutingModule = class UserDoctorsPagePageRoutingModule {
};
UserDoctorsPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UserDoctorsPagePageRoutingModule);



/***/ }),

/***/ 9545:
/*!***************************************************************!*\
  !*** ./src/app/user-doctors-page/user-doctors-page.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDoctorsPagePageModule": () => (/* binding */ UserDoctorsPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _user_doctors_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-doctors-page-routing.module */ 223);
/* harmony import */ var _user_doctors_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-doctors-page.page */ 4062);







let UserDoctorsPagePageModule = class UserDoctorsPagePageModule {
};
UserDoctorsPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _user_doctors_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserDoctorsPagePageRoutingModule
        ],
        declarations: [_user_doctors_page_page__WEBPACK_IMPORTED_MODULE_1__.UserDoctorsPagePage]
    })
], UserDoctorsPagePageModule);



/***/ }),

/***/ 4062:
/*!*************************************************************!*\
  !*** ./src/app/user-doctors-page/user-doctors-page.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDoctorsPagePage": () => (/* binding */ UserDoctorsPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_user_doctors_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./user-doctors-page.page.html */ 3926);
/* harmony import */ var _user_doctors_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-doctors-page.page.scss */ 9482);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../error-controller.service */ 4898);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);




/* eslint-disable max-len */
/* eslint-disable @typescript-eslint/dot-notation */
/* eslint-disable quote-props */

/* eslint-disable @typescript-eslint/naming-convention */




let UserDoctorsPagePage = class UserDoctorsPagePage {
    constructor(router, http, errorController, alertController, loadingController) {
        this.router = router;
        this.http = http;
        this.errorController = errorController;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.app_token = '';
    }
    ngOnInit() {
    }
    whats_app_clicked(doctor) {
        window.open('https://wa.me/' + doctor.user.phone);
    }
    allDoctorsClicked() {
        this.router.navigate(['user-doctors-all-doctors']);
    }
    myDoctorsClicked() {
        this.router.navigate(['user-doctors-my-doctors']);
    }
};
UserDoctorsPagePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController }
];
UserDoctorsPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-user-doctors-page',
        template: _raw_loader_user_doctors_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_user_doctors_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], UserDoctorsPagePage);



/***/ }),

/***/ 9482:
/*!***************************************************************!*\
  !*** ./src/app/user-doctors-page/user-doctors-page.page.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("h1, ion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 17px;\n}\n\nh2, ion-list-header {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 13px;\n}\n\nh3 {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 10px;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 15px;\n}\n\n.profile {\n  text-align: center;\n  background-color: white;\n  margin-right: 5%;\n  margin-left: 5%;\n  margin-top: 4%;\n  margin-bottom: 4%;\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(108, 235, 58, 0.6);\n  backdrop-filter: blur(1.2px);\n  -webkit-backdrop-filter: blur(1.2px);\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  border-radius: 7%;\n}\n\nion-item {\n  border-radius: 5%;\n}\n\nion-searchbar {\n  border-radius: 20px;\n}\n\nion-list-header {\n  font-size: 15px;\n}\n\nion-content {\n  --ion-background-color: linear-gradient(to top, #34e67e, #abf853 80%);\n}\n\nion-toolbar {\n  --background: #abf853;\n}\n\n.item {\n  text-align: center;\n  border-style: groove;\n  background: rgba(255, 255, 255, 0.7);\n  box-shadow: 2px 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 6px solid rgba(255, 255, 255, 0.3);\n  height: 20%;\n  width: 50%;\n  padding-bottom: 6%;\n  margin-bottom: 5%;\n  margin-left: 25%;\n}\n\n.item-title {\n  margin-top: 25%;\n  font-size: 12px;\n  padding-bottom: 5%;\n}\n\n.div_margin {\n  margin-top: 50%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItZG9jdG9ycy1wYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLHdDQUFBO0VBQ0EsZUFBQTtBQUFGOztBQUVBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBQ0E7RUFDRSx3Q0FBQTtFQUNBLGVBQUE7QUFFRjs7QUFBQTtFQUNFLGdCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQkFBQTtBQUdGOztBQURBO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUVBLG9DQUFBO0VBQ0EsZ0RBQUE7RUFDQSw0QkFBQTtFQUNBLG9DQUFBO0VBQ0EsMkNBQUE7RUFDQSxpQkFBQTtBQUdGOztBQUFBO0VBQ0UsaUJBQUE7QUFHRjs7QUFEQTtFQUNFLG1CQUFBO0FBSUY7O0FBRkE7RUFDRSxlQUFBO0FBS0Y7O0FBSEE7RUFDRSxxRUFBQTtBQU1GOztBQUpBO0VBQ0UscUJBQUE7QUFPRjs7QUFKQTtFQUNFLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxvQ0FBQTtFQUVGLGtEQUFBO0VBQ0EsNEJBQUE7RUFDQSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsMENBQUE7RUFDRSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQU1GOztBQUhBO0VBQ0UsZUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQU1GOztBQUpBO0VBQ0UsZUFBQTtBQU9GIiwiZmlsZSI6InVzZXItZG9jdG9ycy1wYWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5oMSxpb24tdGl0bGV7XHJcbiAgZm9udC1mYW1pbHk6ICdQbHVzSmFrYXJ0YS1ib2xkJywgY3Vyc2l2ZTtcclxuICBmb250LXNpemU6IDE3cHg7XHJcbn1cclxuaDIsaW9uLWxpc3QtaGVhZGVye1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG59XHJcbmgze1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxMHB4O1xyXG59XHJcbnB7XHJcbiAgY29sb3I6ICM4Njg2ODZkYztcclxuICBmb250LWZhbWlseTogJ1FhbmVsYXNVbHRyYUxpZ2h0JztcclxuICBtYXJnaW4tdG9wOiAxNXB4O1xyXG59XHJcbi5wcm9maWxle1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxuICBtYXJnaW4tdG9wOiA0JTtcclxuICBtYXJnaW4tYm90dG9tOiA0JTtcclxuXHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC42ICk7XHJcbiAgYm94LXNoYWRvdzogMCA4cHggMzJweCAwIHJnYmEoMTA4LCAyMzUsIDU4LCAwLjYpO1xyXG4gIGJhY2tkcm9wLWZpbHRlcjogYmx1ciggMS4ycHggKTtcclxuICAtd2Via2l0LWJhY2tkcm9wLWZpbHRlcjogYmx1ciggMS4ycHggKTtcclxuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjE4ICk7XHJcbiAgYm9yZGVyLXJhZGl1czogNyU7XHJcblxyXG59XHJcbmlvbi1pdGVte1xyXG4gIGJvcmRlci1yYWRpdXM6IDUlO1xyXG59XHJcbmlvbi1zZWFyY2hiYXJ7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcclxufVxyXG5pb24tbGlzdC1oZWFkZXJ7XHJcbiAgZm9udC1zaXplOiAxNXB4O1xyXG59XHJcbmlvbi1jb250ZW50e1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byB0b3AsICMzNGU2N2UsICNhYmY4NTMgODAlKTtcclxufVxyXG5pb24tdG9vbGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjYWJmODUzO1xyXG5cclxufVxyXG4uaXRlbXtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgYm9yZGVyLXN0eWxlOmdyb292ZTtcclxuICBiYWNrZ3JvdW5kOiByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjcgKTtcclxuXHJcbmJveC1zaGFkb3c6IDJweCA4cHggMzJweCAwIHJnYmEoIDMxLCAzOCwgMTM1LCAwLjM3ICk7XHJcbmJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuLXdlYmtpdC1iYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDIuNXB4ICk7XHJcbmJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbmJvcmRlcjogNnB4IHNvbGlkIHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuMyApO1xyXG4gIGhlaWdodDogMjAlO1xyXG4gIHdpZHRoOiA1MCU7XHJcbiAgcGFkZGluZy1ib3R0b206IDYlO1xyXG4gIG1hcmdpbi1ib3R0b206IDUlO1xyXG4gIG1hcmdpbi1sZWZ0OiAyNSU7XHJcbn1cclxuXHJcbi5pdGVtLXRpdGxle1xyXG4gIG1hcmdpbi10b3A6IDI1JTtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDUlO1xyXG59XHJcbi5kaXZfbWFyZ2lue1xyXG4gIG1hcmdpbi10b3A6IDUwJTtcclxuXHJcbn1cclxuIl19 */");

/***/ }),

/***/ 3926:
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/user-doctors-page/user-doctors-page.page.html ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"user-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Doctors</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen>\n\n\n\n  <div class=\"div_margin\" >\n\n    <div class =\"item\" (click)=\"allDoctorsClicked()\">\n      <h1 class=\"item-title\">Show All Doctors</h1>\n\n    </div>\n\n\n    <div class =\"item\" (click)=\"myDoctorsClicked()\">\n      <h1 class=\"item-title\">Show My Doctors\n      </h1>\n    </div>\n\n\n  </div>\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_user-doctors-page_user-doctors-page_module_ts.js.map