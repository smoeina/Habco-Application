(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_admin-doctors_admin-doctors_module_ts"],{

/***/ 4171:
/*!***************************************************************!*\
  !*** ./src/app/admin-doctors/admin-doctors-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminDoctorsPageRoutingModule": () => (/* binding */ AdminDoctorsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _admin_doctors_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./admin-doctors.page */ 1318);




const routes = [
    {
        path: '',
        component: _admin_doctors_page__WEBPACK_IMPORTED_MODULE_0__.AdminDoctorsPage
    }
];
let AdminDoctorsPageRoutingModule = class AdminDoctorsPageRoutingModule {
};
AdminDoctorsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AdminDoctorsPageRoutingModule);



/***/ }),

/***/ 4290:
/*!*******************************************************!*\
  !*** ./src/app/admin-doctors/admin-doctors.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminDoctorsPageModule": () => (/* binding */ AdminDoctorsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _admin_doctors_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./admin-doctors-routing.module */ 4171);
/* harmony import */ var _admin_doctors_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./admin-doctors.page */ 1318);







let AdminDoctorsPageModule = class AdminDoctorsPageModule {
};
AdminDoctorsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _admin_doctors_routing_module__WEBPACK_IMPORTED_MODULE_0__.AdminDoctorsPageRoutingModule
        ],
        declarations: [_admin_doctors_page__WEBPACK_IMPORTED_MODULE_1__.AdminDoctorsPage]
    })
], AdminDoctorsPageModule);



/***/ }),

/***/ 1318:
/*!*****************************************************!*\
  !*** ./src/app/admin-doctors/admin-doctors.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminDoctorsPage": () => (/* binding */ AdminDoctorsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_admin_doctors_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./admin-doctors.page.html */ 866);
/* harmony import */ var _admin_doctors_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./admin-doctors.page.scss */ 2729);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../admin.service */ 457);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../error-controller.service */ 4898);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 1841);



/* eslint-disable @typescript-eslint/prefer-for-of */
/* eslint-disable no-var */
/* eslint-disable prefer-arrow/prefer-arrow-functions */


/* eslint-disable max-len */


/* eslint-disable @typescript-eslint/naming-convention */


let AdminDoctorsPage = class AdminDoctorsPage {
    constructor(alertController, http, loadingController, errorController, adminService, router) {
        this.alertController = alertController;
        this.http = http;
        this.loadingController = loadingController;
        this.errorController = errorController;
        this.adminService = adminService;
        this.router = router;
        this.app_token = '';
    }
    get_doctors_list() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            this.app_token = localStorage.getItem('app-token');
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
                Accept: 'application/json, text/plain',
                'cache-control': 'no-cache',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token, Accept, Authorization, X-Request-With, Access-Control-Request-Method, Access-Control-Request-Headers',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, OPTIONS, TRACE, PATCH, CONNECT'
            });
            const options = { headers };
            this.http.get('https://habco.rshayanfar.ir/habco/doctor', options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
                this.doctors_list = resp['data'];
                this.doctors_list.sort(function (a, b) {
                    var textA = a.fname;
                    var textB = b.fname;
                    return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
                });
                var edited_doctors_list = [];
                for (let i = 0; i < this.doctors_list.length; i++) {
                    if (this.doctors_list[i].fname) {
                        edited_doctors_list.push(this.doctors_list[i]);
                    }
                }
                this.doctors_list = edited_doctors_list;
                console.log(resp['data']);
                yield loading.dismiss();
            })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
                yield loading.dismiss();
                this.errorController.showError(error);
            }));
        });
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.get_doctors_list();
    }
    select_doctor(doctor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.adminService.selected_user = doctor;
            ;
            this.adminService.type = 'doctor';
            localStorage.setItem('selected_user', JSON.stringify(doctor));
            localStorage.setItem('type', 'doctor');
            this.router.navigate(['admin-see-info']);
        });
    }
};
AdminDoctorsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_3__.ErrorControllerService },
    { type: _admin_service__WEBPACK_IMPORTED_MODULE_2__.AdminService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router }
];
AdminDoctorsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-admin-doctors',
        template: _raw_loader_admin_doctors_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_admin_doctors_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AdminDoctorsPage);



/***/ }),

/***/ 2729:
/*!*******************************************************!*\
  !*** ./src/app/admin-doctors/admin-doctors.page.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 17px;\n}\n\nh2, ion-list-header {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 13px;\n}\n\nh3 {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 10px;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 15px;\n}\n\n.profile {\n  text-align: center;\n  margin-right: 5%;\n  margin-left: 5%;\n  margin-top: 4%;\n  margin-bottom: 4%;\n  border-style: groove;\n  background: rgba(255, 255, 255, 0.7);\n  box-shadow: 2px 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 3px solid rgba(255, 255, 255, 0.3);\n}\n\nion-item {\n  border-radius: 5%;\n}\n\nion-searchbar {\n  border-radius: 20px;\n}\n\nion-list-header {\n  font-size: 15px;\n}\n\nion-content {\n  --ion-background-color: linear-gradient(to top, #34e67e, #abf853 80%);\n}\n\nion-toolbar {\n  --background: #abf853;\n}\n\nh1 {\n  font-family: \"PlusJakarta\", cursive;\n  font-size: 17px;\n  margin-top: 70%;\n  width: 80%;\n  margin-left: 10%;\n  margin-right: 10%;\n}\n\nion-list {\n  border-bottom-color: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkbWluLWRvY3RvcnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBQ0E7RUFDRSx3Q0FBQTtFQUNBLGVBQUE7QUFFRjs7QUFBQTtFQUNFLHdDQUFBO0VBQ0EsZUFBQTtBQUdGOztBQURBO0VBQ0UsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGdCQUFBO0FBSUY7O0FBRkE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0VBQ0Esb0NBQUE7RUFFRixrREFBQTtFQUNBLDRCQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0FBSUE7O0FBREE7RUFDRSxpQkFBQTtBQUlGOztBQUZBO0VBQ0UsbUJBQUE7QUFLRjs7QUFIQTtFQUNFLGVBQUE7QUFNRjs7QUFKQTtFQUNFLHFFQUFBO0FBT0Y7O0FBTEE7RUFDRSxxQkFBQTtBQVFGOztBQUxBO0VBQ0UsbUNBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBUUY7O0FBTkE7RUFDRSxnQ0FBQTtBQVNGIiwiZmlsZSI6ImFkbWluLWRvY3RvcnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRpdGxle1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxN3B4O1xyXG59XHJcbmgyLGlvbi1saXN0LWhlYWRlcntcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhLWJvbGQnLCBjdXJzaXZlO1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxufVxyXG5oM3tcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhLWJvbGQnLCBjdXJzaXZlO1xyXG4gIGZvbnQtc2l6ZTogMTBweDtcclxufVxyXG5we1xyXG4gIGNvbG9yOiAjODY4Njg2ZGM7XHJcbiAgZm9udC1mYW1pbHk6ICdRYW5lbGFzVWx0cmFMaWdodCc7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4ucHJvZmlsZXtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgbWFyZ2luLXRvcDogNCU7XHJcbiAgbWFyZ2luLWJvdHRvbTogNCU7XHJcbiAgYm9yZGVyLXN0eWxlOmdyb292ZTtcclxuICBiYWNrZ3JvdW5kOiByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjcgKTtcclxuXHJcbmJveC1zaGFkb3c6IDJweCA4cHggMzJweCAwIHJnYmEoIDMxLCAzOCwgMTM1LCAwLjM3ICk7XHJcbmJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuLXdlYmtpdC1iYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDIuNXB4ICk7XHJcbmJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbmJvcmRlcjogM3B4IHNvbGlkIHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuMyApO1xyXG5cclxufVxyXG5pb24taXRlbXtcclxuICBib3JkZXItcmFkaXVzOiA1JTtcclxufVxyXG5pb24tc2VhcmNoYmFye1xyXG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbn1cclxuaW9uLWxpc3QtaGVhZGVye1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG5pb24tY29udGVudHtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBsaW5lYXItZ3JhZGllbnQodG8gdG9wLCAjMzRlNjdlLCAjYWJmODUzIDgwJSk7XHJcbn1cclxuaW9uLXRvb2xiYXIge1xyXG4gIC0tYmFja2dyb3VuZDogI2FiZjg1MztcclxuXHJcbn1cclxuaDF7XHJcbiAgZm9udC1mYW1pbHk6ICdQbHVzSmFrYXJ0YScsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxN3B4O1xyXG4gIG1hcmdpbi10b3A6IDcwJTtcclxuICB3aWR0aDogODAlO1xyXG4gIG1hcmdpbi1sZWZ0OiAxMCU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMCU7XHJcbn1cclxuaW9uLWxpc3R7XHJcbiAgYm9yZGVyLWJvdHRvbS1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 866:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin-doctors/admin-doctors.page.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"admin-home\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Doctors</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <h1 *ngIf=\"!this.doctors_list\">There is no doctor in database yet :(</h1>\n  <ion-list>\n\n      <div class=\"profile\" *ngFor=\"let doctor of this.doctors_list\">\n        <ion-item lines=\"none\" no-lines>\n          <ion-avatar slot=\"start\">\n            <img src=\"https://ui-avatars.com/api/background=17D7A0&color=fff?name={{doctor.fname}}+{{doctor.lname}}?\">\n          </ion-avatar>\n          <ion-label>\n            <h2>{{doctor.fname}} {{doctor.lname}}</h2>\n            <h3>{{doctor.specialization}}</h3>\n          </ion-label>\n          <ion-icon name=\"create-outline\" slot=\"end\" #doctor_selected (click)=\"select_doctor(doctor)\" ></ion-icon>\n        </ion-item>\n      </div>\n  </ion-list>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_admin-doctors_admin-doctors_module_ts.js.map