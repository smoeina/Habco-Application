(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_register_register_module_ts"],{

/***/ 1880:
/*!*****************************************************!*\
  !*** ./src/app/register/register-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageRoutingModule": () => (/* binding */ RegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page */ 8135);




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_0__.RegisterPage
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ 8723:
/*!*********************************************!*\
  !*** ./src/app/register/register.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageModule": () => (/* binding */ RegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 1880);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page */ 8135);
/* harmony import */ var ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ion-intl-tel-input */ 6662);








let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterPageRoutingModule,
            ion_intl_tel_input__WEBPACK_IMPORTED_MODULE_7__.IonIntlTelInputModule
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_1__.RegisterPage]
    })
], RegisterPageModule);



/***/ }),

/***/ 8135:
/*!*******************************************!*\
  !*** ./src/app/register/register.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPage": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./register.page.html */ 9200);
/* harmony import */ var _register_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page.scss */ 9728);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../error-controller.service */ 4898);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../auth.service */ 2891);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);




/* eslint-disable @typescript-eslint/naming-convention */





let RegisterPage = class RegisterPage {
    constructor(router, authService, loadingController, alertController, ErrorCont) {
        this.router = router;
        this.authService = authService;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.ErrorCont = ErrorCont;
        this.emailSpan = true;
        this.phoneSpan = true;
        this.userType = 'user';
        this.step = 'None';
        this.phone_number = '';
    }
    ngOnInit() {
    }
    checkInputValues() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Error in entered values',
                message: 'Please check entered values and try again',
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    registerDoneAlert() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Register Done.',
                message: 'Registered Successfully.',
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    onClickSubmit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            console.log(this.phone);
            console.log((this.phone.dialCodePrefix + this.phone.country.dialCode + this.phone.phoneNumber)
                .replace(/\s/g, '').replaceAll('+', '').replaceAll('-', ''));
            this.phone_number = (this.phone.dialCodePrefix + this.phone.country.dialCode + this.phone.phoneNumber)
                .replace(/\s/g, '').replaceAll('+', '').replaceAll('-', '');
            if (this.step === 'None') {
                this.ErrorCont.showErrorMessage('Please Enter User Type');
                return;
            }
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            if (this.emailSpan && this.phoneSpan && this.email.length !== 0) {
                this.authService.register(this.email.value, this.phone_number, this.step).toPromise().then(resp => {
                    console.log(resp);
                    loading.dismiss();
                    this.registerDoneAlert();
                    this.router.navigate(['login']);
                }).catch(error => {
                    // console.log(error);
                    loading.dismiss();
                    this.ErrorCont.showError(error);
                });
            }
            else {
                this.checkInputValues();
            }
        });
    }
    checkEmail() {
        if (this.email.value.includes('@') && this.email.value.includes('.')) {
            this.emailSpan = true;
        }
        else {
            return this.emailSpan = false;
        }
    }
    checkPhoneNumber() {
        if (this.phone.internationalNumber.includes('+')) {
            this.phoneSpan = true;
        }
        else {
            return this.phoneSpan = false;
        }
    }
    clickLoginButton() {
        this.router.navigate(['login']);
    }
    doctorClicked() {
        this.step = 'doctor';
    }
    nurseClicked() {
        this.step = 'nurse';
    }
    userClicked() {
        this.step = 'patient';
    }
    drugStoreClicked() {
        this.step = 'pharmacist';
    }
};
RegisterPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService }
];
RegisterPage.propDecorators = {
    email: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['email',] }],
    phone: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['phone',] }]
};
RegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-register',
        template: _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_register_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], RegisterPage);



/***/ }),

/***/ 9728:
/*!*********************************************!*\
  !*** ./src/app/register/register.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("h1, h2 {\n  font-family: \"PlusJakarta-bold\";\n  font-size: 20px;\n  text-align: center;\n  font-weight: 100;\n  margin-top: 15%;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 4%;\n  text-align: center;\n}\n\nimg {\n  text-align: center;\n  height: 40%;\n  width: 45%;\n  margin-top: 15%;\n  margin-left: 30%;\n  margin-right: 30%;\n}\n\nion-input {\n  font-family: \"QanelasUltraLight\";\n  background-color: #F1F1F1;\n  margin-left: 12%;\n  margin-right: 12%;\n  width: 76%;\n  border-radius: 20px;\n  margin-top: 5px;\n  --padding-start: 10px;\n}\n\nion-button {\n  font-family: \"PlusJakarta-bold\";\n  position: relative;\n  margin-left: 20%;\n  width: 60%;\n  height: 30px;\n  margin-right: 20%;\n  margin-top: 20px;\n}\n\n#forget {\n  margin-left: 50%;\n  margin-bottom: 20px;\n}\n\na {\n  font-family: \"PlusJakarta\";\n}\n\nspan {\n  color: #ca2525dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 15px;\n  text-align: center;\n  width: 60%;\n  margin-left: 20%;\n  margin-right: 20%;\n  white-space: nowrap;\n}\n\nion-intl-tel-input {\n  margin-left: 12%;\n  margin-right: 12%;\n  width: 76%;\n}\n\n.flex-container {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  height: 30%;\n  width: 80%;\n  margin-left: 10%;\n  margin-right: 10%;\n}\n\n.flex-container > div {\n  background-color: #f8f6f6;\n  margin: 10px;\n  border-radius: 5px;\n  border: 2px solid #9bf0a9;\n  width: 40%;\n  height: 15%;\n  text-align: center;\n  padding-bottom: 4%;\n}\n\n.flex-container > div.active {\n  background-color: #9bf0a9;\n  margin: 10px;\n  border-radius: 5px;\n  border: 2px solid #9bf0a9;\n  width: 40%;\n  height: 15%;\n  text-align: center;\n  padding-bottom: 4%;\n}\n\n.type {\n  height: 35%;\n}\n\n.active {\n  background-color: #9bf0a9;\n  margin: 10px;\n  border-radius: 5px;\n  border: 2px solid #9bf0a9;\n  width: 40%;\n  height: 15%;\n  text-align: center;\n  padding-bottom: 4%;\n}\n\n.patient {\n  height: 40%;\n  margin-bottom: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLCtCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBQUY7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLGdDQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFHQTtFQUNFLGdDQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0FBQUY7O0FBRUE7RUFDRSwrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0QsWUFBQTtFQUNDLGlCQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7QUFFRjs7QUFBQTtFQUNFLDBCQUFBO0FBR0Y7O0FBQUE7RUFDRSxnQkFBQTtFQUNBLGdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFHRjs7QUFEQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0FBSUY7O0FBQUE7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBR0Y7O0FBREE7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBSUY7O0FBRkE7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBS0Y7O0FBSEE7RUFDRSxXQUFBO0FBTUY7O0FBSkE7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBT0Y7O0FBTEE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7QUFRQSIsImZpbGUiOiJyZWdpc3Rlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaDEsaDJ7XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgZm9udC13ZWlnaHQ6IDEwMDtcclxuICBtYXJnaW4tdG9wOiAxNSU7XHJcbn1cclxucHtcclxuICBjb2xvcjogIzg2ODY4NmRjO1xyXG4gIGZvbnQtZmFtaWx5OiAnUWFuZWxhc1VsdHJhTGlnaHQnO1xyXG4gIG1hcmdpbi10b3A6IDQlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbn1cclxuaW1ne1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBoZWlnaHQ6IDQwJTtcclxuICB3aWR0aDogNDUlO1xyXG4gIG1hcmdpbi10b3A6IDE1JTtcclxuICBtYXJnaW4tbGVmdDogMzAlO1xyXG4gIG1hcmdpbi1yaWdodDogMzAlO1xyXG5cclxufVxyXG5cclxuaW9uLWlucHV0e1xyXG4gIGZvbnQtZmFtaWx5OiBcIlFhbmVsYXNVbHRyYUxpZ2h0XCI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI0YxRjFGMTtcclxuICBtYXJnaW4tbGVmdDogMTIlO1xyXG4gIG1hcmdpbi1yaWdodDogMTIlO1xyXG4gIHdpZHRoOiA3NiU7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xyXG59XHJcbmlvbi1idXR0b257XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBtYXJnaW4tbGVmdDogMjAlO1xyXG4gIHdpZHRoOiA2MCU7XHJcblx0aGVpZ2h0OiAzMHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMjAlO1xyXG4gIG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuI2ZvcmdldHtcclxuICBtYXJnaW4tbGVmdDogNTAlO1xyXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbn1cclxuYXtcclxuICBmb250LWZhbWlseTogXCJQbHVzSmFrYXJ0YVwiO1xyXG5cclxufVxyXG5zcGFue1xyXG4gIGNvbG9yOiAjY2EyNTI1ZGM7XHJcbiAgZm9udC1mYW1pbHk6ICdRYW5lbGFzVWx0cmFMaWdodCc7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2lkdGg6IDYwJTtcclxuICBtYXJnaW4tbGVmdDogMjAlO1xyXG4gIG1hcmdpbi1yaWdodDogMjAlO1xyXG4gIHdoaXRlLXNwYWNlOm5vd3JhcDtcclxufVxyXG5pb24taW50bC10ZWwtaW5wdXR7XHJcbiAgbWFyZ2luLWxlZnQ6IDEyJTtcclxuICBtYXJnaW4tcmlnaHQ6IDEyJTtcclxuICB3aWR0aDogNzYlO1xyXG5cclxufVxyXG5cclxuLmZsZXgtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGZsZXgtd3JhcDp3cmFwO1xyXG4gIGhlaWdodDogMzAlO1xyXG4gIHdpZHRoOiA4MCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDEwJTtcclxufVxyXG4uZmxleC1jb250YWluZXIgPiBkaXYge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmOGY2ZjY7XHJcbiAgbWFyZ2luOiAxMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjOWJmMGE5O1xyXG4gIHdpZHRoOjQwJTtcclxuICBoZWlnaHQ6IDE1JTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcGFkZGluZy1ib3R0b206IDQlO1xyXG59XHJcbi5mbGV4LWNvbnRhaW5lciA+IGRpdi5hY3RpdmV7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzliZjBhOTtcclxuICBtYXJnaW46IDEwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICM5YmYwYTk7XHJcbiAgd2lkdGg6NDAlO1xyXG4gIGhlaWdodDogMTUlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBwYWRkaW5nLWJvdHRvbTogNCU7XHJcbn1cclxuLnR5cGV7XHJcbiAgaGVpZ2h0OiAzNSU7XHJcbn1cclxuLmFjdGl2ZXtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOWJmMGE5O1xyXG4gIG1hcmdpbjogMTBweDtcclxuICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgYm9yZGVyOiAycHggc29saWQgIzliZjBhOTtcclxuICB3aWR0aDo0MCU7XHJcbiAgaGVpZ2h0OiAxNSU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHBhZGRpbmctYm90dG9tOiA0JTtcclxufVxyXG4ucGF0aWVudHtcclxuaGVpZ2h0OiA0MCU7XHJcbm1hcmdpbi1ib3R0b206IDUlO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 9200:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("  <ion-content>\n    <h1>Join us Today</h1>\n    <p>Please enter the details below to continue.</p>\n    <!-- phoneNumber?: number;\n    email?: string;\n    password?: string;\n    id?: number;\n    accessToken?: string; -->\n    <form #userlogin = \"ngForm\" (ngSubmit) = \"onClickSubmit()\" >\n\n      <div class=\"flex-container\" #type>\n        <div [class.active]=\"step==='doctor'\" (click)=\"doctorClicked()\">\n          <img class=\"type\" src=\"/assets/Doctor-Register.png\" alt=\"\">\n          <p style=\"font-size: 13px;display: inline\"><b>Doctor</b></p>\n        </div>\n\n        <div [class.active]=\"step==='nurse'\" (click)=\"nurseClicked()\"> <img class=\"type\" src=\"/assets/Nurse-Register.png\" alt=\"\">\n          <p style=\"font-size: 13px;display: inline\"><b>Nurse</b></p>\n\n        </div>\n        <div [class.active]=\"step==='pharmacist'\" (click)=\"drugStoreClicked()\"><div > <img class=\"type\" src=\"/assets/Drugstore-Register.png\" alt=\"\"></div>\n        <p style=\"font-size: 14px;display: inline\"><b>Pharmacist</b></p>\n      </div>\n      <div [class.active]=\"step==='patient'\" (click)=\"userClicked()\" ><div> <img class=\"patient\"  src=\"/assets/Normal-user-Register.png\" alt=\"\"></div>\n      <p style=\"font-size: 14px;display: inline\"><b>Patient</b></p>\n    </div>\n      </div>\n      <ion-intl-tel-input defaultCountryiso=\"ca\" #phone inputPlaceholder=\"2124567890\"></ion-intl-tel-input>\n      <!-- Put Eye icon for seeing password -->\n      <ion-input on-keyup=\"checkEmail()\" #email type=\"email\" class=\"input\" placeholder=\"Email\" ></ion-input>\n      <span [hidden]=\"emailSpan\">Incorrect format for Email</span>\n      <ion-button expand=\"block\" shape='round' clearInput type =\"submit\" value = \"submit\">Register</ion-button>\n    </form>\n    <p>Have an account?<a (click)=\"clickLoginButton()\">Login</a></p>\n\n  </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_register_register_module_ts.js.map