(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_drugstore-prescriptions-page_drugstore-prescriptions-page_module_ts"],{

/***/ 3333:
/*!*********************************************************************************************!*\
  !*** ./src/app/drugstore-prescriptions-page/drugstore-prescriptions-page-routing.module.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DrugstorePrescriptionsPagePageRoutingModule": () => (/* binding */ DrugstorePrescriptionsPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _drugstore_prescriptions_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./drugstore-prescriptions-page.page */ 5262);




const routes = [
    {
        path: '',
        component: _drugstore_prescriptions_page_page__WEBPACK_IMPORTED_MODULE_0__.DrugstorePrescriptionsPagePage
    }
];
let DrugstorePrescriptionsPagePageRoutingModule = class DrugstorePrescriptionsPagePageRoutingModule {
};
DrugstorePrescriptionsPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DrugstorePrescriptionsPagePageRoutingModule);



/***/ }),

/***/ 1570:
/*!*************************************************************************************!*\
  !*** ./src/app/drugstore-prescriptions-page/drugstore-prescriptions-page.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DrugstorePrescriptionsPagePageModule": () => (/* binding */ DrugstorePrescriptionsPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _drugstore_prescriptions_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./drugstore-prescriptions-page-routing.module */ 3333);
/* harmony import */ var _drugstore_prescriptions_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./drugstore-prescriptions-page.page */ 5262);







let DrugstorePrescriptionsPagePageModule = class DrugstorePrescriptionsPagePageModule {
};
DrugstorePrescriptionsPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _drugstore_prescriptions_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.DrugstorePrescriptionsPagePageRoutingModule
        ],
        declarations: [_drugstore_prescriptions_page_page__WEBPACK_IMPORTED_MODULE_1__.DrugstorePrescriptionsPagePage]
    })
], DrugstorePrescriptionsPagePageModule);



/***/ }),

/***/ 5262:
/*!***********************************************************************************!*\
  !*** ./src/app/drugstore-prescriptions-page/drugstore-prescriptions-page.page.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DrugstorePrescriptionsPagePage": () => (/* binding */ DrugstorePrescriptionsPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_drugstore_prescriptions_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./drugstore-prescriptions-page.page.html */ 7780);
/* harmony import */ var _drugstore_prescriptions_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./drugstore-prescriptions-page.page.scss */ 7505);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../error-controller.service */ 4898);



/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/dot-notation */
/* eslint-disable @typescript-eslint/naming-convention */






let DrugstorePrescriptionsPagePage = class DrugstorePrescriptionsPagePage {
    constructor(alertController, http, loadingController, errorController, router) {
        this.alertController = alertController;
        this.http = http;
        this.loadingController = loadingController;
        this.errorController = errorController;
        this.router = router;
        this.app_token = '';
    }
    ngOnInit() {
    }
    get_id() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers };
            // http://localhost:8000/habco/pharmacist/{id}/drug
            this.http.get('https://habco.rshayanfar.ir/habco/prescription', options).toPromise().then(resp => {
                this.prescriptions = resp['data'];
                loading.dismiss();
            }).catch(error => {
                loading.dismiss();
                this.errorController.showError(error);
            });
        });
    }
    ionViewWillEnter() {
        this.app_token = localStorage.getItem('app-token');
        this.get_id();
    }
    change_status(pres) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            const prompt = this.alertController.create({
                header: 'Tranmitting prescription',
                message: 'Are you want to change the status of prescription to transmitted?',
                buttons: [
                    {
                        text: 'Cancel',
                        handler: data => {
                            console.log('Cancel clicked');
                        }
                    },
                    {
                        text: 'Yes',
                        handler: (data) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                            yield loading.present();
                            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                                'Content-Type': 'application/json',
                                Authorization: 'Bearer ' + this.app_token,
                            });
                            const options = { headers };
                            this.http.put('https://habco.rshayanfar.ir/habco/prescription/' + pres.id, { status: 'transmitted' }, options).toPromise().then(response => {
                                console.log(response['data']);
                                loading.dismiss();
                                this.get_id();
                            }).catch(error => {
                                loading.dismiss();
                                this.errorController.showError(error);
                            });
                        })
                    }
                ]
            });
            (yield prompt).present();
        });
    }
};
DrugstorePrescriptionsPagePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
DrugstorePrescriptionsPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-drugstore-prescriptions-page',
        template: _raw_loader_drugstore_prescriptions_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_drugstore_prescriptions_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DrugstorePrescriptionsPagePage);



/***/ }),

/***/ 7505:
/*!*************************************************************************************!*\
  !*** ./src/app/drugstore-prescriptions-page/drugstore-prescriptions-page.page.scss ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("p {\n  font-family: \"HelloKetta\";\n  font-size: 30px;\n}\n\nion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 16px;\n}\n\nion-card {\n  margin-top: 10%;\n  font-family: \"Gilroy\", cursive;\n}\n\nion-button {\n  margin-left: 30%;\n  margin-right: 30%;\n  width: 40%;\n  font-family: \"Gilroy-bold\", cursive;\n}\n\nion-card-subtitle {\n  font-family: \"Gilroy-bold\";\n}\n\nion-select-option {\n  font-family: \"Gilroy\";\n}\n\nion-item {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRydWdzdG9yZS1wcmVzY3JpcHRpb25zLXBhZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UseUJBQUE7RUFDQSxlQUFBO0FBQUY7O0FBRUE7RUFDRSx3Q0FBQTtFQUNBLGVBQUE7QUFDRjs7QUFDQTtFQUNFLGVBQUE7RUFDQSw4QkFBQTtBQUVGOztBQUNBO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFVBQUE7RUFDQSxtQ0FBQTtBQUVGOztBQUNBO0VBQ0UsMEJBQUE7QUFFRjs7QUFDQTtFQUNFLHFCQUFBO0FBRUY7O0FBQ0E7RUFDRSx3Q0FBQTtFQUNBLGVBQUE7QUFFRiIsImZpbGUiOiJkcnVnc3RvcmUtcHJlc2NyaXB0aW9ucy1wYWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5we1xyXG4gIGZvbnQtZmFtaWx5OiAnSGVsbG9LZXR0YSc7XHJcbiAgZm9udC1zaXplOjMwcHg7XHJcbn1cclxuaW9uLXRpdGxle1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG59XHJcbmlvbi1jYXJke1xyXG4gIG1hcmdpbi10b3A6IDEwJTtcclxuICBmb250LWZhbWlseTogJ0dpbHJveScsIGN1cnNpdmU7XHJcblxyXG59XHJcbmlvbi1idXR0b257XHJcbiAgbWFyZ2luLWxlZnQ6IDMwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDMwJTtcclxuICB3aWR0aDogNDAlO1xyXG4gIGZvbnQtZmFtaWx5OiAnR2lscm95LWJvbGQnLCBjdXJzaXZlO1xyXG5cclxufVxyXG5pb24tY2FyZC1zdWJ0aXRsZXtcclxuICBmb250LWZhbWlseTogJ0dpbHJveS1ib2xkJztcclxuXHJcbn1cclxuaW9uLXNlbGVjdC1vcHRpb257XHJcbiAgZm9udC1mYW1pbHk6ICdHaWxyb3knO1xyXG5cclxufVxyXG5pb24taXRlbXtcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhLWJvbGQnLCBjdXJzaXZlO1xyXG4gIGZvbnQtc2l6ZTogMTBweDtcclxufVxyXG5cclxuIl19 */");

/***/ }),

/***/ 7780:
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/drugstore-prescriptions-page/drugstore-prescriptions-page.page.html ***!
  \***************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"drugstore-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>drugstore-prescriptions-page</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card *ngFor=\"let prescription of this.prescriptions\" (click)=\"change_status(prescription)\">\n    <ion-card-header>\n      <ion-card-subtitle>Patient:\n        <ion-item>\n          {{prescription.patient.user.fname}} {{prescription.patient.user.lname}}\n        </ion-item>\n\n      </ion-card-subtitle>\n      <ion-card-subtitle>Date:\n        <ion-item>\n          <ion-datetime disabled  value=\"{{prescription.created_at}}\" display-timezone=\"utc\"></ion-datetime>\n        </ion-item>\n\n      </ion-card-subtitle>\n    </ion-card-header>\n\n    <ion-card-content>\n      <ion-card-subtitle>Text:</ion-card-subtitle>\n      <p>\n        {{prescription.text}}\n      </p>\n    </ion-card-content>\n    <ion-card-content>\n      <ion-card-subtitle >Status:</ion-card-subtitle>\n      <p style=\"font-family: 'Gilroy-bold';font-size: 14px;\">\n        {{prescription.status}}\n      </p>\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_drugstore-prescriptions-page_drugstore-prescriptions-page_module_ts.js.map