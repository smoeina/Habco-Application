(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_user-doctors-all-doctors_user-doctors-all-doctors_module_ts"],{

/***/ 116:
/*!*************************************************************************************!*\
  !*** ./src/app/user-doctors-all-doctors/user-doctors-all-doctors-routing.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDoctorsAllDoctorsPageRoutingModule": () => (/* binding */ UserDoctorsAllDoctorsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _user_doctors_all_doctors_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-doctors-all-doctors.page */ 5755);




const routes = [
    {
        path: '',
        component: _user_doctors_all_doctors_page__WEBPACK_IMPORTED_MODULE_0__.UserDoctorsAllDoctorsPage
    }
];
let UserDoctorsAllDoctorsPageRoutingModule = class UserDoctorsAllDoctorsPageRoutingModule {
};
UserDoctorsAllDoctorsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UserDoctorsAllDoctorsPageRoutingModule);



/***/ }),

/***/ 7296:
/*!*****************************************************************************!*\
  !*** ./src/app/user-doctors-all-doctors/user-doctors-all-doctors.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDoctorsAllDoctorsPageModule": () => (/* binding */ UserDoctorsAllDoctorsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _user_doctors_all_doctors_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-doctors-all-doctors-routing.module */ 116);
/* harmony import */ var _user_doctors_all_doctors_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-doctors-all-doctors.page */ 5755);







let UserDoctorsAllDoctorsPageModule = class UserDoctorsAllDoctorsPageModule {
};
UserDoctorsAllDoctorsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _user_doctors_all_doctors_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserDoctorsAllDoctorsPageRoutingModule
        ],
        declarations: [_user_doctors_all_doctors_page__WEBPACK_IMPORTED_MODULE_1__.UserDoctorsAllDoctorsPage]
    })
], UserDoctorsAllDoctorsPageModule);



/***/ }),

/***/ 5755:
/*!***************************************************************************!*\
  !*** ./src/app/user-doctors-all-doctors/user-doctors-all-doctors.page.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserDoctorsAllDoctorsPage": () => (/* binding */ UserDoctorsAllDoctorsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_user_doctors_all_doctors_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./user-doctors-all-doctors.page.html */ 4645);
/* harmony import */ var _user_doctors_all_doctors_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-doctors-all-doctors.page.scss */ 4748);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../error-controller.service */ 4898);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);



/* eslint-disable max-len */


/* eslint-disable @typescript-eslint/naming-convention */


let UserDoctorsAllDoctorsPage = class UserDoctorsAllDoctorsPage {
    constructor(alertController, http, loadingController, errorController) {
        this.alertController = alertController;
        this.http = http;
        this.loadingController = loadingController;
        this.errorController = errorController;
        this.app_token = '';
    }
    get_doctors_list() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            this.app_token = localStorage.getItem('app-token');
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
                Accept: 'application/json, text/plain',
                'cache-control': 'no-cache',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token, Accept, Authorization, X-Request-With, Access-Control-Request-Method, Access-Control-Request-Headers',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, OPTIONS, TRACE, PATCH, CONNECT'
            });
            const options = { headers };
            this.http.get('https://habco.rshayanfar.ir/habco/doctor', options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                this.doctors_list = resp['data'];
                yield loading.dismiss();
            })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                yield loading.dismiss();
                this.errorController.showError(error);
            }));
        });
    }
    ngOnInit() {
    }
    select_doctor(doctor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
                Accept: 'application/json, text/plain',
                'cache-control': 'no-cache',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token, Accept, Authorization, X-Request-With, Access-Control-Request-Method, Access-Control-Request-Headers',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, OPTIONS, TRACE, PATCH, CONNECT'
            });
            const options = { headers };
            this.alertController.create({
                header: 'Confirm Alert',
                subHeader: 'Select Doctor',
                message: 'Are you sure?Do you want Select ' + doctor.lname + ' as your Doctor?',
                buttons: [
                    {
                        text: 'No',
                        handler: () => {
                        }
                    },
                    {
                        text: 'Yes',
                        handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                            yield loading.present();
                            this.http.post('https://habco.rshayanfar.ir/habco/patient/doctor' + doctor.id, { '': '' }, options).toPromise().then(resp => {
                            }).catch(error => {
                                loading.dismiss();
                                this.errorController.showError(error);
                            });
                        })
                    }
                ]
            }).then(res => {
                res.present();
                loading.dismiss();
            });
        });
    }
    ionViewWillEnter() {
        this.get_doctors_list();
    }
};
UserDoctorsAllDoctorsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService }
];
UserDoctorsAllDoctorsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-user-doctors-all-doctors',
        template: _raw_loader_user_doctors_all_doctors_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_user_doctors_all_doctors_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], UserDoctorsAllDoctorsPage);



/***/ }),

/***/ 4748:
/*!*****************************************************************************!*\
  !*** ./src/app/user-doctors-all-doctors/user-doctors-all-doctors.page.scss ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 17px;\n}\n\nh2, ion-list-header {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 13px;\n}\n\nh3 {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 10px;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 15px;\n}\n\n.profile {\n  text-align: center;\n  margin-right: 5%;\n  margin-left: 5%;\n  margin-top: 4%;\n  margin-bottom: 4%;\n  border-style: groove;\n  background: rgba(255, 255, 255, 0.7);\n  box-shadow: 2px 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 3px solid rgba(255, 255, 255, 0.3);\n}\n\nion-item {\n  border-radius: 5%;\n}\n\nion-searchbar {\n  border-radius: 20px;\n}\n\nion-list-header {\n  font-size: 15px;\n}\n\nion-content {\n  --ion-background-color: linear-gradient(to top, #34e67e, #abf853 80%);\n}\n\nion-toolbar {\n  --background: #abf853;\n}\n\nh1 {\n  font-family: \"PlusJakarta\", cursive;\n  font-size: 17px;\n  margin-top: 70%;\n  width: 80%;\n  margin-left: 10%;\n  margin-right: 10%;\n}\n\nion-list {\n  border-bottom-color: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItZG9jdG9ycy1hbGwtZG9jdG9ycy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx3Q0FBQTtFQUNBLGVBQUE7QUFDRjs7QUFDQTtFQUNFLHdDQUFBO0VBQ0EsZUFBQTtBQUVGOztBQUFBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBR0Y7O0FBREE7RUFDRSxnQkFBQTtFQUNBLGdDQUFBO0VBQ0EsZ0JBQUE7QUFJRjs7QUFGQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxvQ0FBQTtFQUVGLGtEQUFBO0VBQ0EsNEJBQUE7RUFDQSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsMENBQUE7QUFJQTs7QUFEQTtFQUNFLGlCQUFBO0FBSUY7O0FBRkE7RUFDRSxtQkFBQTtBQUtGOztBQUhBO0VBQ0UsZUFBQTtBQU1GOztBQUpBO0VBQ0UscUVBQUE7QUFPRjs7QUFMQTtFQUNFLHFCQUFBO0FBUUY7O0FBTEE7RUFDRSxtQ0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFRRjs7QUFOQTtFQUNFLGdDQUFBO0FBU0YiLCJmaWxlIjoidXNlci1kb2N0b3JzLWFsbC1kb2N0b3JzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10aXRsZXtcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhLWJvbGQnLCBjdXJzaXZlO1xyXG4gIGZvbnQtc2l6ZTogMTdweDtcclxufVxyXG5oMixpb24tbGlzdC1oZWFkZXJ7XHJcbiAgZm9udC1mYW1pbHk6ICdQbHVzSmFrYXJ0YS1ib2xkJywgY3Vyc2l2ZTtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbn1cclxuaDN7XHJcbiAgZm9udC1mYW1pbHk6ICdQbHVzSmFrYXJ0YS1ib2xkJywgY3Vyc2l2ZTtcclxuICBmb250LXNpemU6IDEwcHg7XHJcbn1cclxucHtcclxuICBjb2xvcjogIzg2ODY4NmRjO1xyXG4gIGZvbnQtZmFtaWx5OiAnUWFuZWxhc1VsdHJhTGlnaHQnO1xyXG4gIG1hcmdpbi10b3A6IDE1cHg7XHJcbn1cclxuLnByb2ZpbGV7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gIG1hcmdpbi10b3A6IDQlO1xyXG4gIG1hcmdpbi1ib3R0b206IDQlO1xyXG4gIGJvcmRlci1zdHlsZTpncm9vdmU7XHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC43ICk7XHJcblxyXG5ib3gtc2hhZG93OiAycHggOHB4IDMycHggMCByZ2JhKCAzMSwgMzgsIDEzNSwgMC4zNyApO1xyXG5iYWNrZHJvcC1maWx0ZXI6IGJsdXIoIDIuNXB4ICk7XHJcbi13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG5ib3JkZXI6IDNweCBzb2xpZCByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjMgKTtcclxuXHJcbn1cclxuaW9uLWl0ZW17XHJcbiAgYm9yZGVyLXJhZGl1czogNSU7XHJcbn1cclxuaW9uLXNlYXJjaGJhcntcclxuICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG59XHJcbmlvbi1saXN0LWhlYWRlcntcclxuICBmb250LXNpemU6IDE1cHg7XHJcbn1cclxuaW9uLWNvbnRlbnR7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbGluZWFyLWdyYWRpZW50KHRvIHRvcCwgIzM0ZTY3ZSwgI2FiZjg1MyA4MCUpO1xyXG59XHJcbmlvbi10b29sYmFyIHtcclxuICAtLWJhY2tncm91bmQ6ICNhYmY4NTM7XHJcblxyXG59XHJcbmgxe1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEnLCBjdXJzaXZlO1xyXG4gIGZvbnQtc2l6ZTogMTdweDtcclxuICBtYXJnaW4tdG9wOiA3MCU7XHJcbiAgd2lkdGg6IDgwJTtcclxuICBtYXJnaW4tbGVmdDogMTAlO1xyXG4gIG1hcmdpbi1yaWdodDogMTAlO1xyXG59XHJcbmlvbi1saXN0e1xyXG4gIGJvcmRlci1ib3R0b20tY29sb3I6IHRyYW5zcGFyZW50O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 4645:
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/user-doctors-all-doctors/user-doctors-all-doctors.page.html ***!
  \*******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"user-doctors-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Doctors</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <h1 *ngIf=\"!this.doctors_list\">There is no doctor in database yet :(</h1>\n  <ion-list>\n\n      <div class=\"profile\" *ngFor=\"let doctor of this.doctors_list\">\n        <ion-item lines=\"none\" no-lines>\n          <ion-avatar slot=\"start\">\n            <img src=\"https://ui-avatars.com/api/background=17D7A0&color=fff?name={{doctor.fname}}+{{doctor.lname}}?\">\n          </ion-avatar>\n          <ion-label>\n            <h2>{{doctor.fname}} {{doctor.lname}}</h2>\n            <h3>{{doctor.specialization}}</h3>\n          </ion-label>\n          <ion-icon name=\"add-circle\" slot=\"end\" #doctor_selected\n           (click)=\"select_doctor(doctor)\"></ion-icon>\n        </ion-item>\n      </div>\n  </ion-list>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_user-doctors-all-doctors_user-doctors-all-doctors_module_ts.js.map