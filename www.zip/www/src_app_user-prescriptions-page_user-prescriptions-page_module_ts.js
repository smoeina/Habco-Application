(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_user-prescriptions-page_user-prescriptions-page_module_ts"],{

/***/ 626:
/*!***********************************************************************************!*\
  !*** ./src/app/user-prescriptions-page/user-prescriptions-page-routing.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserPrescriptionsPagePageRoutingModule": () => (/* binding */ UserPrescriptionsPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _user_prescriptions_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-prescriptions-page.page */ 9348);




const routes = [
    {
        path: '',
        component: _user_prescriptions_page_page__WEBPACK_IMPORTED_MODULE_0__.UserPrescriptionsPagePage
    }
];
let UserPrescriptionsPagePageRoutingModule = class UserPrescriptionsPagePageRoutingModule {
};
UserPrescriptionsPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UserPrescriptionsPagePageRoutingModule);



/***/ }),

/***/ 8549:
/*!***************************************************************************!*\
  !*** ./src/app/user-prescriptions-page/user-prescriptions-page.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserPrescriptionsPagePageModule": () => (/* binding */ UserPrescriptionsPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _user_prescriptions_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-prescriptions-page-routing.module */ 626);
/* harmony import */ var _user_prescriptions_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-prescriptions-page.page */ 9348);







let UserPrescriptionsPagePageModule = class UserPrescriptionsPagePageModule {
};
UserPrescriptionsPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _user_prescriptions_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserPrescriptionsPagePageRoutingModule
        ],
        declarations: [_user_prescriptions_page_page__WEBPACK_IMPORTED_MODULE_1__.UserPrescriptionsPagePage]
    })
], UserPrescriptionsPagePageModule);



/***/ }),

/***/ 9348:
/*!*************************************************************************!*\
  !*** ./src/app/user-prescriptions-page/user-prescriptions-page.page.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserPrescriptionsPagePage": () => (/* binding */ UserPrescriptionsPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_user_prescriptions_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./user-prescriptions-page.page.html */ 9156);
/* harmony import */ var _user_prescriptions_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-prescriptions-page.page.scss */ 982);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 1841);




/* eslint-disable @typescript-eslint/naming-convention */


let UserPrescriptionsPagePage = class UserPrescriptionsPagePage {
    constructor(http, loadingController) {
        this.http = http;
        this.loadingController = loadingController;
        this.app_token = '';
    }
    ngOnInit() {
    }
    get_data() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            this.app_token = localStorage.getItem('app-token');
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders({
                'Content-Type': 'application/json',
                Accept: 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers };
            this.http.get('https://habco.rshayanfar.ir/habco/prescription', options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
                this.prescriptions = resp['data'];
                yield loading.dismiss();
            })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
                console.log('Error');
                console.log(error);
                yield loading.dismiss();
            }));
            //   this.http.get('https://habco.rshayanfar.ir/habco/instruction',options).toPromise().then(async resp => {
            //     this.prescriptions = resp['data'];
            //     await loading.dismiss();
            //  }).catch(async error => {
            //      console.log('Error');
            //      console.log(error);
            //      await loading.dismiss();
            //  });
        });
    }
    ionViewWillEnter() {
        this.get_data();
    }
};
UserPrescriptionsPagePage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController }
];
UserPrescriptionsPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-user-prescriptions-page',
        template: _raw_loader_user_prescriptions_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_user_prescriptions_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], UserPrescriptionsPagePage);



/***/ }),

/***/ 982:
/*!***************************************************************************!*\
  !*** ./src/app/user-prescriptions-page/user-prescriptions-page.page.scss ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("p {\n  font-family: \"HelloKetta\";\n  font-size: 30px;\n}\n\nion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 16px;\n}\n\nion-card {\n  margin-top: 10%;\n  font-family: \"Gilroy\", cursive;\n}\n\nion-button {\n  margin-left: 30%;\n  margin-right: 30%;\n  width: 40%;\n  font-family: \"Gilroy-bold\", cursive;\n}\n\nion-card-subtitle {\n  font-family: \"Gilroy-bold\";\n}\n\nion-select-option {\n  font-family: \"Gilroy\";\n}\n\nion-item {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 10px;\n}\n\nh1 {\n  font-family: \"PlusJakarta-bold\";\n  font-size: 16px;\n}\n\nion-content {\n  --ion-background-color: linear-gradient(to bottom, #c3fc81, #abf853 80%);\n}\n\nion-toolbar {\n  --background: #abf853;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItcHJlc2NyaXB0aW9ucy1wYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLHlCQUFBO0VBQ0EsZUFBQTtBQUFGOztBQUVBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxlQUFBO0VBQ0EsOEJBQUE7QUFFRjs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0VBQ0EsbUNBQUE7QUFFRjs7QUFDQTtFQUNFLDBCQUFBO0FBRUY7O0FBQ0E7RUFDRSxxQkFBQTtBQUVGOztBQUNBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBRUY7O0FBQUE7RUFDRSwrQkFBQTtFQUNBLGVBQUE7QUFHRjs7QUFEQTtFQUNFLHdFQUFBO0FBSUY7O0FBRkE7RUFDRSxxQkFBQTtBQUtGIiwiZmlsZSI6InVzZXItcHJlc2NyaXB0aW9ucy1wYWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5we1xyXG4gIGZvbnQtZmFtaWx5OiAnSGVsbG9LZXR0YSc7XHJcbiAgZm9udC1zaXplOjMwcHg7XHJcbn1cclxuaW9uLXRpdGxle1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG59XHJcbmlvbi1jYXJke1xyXG4gIG1hcmdpbi10b3A6IDEwJTtcclxuICBmb250LWZhbWlseTogJ0dpbHJveScsIGN1cnNpdmU7XHJcblxyXG59XHJcbmlvbi1idXR0b257XHJcbiAgbWFyZ2luLWxlZnQ6IDMwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDMwJTtcclxuICB3aWR0aDogNDAlO1xyXG4gIGZvbnQtZmFtaWx5OiAnR2lscm95LWJvbGQnLCBjdXJzaXZlO1xyXG5cclxufVxyXG5pb24tY2FyZC1zdWJ0aXRsZXtcclxuICBmb250LWZhbWlseTogJ0dpbHJveS1ib2xkJztcclxuXHJcbn1cclxuaW9uLXNlbGVjdC1vcHRpb257XHJcbiAgZm9udC1mYW1pbHk6ICdHaWxyb3knO1xyXG5cclxufVxyXG5pb24taXRlbXtcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhLWJvbGQnLCBjdXJzaXZlO1xyXG4gIGZvbnQtc2l6ZTogMTBweDtcclxufVxyXG5oMXtcclxuICBmb250LWZhbWlseTogJ1BsdXNKYWthcnRhLWJvbGQnO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG5pb24tY29udGVudHtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjYzNmYzgxLCAjYWJmODUzIDgwJSk7XHJcbn1cclxuaW9uLXRvb2xiYXIge1xyXG4gIC0tYmFja2dyb3VuZDogI2FiZjg1MztcclxuXHJcbn1cclxuIl19 */");

/***/ }),

/***/ 9156:
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/user-prescriptions-page/user-prescriptions-page.page.html ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"user-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Presciptions</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card *ngFor=\"let prescription of this.prescriptions\">\n    <ion-card-header>\n      <ion-card-subtitle>Doctor:\n        <ion-item>\n          {{prescription.doctor.user.fname}} {{prescription.doctor.user.lname}}\n        </ion-item>\n\n      </ion-card-subtitle>\n      <ion-card-subtitle>Date:\n        <ion-item>\n          <ion-datetime disabled  value=\"{{prescription.created_at}}\" display-timezone=\"utc\"></ion-datetime>\n        </ion-item>\n\n      </ion-card-subtitle>\n    </ion-card-header>\n\n    <ion-card-content>\n      <ion-card-subtitle>Text:</ion-card-subtitle>\n      <p>\n        {{prescription.text}}\n      </p>\n    </ion-card-content>\n  </ion-card>\n\n\n  <!-- <h1>Instructions</h1>\n\n  <ion-card *ngFor=\"let instruction of this.instructions\">\n    <ion-card-header>\n      <ion-card-subtitle>Nurse:\n        <ion-item>\n          {{instruction.nurse.user.fname}} {{instruction.nurse.user.lname}}\n        </ion-item>\n\n      </ion-card-subtitle>\n      <ion-card-subtitle>Date:\n        <ion-item>\n          <ion-datetime disabled  value=\"{{instruction.created_at}}\" display-timezone=\"utc\"></ion-datetime>\n        </ion-item>\n\n      </ion-card-subtitle>\n    </ion-card-header>\n\n    <ion-card-content>\n      <ion-card-subtitle>Text:</ion-card-subtitle>\n      <p>\n        {{instruction.text}}\n      </p>\n    </ion-card-content>\n  </ion-card> -->\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_user-prescriptions-page_user-prescriptions-page_module_ts.js.map