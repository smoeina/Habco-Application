(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_doctor-patients-page_doctor-patients-page_module_ts"],{

/***/ 942:
/*!*****************************************************************************!*\
  !*** ./src/app/doctor-patients-page/doctor-patients-page-routing.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DoctorPatientsPagePageRoutingModule": () => (/* binding */ DoctorPatientsPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _doctor_patients_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./doctor-patients-page.page */ 7320);




const routes = [
    {
        path: '',
        component: _doctor_patients_page_page__WEBPACK_IMPORTED_MODULE_0__.DoctorPatientsPagePage
    }
];
let DoctorPatientsPagePageRoutingModule = class DoctorPatientsPagePageRoutingModule {
};
DoctorPatientsPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DoctorPatientsPagePageRoutingModule);



/***/ }),

/***/ 1415:
/*!*********************************************************************!*\
  !*** ./src/app/doctor-patients-page/doctor-patients-page.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DoctorPatientsPagePageModule": () => (/* binding */ DoctorPatientsPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _doctor_patients_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./doctor-patients-page-routing.module */ 942);
/* harmony import */ var _doctor_patients_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./doctor-patients-page.page */ 7320);







let DoctorPatientsPagePageModule = class DoctorPatientsPagePageModule {
};
DoctorPatientsPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _doctor_patients_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.DoctorPatientsPagePageRoutingModule
        ],
        declarations: [_doctor_patients_page_page__WEBPACK_IMPORTED_MODULE_1__.DoctorPatientsPagePage]
    })
], DoctorPatientsPagePageModule);



/***/ }),

/***/ 7320:
/*!*******************************************************************!*\
  !*** ./src/app/doctor-patients-page/doctor-patients-page.page.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DoctorPatientsPagePage": () => (/* binding */ DoctorPatientsPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_doctor_patients_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./doctor-patients-page.page.html */ 8047);
/* harmony import */ var _doctor_patients_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./doctor-patients-page.page.scss */ 8479);
/* harmony import */ var _doctor_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../doctor-service.service */ 5268);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);






let DoctorPatientsPagePage = class DoctorPatientsPagePage {
    constructor(dc, modalController) {
        this.dc = dc;
        this.modalController = modalController;
        this.myDict = { true: 'Yes', false: 'No', null: 'Not filled yet' };
    }
    ngOnInit() {
    }
};
DoctorPatientsPagePage.ctorParameters = () => [
    { type: _doctor_service_service__WEBPACK_IMPORTED_MODULE_2__.DoctorServiceService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController }
];
DoctorPatientsPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-doctor-patients-page',
        template: _raw_loader_doctor_patients_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_doctor_patients_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DoctorPatientsPagePage);



/***/ }),

/***/ 8479:
/*!*********************************************************************!*\
  !*** ./src/app/doctor-patients-page/doctor-patients-page.page.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("h1, ion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 17px;\n}\n\nh2, ion-list-header {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 13px;\n}\n\nh3 {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 10px;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 15px;\n}\n\n.profile {\n  text-align: center;\n  background-color: white;\n  margin-right: 5%;\n  margin-left: 5%;\n  margin-top: 4%;\n  margin-bottom: 4%;\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(108, 235, 58, 0.6);\n  backdrop-filter: blur(1.2px);\n  -webkit-backdrop-filter: blur(1.2px);\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  border-radius: 7%;\n}\n\nion-item {\n  border-radius: 5%;\n}\n\nion-searchbar {\n  border-radius: 20px;\n}\n\nion-list-header {\n  font-size: 15px;\n}\n\n.answer {\n  font-family: \"QanelasUltraLight\";\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRvY3Rvci1wYXRpZW50cy1wYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLHdDQUFBO0VBQ0EsZUFBQTtBQUFGOztBQUVBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBQ0E7RUFDRSx3Q0FBQTtFQUNBLGVBQUE7QUFFRjs7QUFBQTtFQUNFLGdCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQkFBQTtBQUdGOztBQURBO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUVBLG9DQUFBO0VBQ0EsZ0RBQUE7RUFDQSw0QkFBQTtFQUNBLG9DQUFBO0VBQ0EsMkNBQUE7RUFDQSxpQkFBQTtBQUdGOztBQUFBO0VBQ0UsaUJBQUE7QUFHRjs7QUFEQTtFQUNFLG1CQUFBO0FBSUY7O0FBRkE7RUFDRSxlQUFBO0FBS0Y7O0FBSEE7RUFDRSxnQ0FBQTtBQU1GIiwiZmlsZSI6ImRvY3Rvci1wYXRpZW50cy1wYWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5oMSxpb24tdGl0bGV7XHJcbiAgZm9udC1mYW1pbHk6ICdQbHVzSmFrYXJ0YS1ib2xkJywgY3Vyc2l2ZTtcclxuICBmb250LXNpemU6IDE3cHg7XHJcbn1cclxuaDIsaW9uLWxpc3QtaGVhZGVye1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG59XHJcbmgze1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxMHB4O1xyXG59XHJcbnB7XHJcbiAgY29sb3I6ICM4Njg2ODZkYztcclxuICBmb250LWZhbWlseTogJ1FhbmVsYXNVbHRyYUxpZ2h0JztcclxuICBtYXJnaW4tdG9wOiAxNXB4O1xyXG59XHJcbi5wcm9maWxle1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxuICBtYXJnaW4tdG9wOiA0JTtcclxuICBtYXJnaW4tYm90dG9tOiA0JTtcclxuXHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC42ICk7XHJcbiAgYm94LXNoYWRvdzogMCA4cHggMzJweCAwIHJnYmEoMTA4LCAyMzUsIDU4LCAwLjYpO1xyXG4gIGJhY2tkcm9wLWZpbHRlcjogYmx1ciggMS4ycHggKTtcclxuICAtd2Via2l0LWJhY2tkcm9wLWZpbHRlcjogYmx1ciggMS4ycHggKTtcclxuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKCAyNTUsIDI1NSwgMjU1LCAwLjE4ICk7XHJcbiAgYm9yZGVyLXJhZGl1czogNyU7XHJcblxyXG59XHJcbmlvbi1pdGVte1xyXG4gIGJvcmRlci1yYWRpdXM6IDUlO1xyXG59XHJcbmlvbi1zZWFyY2hiYXJ7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcclxufVxyXG5pb24tbGlzdC1oZWFkZXJ7XHJcbiAgZm9udC1zaXplOiAxNXB4O1xyXG59XHJcbi5hbnN3ZXJ7XHJcbiAgZm9udC1mYW1pbHk6ICdRYW5lbGFzVWx0cmFMaWdodCc7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 8047:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/doctor-patients-page/doctor-patients-page.page.html ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"doctor-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Patients</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content fullscreen>\n\n\n\n  <ion-list>\n\n  <div *ngFor=\"let patient of this.dc.patients_list\">\n\n    <ion-card>\n      <ion-item style=\"font-family: PlusJakarta-bold;\">\n\n        <ion-label style=\"text-align: center;font-family: PlusJakarta-bold; \">\n          <ion-avatar slot=\"start\" style=\"text-align: center;margin-left:35%;\n          margin-right:30%; margin-bottom:7px;font-family:PlusJakarta \">\n          <img src=\"https://ui-avatars.com/api/background=17D7A0&color=fff?name={{patient.user.fname}}+{{patient.user.lname}}?\">\n        </ion-avatar>\n        {{patient.user.fname}} {{patient.user.lname}}</ion-label>\n      </ion-item>\n      <ion-card-content>\n        <h2>Covid Record: <div class=\"answer\">{{myDict[patient.covid_19]}}</div></h2>\n        <h2>Cancer Record: <div class=\"answer\">{{myDict[patient.cancer]}}</div></h2>\n        <h2>Being in dangerous area Record: <div class=\"answer\">{{myDict[patient.dangerous_area]}}</div></h2>\n        <h2>Diabetes Record: <div class=\"answer\">{{myDict[patient.diabetes]}}</div></h2>\n        <h2>Immunological disease Record: <div class=\"answer\">{{myDict[patient.imuloical]}}</div></h2>\n        <h2>Living in infectious area: <div class=\"answer\">{{myDict[patient.infectious]}}</div></h2>\n        <h2>Having pet Record: <div class=\"answer\">{{myDict[patient.pet]}}</div></h2>\n        <h2>Respiratory disease Record: <div class=\"answer\">{{myDict[patient.respiratory]}}</div></h2>\n        <h2>Vascular disease Record: <div class=\"answer\">{{myDict[patient.vascular]}}</div></h2>\n\n      </ion-card-content>\n    </ion-card>\n\n\n\n\n  </div>\n\n</ion-list>\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_doctor-patients-page_doctor-patients-page_module_ts.js.map