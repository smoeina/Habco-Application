(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_admin-see-info_admin-see-info_module_ts"],{

/***/ 3598:
/*!*****************************************************************!*\
  !*** ./src/app/admin-see-info/admin-see-info-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminSeeInfoPageRoutingModule": () => (/* binding */ AdminSeeInfoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _admin_see_info_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./admin-see-info.page */ 4164);




const routes = [
    {
        path: '',
        component: _admin_see_info_page__WEBPACK_IMPORTED_MODULE_0__.AdminSeeInfoPage
    }
];
let AdminSeeInfoPageRoutingModule = class AdminSeeInfoPageRoutingModule {
};
AdminSeeInfoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AdminSeeInfoPageRoutingModule);



/***/ }),

/***/ 6913:
/*!*********************************************************!*\
  !*** ./src/app/admin-see-info/admin-see-info.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminSeeInfoPageModule": () => (/* binding */ AdminSeeInfoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _admin_see_info_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./admin-see-info-routing.module */ 3598);
/* harmony import */ var _admin_see_info_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./admin-see-info.page */ 4164);







let AdminSeeInfoPageModule = class AdminSeeInfoPageModule {
};
AdminSeeInfoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _admin_see_info_routing_module__WEBPACK_IMPORTED_MODULE_0__.AdminSeeInfoPageRoutingModule
        ],
        declarations: [_admin_see_info_page__WEBPACK_IMPORTED_MODULE_1__.AdminSeeInfoPage]
    })
], AdminSeeInfoPageModule);



/***/ }),

/***/ 4164:
/*!*******************************************************!*\
  !*** ./src/app/admin-see-info/admin-see-info.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdminSeeInfoPage": () => (/* binding */ AdminSeeInfoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_admin_see_info_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./admin-see-info.page.html */ 3665);
/* harmony import */ var _admin_see_info_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./admin-see-info.page.scss */ 5311);
/* harmony import */ var _admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../admin.service */ 457);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../error-controller.service */ 4898);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);




/* eslint-disable max-len */


/* eslint-disable @typescript-eslint/naming-convention */


let AdminSeeInfoPage = class AdminSeeInfoPage {
    constructor(alertController, http, loadingController, errorController, adminService) {
        this.alertController = alertController;
        this.http = http;
        this.loadingController = loadingController;
        this.errorController = errorController;
        this.adminService = adminService;
        this.app_token = '';
        this.doctor = false;
        this.nurse = false;
        this.pharmacist = false;
        this.document_accepted = false;
        this.document_disabled = true;
        this.cv_accepted = false;
        this.cv_disabled = true;
    }
    ngOnInit() {
        var obj = JSON.parse(localStorage.getItem('selected_user'));
        if (obj != null && localStorage.getItem('type') !== undefined) {
            this.adminService.type = localStorage.getItem('type');
            this.adminService.selected_user = obj;
        }
    }
    check_doc() {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.app_token,
            Accept: 'application/json, text/plain',
            'cache-control': 'no-cache',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token, Accept, Authorization, X-Request-With, Access-Control-Request-Method, Access-Control-Request-Headers',
            'Access-Control-Allow-Credentials': 'true',
            'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, OPTIONS, TRACE, PATCH, CONNECT'
        });
        const options = { headers };
        if (this.document_id !== null && this.document_id === 'number') {
            this.http.get('https://habco.rshayanfar.ir/habco/document/' + this.document_id, options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                this.document_accepted = resp['data']['verified'];
                this.document_disabled = false;
            })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                this.errorController.showError(error);
            }));
        }
        else {
            this.document_disabled = true;
        }
    }
    check_cv() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
                Accept: 'application/json, text/plain',
                'cache-control': 'no-cache',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token, Accept, Authorization, X-Request-With, Access-Control-Request-Method, Access-Control-Request-Headers',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, OPTIONS, TRACE, PATCH, CONNECT'
            });
            const options = { headers };
            if (this.cv_id !== null && typeof this.cv_id === 'number') {
                this.http.get('https://habco.rshayanfar.ir/habco/document/' + this.cv_id, options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    this.cv_disabled = false;
                    this.cv_accepted = resp['data']['verified'];
                })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    this.errorController.showError(error);
                }));
            }
            else {
                this.cv_disabled = true;
                yield loading.dismiss();
            }
        });
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            this.app_token = localStorage.getItem('app-token');
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
                Accept: 'application/json, text/plain',
                'cache-control': 'no-cache',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token, Accept, Authorization, X-Request-With, Access-Control-Request-Method, Access-Control-Request-Headers',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, OPTIONS, TRACE, PATCH, CONNECT'
            });
            const options = { headers };
            yield loading.dismiss();
            this.adminService.type = localStorage.getItem('type');
            this.adminService.selected_user = JSON.parse(localStorage.getItem('selected_user'));
            console.log(this.adminService.type);
            console.log(this.adminService.selected_user);
            if (this.adminService.type === 'doctor') {
                this.doctor = true;
                this.nurse = false;
                this.pharmacist = false;
                this.http.get('https://habco.rshayanfar.ir/habco/doctor/' + this.adminService.selected_user.id, options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    this.cv_id = resp['data']['cv_id'];
                    this.document_id = resp['data']['document_id'];
                    this.check_doc();
                    this.check_cv();
                })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    this.errorController.showError(error);
                }));
            }
            if (this.adminService.type === 'nurse') {
                this.nurse = true;
                this.doctor = false;
                this.pharmacist = false;
                this.http.get('https://habco.rshayanfar.ir/habco/nurse/' + this.adminService.selected_user.id, options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    this.cv_id = resp['data']['cv_id'];
                    this.document_id = resp['data']['document_id'];
                    this.check_doc();
                    this.check_cv();
                })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    this.errorController.showError(error);
                }));
            }
            console.log(this.adminService.type);
            if (this.adminService.type === 'pharmacist') {
                this.pharmacist = true;
                this.nurse = false;
                this.doctor = false;
                this.http.get('https://habco.rshayanfar.ir/habco/pharmacist/' + this.adminService.selected_user.id, options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    this.cv_id = resp['data']['cv_id'];
                    this.check_cv();
                })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    this.errorController.showError(error);
                }));
            }
        });
    }
    get_document() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (this.document_id) {
                // await loading.present();
                this.app_token = localStorage.getItem('app-token');
                const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                    Authorization: 'Bearer ' + this.app_token,
                    'Accept': 'text/html, application/xhtml+xml,application/pdf, */*',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'cache-control': 'no-cache',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token, Accept, Authorization, X-Request-With, Access-Control-Request-Method, Access-Control-Request-Headers',
                    'Access-Control-Allow-Credentials': 'true',
                    'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, OPTIONS, TRACE, PATCH, CONNECT', responseType: 'text'
                });
                var options = { headers, 'responseType': 'blob' };
                this.http.get('https://habco.rshayanfar.ir/habco/document/' + this.document_id + '/download', options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    var url = window.URL.createObjectURL(resp);
                    window.open(url);
                    // await loading.dismiss();
                })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    // await loading.dismiss();
                    console.log(error.error);
                    this.errorController.showError(error.error);
                }));
            }
            else {
                this.errorController.showErrorMessage('Document has not uploaded yet...');
            }
        });
    }
    get_cv() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (this.cv_id) {
                // await loading.present();
                this.app_token = localStorage.getItem('app-token');
                const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                    Authorization: 'Bearer ' + this.app_token,
                    'Accept': 'text/html, application/xhtml+xml,application/pdf, */*',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'cache-control': 'no-cache',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token, Accept, Authorization, X-Request-With, Access-Control-Request-Method, Access-Control-Request-Headers',
                    'Access-Control-Allow-Credentials': 'true',
                    'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, OPTIONS, TRACE, PATCH, CONNECT', responseType: 'text'
                });
                var options = { headers, 'responseType': 'blob' };
                this.http.get('https://habco.rshayanfar.ir/habco/document/' + this.cv_id + '/download', options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    var url = window.URL.createObjectURL(resp);
                    window.open(url);
                    // await loading.dismiss();
                })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    // await loading.dismiss();
                    this.errorController.showError(error.error);
                }));
            }
            else {
                this.errorController.showErrorMessage('CV has not uploaded yet...');
            }
        });
    }
    doc_toggled(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            var doc_checked = event.detail.checked;
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            console.log('doc_');
            console.log(doc_checked);
            this.app_token = localStorage.getItem('app-token');
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
                Accept: 'application/json, text/plain',
                'cache-control': 'no-cache',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token, Accept, Authorization, X-Request-With, Access-Control-Request-Method, Access-Control-Request-Headers',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, OPTIONS, TRACE, PATCH, CONNECT'
            });
            const options = { headers };
            this.http.put('https://habco.rshayanfar.ir/habco/document/' + this.document_id, { 'verified': doc_checked }, options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                yield loading.dismiss();
                this.check_doc();
            })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                yield loading.dismiss();
                this.errorController.showError(error);
            }));
        });
    }
    cv_toggled(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            var cv_checked = event.detail.checked;
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            this.app_token = localStorage.getItem('app-token');
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
                Accept: 'application/json, text/plain',
                'cache-control': 'no-cache',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token, Accept, Authorization, X-Request-With, Access-Control-Request-Method, Access-Control-Request-Headers',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, OPTIONS, TRACE, PATCH, CONNECT'
            });
            const options = { headers };
            this.http.put('https://habco.rshayanfar.ir/habco/document/' + this.cv_id, { 'verified': cv_checked }, options).toPromise().then((resp) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                yield loading.dismiss();
                this.check_cv();
            })).catch((error) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                yield loading.dismiss();
                this.errorController.showError(error);
            }));
        });
    }
};
AdminSeeInfoPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_3__.ErrorControllerService },
    { type: _admin_service__WEBPACK_IMPORTED_MODULE_2__.AdminService }
];
AdminSeeInfoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-admin-see-info',
        template: _raw_loader_admin_see_info_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_admin_see_info_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AdminSeeInfoPage);



/***/ }),

/***/ 5311:
/*!*********************************************************!*\
  !*** ./src/app/admin-see-info/admin-see-info.page.scss ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("h1 {\n  font-family: \"PlusJakarta-bold\";\n  font-size: 15px;\n  font-weight: 100;\n}\n\np {\n  font-family: \"PlusJakarta\";\n}\n\nion-button {\n  font-family: \"PlusJakarta-bold\";\n  margin-top: 5%;\n  width: 50%;\n  margin-left: 25%;\n  margin-right: 25%;\n  font-size: 12px;\n}\n\nion-label {\n  font-family: \"PlusJakarta\";\n  font-size: 13px;\n}\n\nion-card-title {\n  font-family: \"PlusJakarta-bold\";\n  font-size: 17px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkbWluLXNlZS1pbmZvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLCtCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSwwQkFBQTtBQUVGOztBQUNBO0VBQ0UsK0JBQUE7RUFDQSxjQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FBRUY7O0FBQUE7RUFDRSwwQkFBQTtFQUNBLGVBQUE7QUFHRjs7QUFEQTtFQUNFLCtCQUFBO0VBQ0EsZUFBQTtBQUlGIiwiZmlsZSI6ImFkbWluLXNlZS1pbmZvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImgxe1xyXG4gIGZvbnQtZmFtaWx5OiBcIlBsdXNKYWthcnRhLWJvbGRcIjtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDEwMDtcclxufVxyXG5we1xyXG4gIGZvbnQtZmFtaWx5OiBcIlBsdXNKYWthcnRhXCI7XHJcblxyXG59XHJcbmlvbi1idXR0b257XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIG1hcmdpbi10b3A6IDUlO1xyXG4gIHdpZHRoOiA1MCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDI1JTtcclxuICBtYXJnaW4tcmlnaHQ6IDI1JTtcclxuICBmb250LXNpemU6IDEycHg7XHJcbn1cclxuaW9uLWxhYmVse1xyXG4gIGZvbnQtZmFtaWx5OiBcIlBsdXNKYWthcnRhXCI7XHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG59XHJcbmlvbi1jYXJkLXRpdGxle1xyXG4gIGZvbnQtZmFtaWx5OiBcIlBsdXNKYWthcnRhLWJvbGRcIjtcclxuICBmb250LXNpemU6IDE3cHg7XHJcblxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 3665:
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin-see-info/admin-see-info.page.html ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"admin-home\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>{{this.adminService.type}} info</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card>\n    <ion-card-header>\n      <ion-card-subtitle></ion-card-subtitle>\n      <ion-card-title>Personal Info</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content>\n      <h1>\n        First Name:\n      </h1>\n      <p>{{this.adminService.selected_user.fname}}</p>\n\n      <h1>\n        Last Name:\n      </h1>\n      <p>{{this.adminService.selected_user.lname}}</p>\n      <h1 *ngIf=\"this.doctor\">\n        specialization:\n      </h1>\n      <p *ngIf=\"this.doctor\">{{this.adminService.selected_user.specialization}}</p>\n\n    </ion-card-content>\n  </ion-card>\n\n\n\n  <ion-card>\n\n    <ion-card-header>\n      <ion-card-subtitle></ion-card-subtitle>\n      <ion-card-title>Licenses</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content >\n      <div *ngIf=\"this.doctor || this.nurse\">\n        <h1>Document</h1>\n        <ion-item>\n         <ion-label>Accept</ion-label>\n         <ion-toggle color=\"primary\" [checked]=\"this.document_accepted\" [disabled]=\"this.document_disabled\" (ionChange)=\"doc_toggled($event)\"></ion-toggle>\n       </ion-item>\n         <ion-button (click)=\"get_document()\">Get Document</ion-button>\n      </div>\n\n      <h1>CV</h1>\n      <ion-item>\n        <ion-label>Accept</ion-label>\n        <ion-toggle color=\"primary\"[checked]=\"this.cv_accepted\" [disabled]=\"this.cv_disabled\" (ionChange)=\"cv_toggled($event)\"></ion-toggle>\n      </ion-item>\n\n       <ion-button (click)=\"get_cv()\">Get CV</ion-button>\n    </ion-card-content>\n  </ion-card>\n\n\n\n\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_admin-see-info_admin-see-info_module_ts.js.map