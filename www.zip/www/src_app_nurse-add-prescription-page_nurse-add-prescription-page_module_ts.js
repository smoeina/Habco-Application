(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_nurse-add-prescription-page_nurse-add-prescription-page_module_ts"],{

/***/ 5754:
/*!*******************************************************************************************!*\
  !*** ./src/app/nurse-add-prescription-page/nurse-add-prescription-page-routing.module.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NurseAddPrescriptionPagePageRoutingModule": () => (/* binding */ NurseAddPrescriptionPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _nurse_add_prescription_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nurse-add-prescription-page.page */ 8186);




const routes = [
    {
        path: '',
        component: _nurse_add_prescription_page_page__WEBPACK_IMPORTED_MODULE_0__.NurseAddPrescriptionPagePage
    }
];
let NurseAddPrescriptionPagePageRoutingModule = class NurseAddPrescriptionPagePageRoutingModule {
};
NurseAddPrescriptionPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NurseAddPrescriptionPagePageRoutingModule);



/***/ }),

/***/ 5079:
/*!***********************************************************************************!*\
  !*** ./src/app/nurse-add-prescription-page/nurse-add-prescription-page.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NurseAddPrescriptionPagePageModule": () => (/* binding */ NurseAddPrescriptionPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _nurse_add_prescription_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nurse-add-prescription-page-routing.module */ 5754);
/* harmony import */ var _nurse_add_prescription_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nurse-add-prescription-page.page */ 8186);







let NurseAddPrescriptionPagePageModule = class NurseAddPrescriptionPagePageModule {
};
NurseAddPrescriptionPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _nurse_add_prescription_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.NurseAddPrescriptionPagePageRoutingModule
        ],
        declarations: [_nurse_add_prescription_page_page__WEBPACK_IMPORTED_MODULE_1__.NurseAddPrescriptionPagePage]
    })
], NurseAddPrescriptionPagePageModule);



/***/ }),

/***/ 8186:
/*!*********************************************************************************!*\
  !*** ./src/app/nurse-add-prescription-page/nurse-add-prescription-page.page.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NurseAddPrescriptionPagePage": () => (/* binding */ NurseAddPrescriptionPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_nurse_add_prescription_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./nurse-add-prescription-page.page.html */ 9350);
/* harmony import */ var _nurse_add_prescription_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nurse-add-prescription-page.page.scss */ 1781);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../error-controller.service */ 4898);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _nurse_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../nurse.service */ 337);





/* eslint-disable object-shorthand */
/* eslint-disable @typescript-eslint/dot-notation */

/* eslint-disable @typescript-eslint/prefer-for-of */
/* eslint-disable @typescript-eslint/naming-convention */



let NurseAddPrescriptionPagePage = class NurseAddPrescriptionPagePage {
    constructor(doctorService, http, ErrorCont, loadingController) {
        this.doctorService = doctorService;
        this.http = http;
        this.ErrorCont = ErrorCont;
        this.loadingController = loadingController;
        this.patient_names_ids = {};
        this.app_token = '';
        this.prescription = '';
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.app_token = localStorage.getItem('app-token');
        for (let i = 0; i < this.doctorService.patients_list.length; i++) {
            this.patient_names_ids[this.doctorService.patients_list[i].user.fname.toString() + ' ' +
                this.doctorService.patients_list[i].user.lname.toString()] = this.doctorService.patients_list[i].id;
        }
    }
    // http://localhost:8000/habco/instruction/patient/26
    submit_prescription() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers: headers };
            console.log(this.selected_patient.value);
            this.http.post('https://habco.rshayanfar.ir/habco/instruction/patient' + this.selected_patient.value, { text: this.prescription_field.value }, options).toPromise().then(resp => {
                console.log(resp);
            }).catch(error => {
                this.ErrorCont.showError(error);
                loading.dismiss();
            });
        });
    }
};
NurseAddPrescriptionPagePage.ctorParameters = () => [
    { type: _nurse_service__WEBPACK_IMPORTED_MODULE_3__.NurseService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController }
];
NurseAddPrescriptionPagePage.propDecorators = {
    selected_patient: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['selected_patient',] }],
    prescription_field: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['prescription',] }]
};
NurseAddPrescriptionPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-nurse-add-prescription-page',
        template: _raw_loader_nurse_add_prescription_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_nurse_add_prescription_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], NurseAddPrescriptionPagePage);



/***/ }),

/***/ 1781:
/*!***********************************************************************************!*\
  !*** ./src/app/nurse-add-prescription-page/nurse-add-prescription-page.page.scss ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-textarea {\n  font-family: \"HelloKetta\";\n  font-size: 30px;\n}\n\nion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 16px;\n}\n\nion-card {\n  margin-top: 20%;\n  font-family: \"Gilroy\", cursive;\n}\n\nion-button {\n  margin-left: 30%;\n  margin-right: 30%;\n  width: 40%;\n  font-family: \"Gilroy-bold\", cursive;\n}\n\nion-card-subtitle {\n  font-family: \"Gilroy-bold\";\n}\n\nion-select-option {\n  font-family: \"Gilroy\";\n}\n\nion-select {\n  font-family: \"Gilroy\";\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51cnNlLWFkZC1wcmVzY3JpcHRpb24tcGFnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRSx5QkFBQTtFQUNBLGVBQUE7QUFBRjs7QUFFQTtFQUNFLHdDQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUNBO0VBQ0UsZUFBQTtFQUNBLDhCQUFBO0FBRUY7O0FBQ0E7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLG1DQUFBO0FBRUY7O0FBQ0E7RUFDRSwwQkFBQTtBQUVGOztBQUNBO0VBQ0UscUJBQUE7QUFFRjs7QUFDQTtFQUNFLHFCQUFBO0VBQ0EsZUFBQTtBQUVGIiwiZmlsZSI6Im51cnNlLWFkZC1wcmVzY3JpcHRpb24tcGFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW9uLXRleHRhcmVhe1xyXG4gIGZvbnQtZmFtaWx5OiAnSGVsbG9LZXR0YSc7XHJcbiAgZm9udC1zaXplOjMwcHg7XHJcbn1cclxuaW9uLXRpdGxle1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG59XHJcbmlvbi1jYXJke1xyXG4gIG1hcmdpbi10b3A6IDIwJTtcclxuICBmb250LWZhbWlseTogJ0dpbHJveScsIGN1cnNpdmU7XHJcblxyXG59XHJcbmlvbi1idXR0b257XHJcbiAgbWFyZ2luLWxlZnQ6IDMwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDMwJTtcclxuICB3aWR0aDogNDAlO1xyXG4gIGZvbnQtZmFtaWx5OiAnR2lscm95LWJvbGQnLCBjdXJzaXZlO1xyXG5cclxufVxyXG5pb24tY2FyZC1zdWJ0aXRsZXtcclxuICBmb250LWZhbWlseTogJ0dpbHJveS1ib2xkJztcclxuXHJcbn1cclxuaW9uLXNlbGVjdC1vcHRpb257XHJcbiAgZm9udC1mYW1pbHk6ICdHaWxyb3knO1xyXG5cclxufVxyXG5pb24tc2VsZWN0e1xyXG4gIGZvbnQtZmFtaWx5OiAnR2lscm95JztcclxuICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 9350:
/*!*************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/nurse-add-prescription-page/nurse-add-prescription-page.page.html ***!
  \*************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"nurse-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Add new prescription</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n\n  <div *ngFor=\"let item of patient_names_ids | keyvalue\">\n\n\n  </div>\n  <ion-card>\n    <ion-card-header>\n      <ion-card-subtitle>Patient:\n        <ion-item>\n          <ion-select #selected_patient  multiple=\"false\" placeholder=\"Select Patient\"\n          *ngFor=\"let item of patient_names_ids | keyvalue\" >\n            <ion-select-option value=\"{{item.value}}\">{{item.key}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-card-subtitle>\n    </ion-card-header>\n\n    <ion-card-content>\n      <ion-card-subtitle>Text:</ion-card-subtitle>\n      <ion-textarea #prescription placeholder=\"      You should care yourself...\">\n      </ion-textarea>\n      <ion-button (click)=\"submit_prescription()\">\n        <ion-icon slot=\"icon-only\" name=\"add-circle\"></ion-icon>\n        Submit\n      </ion-button>\n    </ion-card-content>\n  </ion-card>\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_nurse-add-prescription-page_nurse-add-prescription-page_module_ts.js.map