(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_drugstore-edit-info_drugstore-edit-info_module_ts"],{

/***/ 2178:
/*!***************************************************************************!*\
  !*** ./src/app/drugstore-edit-info/drugstore-edit-info-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DrugstoreEditInfoPageRoutingModule": () => (/* binding */ DrugstoreEditInfoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _drugstore_edit_info_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./drugstore-edit-info.page */ 6954);




const routes = [
    {
        path: '',
        component: _drugstore_edit_info_page__WEBPACK_IMPORTED_MODULE_0__.DrugstoreEditInfoPage
    }
];
let DrugstoreEditInfoPageRoutingModule = class DrugstoreEditInfoPageRoutingModule {
};
DrugstoreEditInfoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DrugstoreEditInfoPageRoutingModule);



/***/ }),

/***/ 7002:
/*!*******************************************************************!*\
  !*** ./src/app/drugstore-edit-info/drugstore-edit-info.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DrugstoreEditInfoPageModule": () => (/* binding */ DrugstoreEditInfoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _drugstore_edit_info_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./drugstore-edit-info-routing.module */ 2178);
/* harmony import */ var _drugstore_edit_info_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./drugstore-edit-info.page */ 6954);







let DrugstoreEditInfoPageModule = class DrugstoreEditInfoPageModule {
};
DrugstoreEditInfoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _drugstore_edit_info_routing_module__WEBPACK_IMPORTED_MODULE_0__.DrugstoreEditInfoPageRoutingModule
        ],
        declarations: [_drugstore_edit_info_page__WEBPACK_IMPORTED_MODULE_1__.DrugstoreEditInfoPage]
    })
], DrugstoreEditInfoPageModule);



/***/ }),

/***/ 6954:
/*!*****************************************************************!*\
  !*** ./src/app/drugstore-edit-info/drugstore-edit-info.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DrugstoreEditInfoPage": () => (/* binding */ DrugstoreEditInfoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_drugstore_edit_info_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./drugstore-edit-info.page.html */ 8629);
/* harmony import */ var _drugstore_edit_info_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./drugstore-edit-info.page.scss */ 5232);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../error-controller.service */ 4898);



/* eslint-disable @typescript-eslint/naming-convention */






let DrugstoreEditInfoPage = class DrugstoreEditInfoPage {
    constructor(http, error_controller, alertController, router, loadingController) {
        this.http = http;
        this.error_controller = error_controller;
        this.alertController = alertController;
        this.router = router;
        this.loadingController = loadingController;
        this.app_token = '';
        this.cv_uploaded = false;
        this.certification_uploaded = false;
    }
    ngOnInit() {
        this.app_token = localStorage.getItem('app-token');
    }
    cv_file_changed(fileChangeEvent) {
        this.cv_file = fileChangeEvent.target.files[0];
        console.log('File Loaded');
        const fileReader = new FileReader();
        fileReader.readAsDataURL(this.cv_file);
        fileReader.onload = () => {
            this.cv_base64 = fileReader.result;
        };
        this.cv_uploaded = true;
    }
    changeFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    }
    showAlert(header, subHeader, message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header,
                cssClass: 'my-custom-class',
                subHeader,
                message,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    upload_clicked() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            if (this.terms.checked === false) {
                this.error_controller.showError('Please Accept our terms...');
                return 0;
            }
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers };
            if (this.cv_uploaded) {
                console.log(this.cv_base64);
                console.log(this.cv_base64.split(',')[1]);
                const data_to_send = { file: this.cv_base64.split(',')[1], file_type: 'application/pdf', type: 'cv' };
                console.log(data_to_send);
                this.http.post('https://habco.rshayanfar.ir/habco/document', { file: this.cv_base64.split(',')[1], file_type: 'application/pdf', type: 'cv' }, options).toPromise().then(resp => {
                    console.log(resp);
                }).catch(error => {
                    console.log('Error');
                    loading.dismiss();
                    this.error_controller.showError(error);
                });
                this.http.patch('https://habco.rshayanfar.ir/habco/user', { fname: this.fname.value,
                    lname: this.lname.value }, options).toPromise().then(resp => {
                    console.log(resp);
                }).catch(error => {
                    loading.dismiss();
                    this.error_controller.showError(error);
                });
                //console.log(this.proficiency.value);
                // this.http.put('https://habco.rshayanfar.ir/habco/nurse',{specialization:this.proficiency.value}
                // ,options).toPromise().then(
                //   resp =>{
                //     console.log(resp);
                //     loading.dismiss();
                //     this.showAlert('Done','Upload Information Success','Wait till our supervisors check your info.');
                //     this.router.navigate(['nurse-home-page']);
                //   }
                // ).catch(error => {
                //   loading.dismiss();
                //   this.error_controller.showError(error);
                // });
            }
            else {
                loading.dismiss();
                this.error_controller.showErrorMessage('Please Upload your CV and Certification file...');
            }
            loading.dismiss();
        });
    }
};
DrugstoreEditInfoPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController }
];
DrugstoreEditInfoPage.propDecorators = {
    cv: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['cv',] }],
    fname: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['fname',] }],
    lname: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['lname',] }],
    terms: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['terms',] }]
};
DrugstoreEditInfoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-drugstore-edit-info',
        template: _raw_loader_drugstore_edit_info_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_drugstore_edit_info_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DrugstoreEditInfoPage);



/***/ }),

/***/ 5232:
/*!*******************************************************************!*\
  !*** ./src/app/drugstore-edit-info/drugstore-edit-info.page.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-title {\n  font-family: PlusJakarta-bold;\n  font-size: 15px;\n}\n\nion-input {\n  font-family: \"QanelasUltraLight\";\n  font-size: 15px;\n}\n\n.inputs_devision {\n  margin-top: 10%;\n}\n\nion-item {\n  font-family: PlusJakarta-bold;\n  --border-width: 2px;\n  --border-radius: 8px;\n  width: 80%;\n  position: relative;\n  margin-left: 10%;\n  margin-right: 10%;\n  margin-top: 4px;\n}\n\n.Quest {\n  font-size: 11px;\n  margin-bottom: 5%;\n}\n\nion-button {\n  font-family: \"PlusJakarta-bold\";\n  position: relative;\n  margin-left: 25%;\n  width: 50%;\n  height: 50px;\n  margin-right: 25%;\n  margin-top: 5%;\n  margin-bottom: 15%;\n  border-radius: 15%;\n}\n\n.accept_terms {\n  font-family: QanelasUltraLight;\n  font-size: 16px;\n  margin-left: 5%;\n}\n\np {\n  display: inline-block;\n  margin-left: 4px;\n}\n\nion-checkbox {\n  margin-top: 4px;\n}\n\nion-label {\n  font-size: 10px;\n  font-family: QanelasUltraLight;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRydWdzdG9yZS1lZGl0LWluZm8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsNkJBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQ0FBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7QUFDRjs7QUFDQTtFQUNFLDZCQUFBO0VBQ0EsbUJBQUE7RUFDQSxvQkFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FBRUY7O0FBQUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUFHRjs7QUFEQTtFQUNFLCtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7RUFDRCxZQUFBO0VBQ0MsaUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQUlGOztBQUZBO0VBQ0UsOEJBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQUtGOztBQUhBO0VBQ0UscUJBQUE7RUFDQSxnQkFBQTtBQU1GOztBQUpBO0VBQ0UsZUFBQTtBQU9GOztBQUxBO0VBQ0UsZUFBQTtFQUNBLDhCQUFBO0FBUUYiLCJmaWxlIjoiZHJ1Z3N0b3JlLWVkaXQtaW5mby5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdGl0bGV7XHJcbiAgZm9udC1mYW1pbHk6IFBsdXNKYWthcnRhLWJvbGQ7XHJcbiAgZm9udC1zaXplOiAxNXB4O1xyXG5cclxufVxyXG5pb24taW5wdXR7XHJcbiAgZm9udC1mYW1pbHk6IFwiUWFuZWxhc1VsdHJhTGlnaHRcIjtcclxuICBmb250LXNpemU6IDE1cHg7XHJcblxyXG59XHJcbi5pbnB1dHNfZGV2aXNpb257XHJcbiAgbWFyZ2luLXRvcDogMTAlO1xyXG59XHJcbmlvbi1pdGVte1xyXG4gIGZvbnQtZmFtaWx5OlBsdXNKYWthcnRhLWJvbGQ7XHJcbiAgLS1ib3JkZXItd2lkdGg6IDJweDtcclxuICAtLWJvcmRlci1yYWRpdXM6IDhweDtcclxuICB3aWR0aDogODAlO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBtYXJnaW4tbGVmdDogMTAlO1xyXG4gIG1hcmdpbi1yaWdodDogMTAlO1xyXG4gIG1hcmdpbi10b3A6IDRweDtcclxufVxyXG4uUXVlc3R7XHJcbiAgZm9udC1zaXplOiAxMXB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDUlO1xyXG59XHJcbmlvbi1idXR0b257XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGEtYm9sZFwiO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBtYXJnaW4tbGVmdDogMjUlO1xyXG4gIHdpZHRoOiA1MCU7XHJcblx0aGVpZ2h0OiA1MHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMjUlO1xyXG4gIG1hcmdpbi10b3A6IDUlO1xyXG4gIG1hcmdpbi1ib3R0b206IDE1JTtcclxuICBib3JkZXItcmFkaXVzOiAxNSU7XHJcbn1cclxuLmFjY2VwdF90ZXJtc3tcclxuICBmb250LWZhbWlseTpRYW5lbGFzVWx0cmFMaWdodCA7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxufVxyXG5we1xyXG4gIGRpc3BsYXk6aW5saW5lLWJsb2NrO1xyXG4gIG1hcmdpbi1sZWZ0OiA0cHg7XHJcbn1cclxuaW9uLWNoZWNrYm94e1xyXG4gIG1hcmdpbi10b3A6IDRweDtcclxufVxyXG5pb24tbGFiZWx7XHJcbiAgZm9udC1zaXplOiAxMHB4O1xyXG4gIGZvbnQtZmFtaWx5OlFhbmVsYXNVbHRyYUxpZ2h0O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 8629:
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/drugstore-edit-info/drugstore-edit-info.page.html ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"drugstore-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Personal Information</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"inputs_devision\">\n    <ion-title class=\"Quest\">Please complete your personal information.</ion-title>\n<ion-item>\n    <ion-label position='floating'>\n      <ion-icon name=\"person\"></ion-icon>\n      First Name</ion-label>\n    <ion-input type=\"text\" placeholder=\"John\" #fname></ion-input>\n</ion-item>\n<ion-item>\n  <ion-label position='floating'>\n    <ion-icon name=\"person\"></ion-icon>\n    Last Name</ion-label>\n  <ion-input type=\"text\" placeholder=\"Hopkins\"  #lname></ion-input>\n</ion-item>\n\n<ion-item>\n  <ion-label position='floating'>\n    <ion-icon name=\"library\"></ion-icon>\n    Upload Pharmacy license</ion-label>\n  <ion-input accept=\"application/pdf\" type=\"file\" placeholder=\"CV\" #cv (change)=\"cv_file_changed($event)\"></ion-input>\n</ion-item>\n<div class=\"accept_terms\">\n  <ion-checkbox color=\"primary\" #terms></ion-checkbox>\n  <p>I agree to the terms of service</p>\n\n  <span style=\"color: rgb(221, 16, 16);visibility: hidden;\">Please accept terms of the service</span>\n\n</div>\n<div style=\"margin-top: 10%;\">\n  <ion-button (click)=\"upload_clicked()\">\n    Upload\n  </ion-button>\n</div>\n\n  </div>\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_drugstore-edit-info_drugstore-edit-info_module_ts.js.map