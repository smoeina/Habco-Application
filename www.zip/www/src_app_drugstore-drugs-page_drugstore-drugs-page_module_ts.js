(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_drugstore-drugs-page_drugstore-drugs-page_module_ts"],{

/***/ 3049:
/*!*****************************************************************************!*\
  !*** ./src/app/drugstore-drugs-page/drugstore-drugs-page-routing.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DrugstoreDrugsPagePageRoutingModule": () => (/* binding */ DrugstoreDrugsPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _drugstore_drugs_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./drugstore-drugs-page.page */ 4231);




const routes = [
    {
        path: '',
        component: _drugstore_drugs_page_page__WEBPACK_IMPORTED_MODULE_0__.DrugstoreDrugsPagePage
    }
];
let DrugstoreDrugsPagePageRoutingModule = class DrugstoreDrugsPagePageRoutingModule {
};
DrugstoreDrugsPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DrugstoreDrugsPagePageRoutingModule);



/***/ }),

/***/ 2354:
/*!*********************************************************************!*\
  !*** ./src/app/drugstore-drugs-page/drugstore-drugs-page.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DrugstoreDrugsPagePageModule": () => (/* binding */ DrugstoreDrugsPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _drugstore_drugs_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./drugstore-drugs-page-routing.module */ 3049);
/* harmony import */ var _drugstore_drugs_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./drugstore-drugs-page.page */ 4231);







let DrugstoreDrugsPagePageModule = class DrugstoreDrugsPagePageModule {
};
DrugstoreDrugsPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _drugstore_drugs_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.DrugstoreDrugsPagePageRoutingModule
        ],
        declarations: [_drugstore_drugs_page_page__WEBPACK_IMPORTED_MODULE_1__.DrugstoreDrugsPagePage]
    })
], DrugstoreDrugsPagePageModule);



/***/ }),

/***/ 4231:
/*!*******************************************************************!*\
  !*** ./src/app/drugstore-drugs-page/drugstore-drugs-page.page.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DrugstoreDrugsPagePage": () => (/* binding */ DrugstoreDrugsPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_drugstore_drugs_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./drugstore-drugs-page.page.html */ 6052);
/* harmony import */ var _drugstore_drugs_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./drugstore-drugs-page.page.scss */ 9598);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _error_controller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../error-controller.service */ 4898);



/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/dot-notation */
/* eslint-disable @typescript-eslint/naming-convention */






let DrugstoreDrugsPagePage = class DrugstoreDrugsPagePage {
    constructor(alertController, http, loadingController, errorController, router) {
        this.alertController = alertController;
        this.http = http;
        this.loadingController = loadingController;
        this.errorController = errorController;
        this.router = router;
        this.app_token = '';
    }
    ngOnInit() {
    }
    get_id() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.app_token,
            });
            const options = { headers };
            // http://localhost:8000/habco/pharmacist/{id}/drug
            this.http.get('https://habco.rshayanfar.ir/habco/user', options).toPromise().then(resp => {
                this.my_id = resp['data'].id;
                console.log(this.my_id);
                this.http.get('https://habco.rshayanfar.ir/habco/pharmacist/' + this.my_id + '/drug', options).toPromise().then(response => {
                    console.log(response['data']);
                    this.drugs = response['data'];
                    loading.dismiss();
                }).catch(error => {
                    loading.dismiss();
                    this.errorController.showError(error);
                });
            }).catch(error => {
                loading.dismiss();
                this.errorController.showError(error);
            });
        });
    }
    ionViewWillEnter() {
        this.app_token = localStorage.getItem('app-token');
        this.get_id();
    }
    showPrompt() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            const prompt = this.alertController.create({
                header: 'Add a Drug',
                message: 'Here You Can Add A Drug to Database',
                inputs: [
                    {
                        name: 'Name of Drug',
                        placeholder: 'Acetaminophen',
                    }, {
                        name: 'Amount',
                        placeholder: '0',
                        type: 'number',
                        min: 1
                    },
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        handler: data => {
                            console.log('Cancel clicked');
                        }
                    },
                    {
                        text: 'Add',
                        handler: (data) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                            yield loading.present();
                            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                                'Content-Type': 'application/json',
                                Authorization: 'Bearer ' + this.app_token,
                            });
                            const options = { headers };
                            console.log(data);
                            this.http.post('https://habco.rshayanfar.ir/habco/drug', { 'name': data['Name of Drug'], count: +data['Amount'] }, options).toPromise().then(response => {
                                console.log(response['data']);
                                this.drugs = response['data'];
                                this.http.get('https://habco.rshayanfar.ir/habco/pharmacist/' + this.my_id + '/drug', options).toPromise().then(response => {
                                    loading.dismiss();
                                    console.log(response['data']);
                                    this.drugs = response['data'];
                                }).catch(error => {
                                    loading.dismiss();
                                    this.errorController.showError(error);
                                });
                            }).catch(error => {
                                loading.dismiss();
                                this.errorController.showError(error);
                            });
                        })
                    }
                ]
            });
            (yield prompt).present();
        });
    }
    edit_amount(drug) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            const prompt = this.alertController.create({
                header: 'Edit ' + drug.name,
                message: 'Here You Can Edit Amount of Drug',
                inputs: [{
                        name: 'Amount',
                        placeholder: '0',
                        type: 'number',
                        min: 0
                    },
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        handler: data => {
                            console.log('Cancel clicked');
                        }
                    },
                    {
                        text: 'Edit',
                        handler: (data) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                            yield loading.present();
                            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpHeaders({
                                'Content-Type': 'application/json',
                                Authorization: 'Bearer ' + this.app_token,
                            });
                            const options = { headers };
                            console.log(drug);
                            this.http.put('https://habco.rshayanfar.ir/habco/drug/' + drug.id, { count: +data['Amount'] }, options).toPromise().then(response => {
                                console.log(response['data']);
                                this.drugs = response['data'];
                                this.http.get('https://habco.rshayanfar.ir/habco/pharmacist/' + this.my_id + '/drug', options).toPromise().then(resp => {
                                    console.log(resp['data']);
                                    this.drugs = resp['data'];
                                    loading.dismiss();
                                }).catch(error => {
                                    loading.dismiss();
                                    this.errorController.showError(error);
                                });
                            }).catch(error => {
                                loading.dismiss();
                                this.errorController.showError(error);
                            });
                        })
                    }
                ]
            });
            (yield prompt).present();
        });
    }
};
DrugstoreDrugsPagePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _error_controller_service__WEBPACK_IMPORTED_MODULE_2__.ErrorControllerService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
DrugstoreDrugsPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-drugstore-drugs-page',
        template: _raw_loader_drugstore_drugs_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_drugstore_drugs_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DrugstoreDrugsPagePage);



/***/ }),

/***/ 9598:
/*!*********************************************************************!*\
  !*** ./src/app/drugstore-drugs-page/drugstore-drugs-page.page.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("h1 {\n  font-family: \"PlusJakarta-bold\";\n  font-size: 15px;\n  text-align: center;\n  font-weight: 100;\n}\n\nh2 {\n  font-family: \"PlusJakarta\";\n  font-size: 13px;\n  text-align: center;\n  font-weight: 100;\n}\n\np {\n  color: #868686dc;\n  font-family: \"QanelasUltraLight\";\n  margin-top: 4%;\n  text-align: center;\n}\n\nion-content {\n  --ion-background-color: linear-gradient(to top, #34e67e, #abf853 80%);\n}\n\n.welcome-border {\n  background-color: white;\n  margin-right: 10%;\n  margin-left: 10%;\n  padding-bottom: 10%;\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  margin-top: 10%;\n}\n\n.profile-status-messsage {\n  text-align: left;\n  margin-left: 10%;\n  font-size: 15px;\n}\n\n.profile-status {\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  margin-left: 10%;\n  margin-right: 10%;\n  margin-top: 5%;\n}\n\n.item {\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  height: 40%;\n  width: 40%;\n  margin: 8px 5px 0px 3px;\n  padding-bottom: 6%;\n}\n\n.flex-container {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  height: 40%;\n  margin-left: 5%;\n  margin-right: 5%;\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n\n.item-title {\n  margin-top: 3px;\n}\n\n.sec_flex-container {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  margin-left: 10%;\n  margin-right: 10%;\n  margin-top: 10px;\n}\n\n.image {\n  height: 40px;\n  width: 40px;\n  margin-bottom: 4px;\n  text-align: center;\n  margin-left: 27%;\n}\n\n.logout {\n  background: rgba(255, 255, 255, 0.6);\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\n  backdrop-filter: blur(2.5px);\n  -webkit-backdrop-filter: blur(2.5px);\n  border-radius: 10px;\n  border: 1px solid rgba(255, 255, 255, 0.18);\n  height: 30%;\n  width: 40%;\n  margin: 5px 0px 0px 3px;\n  padding-bottom: 2%;\n}\n\nion-toolbar {\n  --background: #abf853;\n}\n\nion-title {\n  font-family: AquireBold;\n  font-size: 25px;\n}\n\nion-button {\n  width: 40%;\n  margin-left: 30%;\n  margin-right: 30%;\n  margin-top: 10%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRydWdzdG9yZS1kcnVncy1wYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLCtCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFBRjs7QUFFQTtFQUNFLDBCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFFRjs7QUFFQTtFQUNFLHFFQUFBO0FBQ0Y7O0FBQ0E7RUFDRSx1QkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLG9DQUFBO0VBQ0YsZ0RBQUE7RUFDQSw0QkFBQTtFQUNBLG9DQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQ0FBQTtFQUNBLGVBQUE7QUFFQTs7QUFBQTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBR0Y7O0FBREE7RUFDRSxvQ0FBQTtFQUNBLGdEQUFBO0VBQ0EsNEJBQUE7RUFDQSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQUlGOztBQURBO0VBQ0Usb0NBQUE7RUFDQSxnREFBQTtFQUNBLDRCQUFBO0VBQ0Esb0NBQUE7RUFDQSxtQkFBQTtFQUNBLDJDQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0FBSUY7O0FBRkE7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQUtGOztBQUhBO0VBQ0UsZUFBQTtBQU1GOztBQUhBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQU1GOztBQUhBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFNRjs7QUFKQTtFQUNFLG9DQUFBO0VBQ0EsZ0RBQUE7RUFDQSw0QkFBQTtFQUNBLG9DQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQ0FBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQU9GOztBQUxBO0VBQ0UscUJBQUE7QUFRRjs7QUFMQTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtBQVFGOztBQU5BO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FBU0YiLCJmaWxlIjoiZHJ1Z3N0b3JlLWRydWdzLXBhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmgxe1xyXG4gIGZvbnQtZmFtaWx5OiBcIlBsdXNKYWthcnRhLWJvbGRcIjtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtd2VpZ2h0OiAxMDA7XHJcbn1cclxuaDJ7XHJcbiAgZm9udC1mYW1pbHk6IFwiUGx1c0pha2FydGFcIjtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtd2VpZ2h0OiAxMDA7XHJcbn1cclxucHtcclxuICBjb2xvcjogIzg2ODY4NmRjO1xyXG4gIGZvbnQtZmFtaWx5OiAnUWFuZWxhc1VsdHJhTGlnaHQnO1xyXG4gIG1hcmdpbi10b3A6IDQlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbn1cclxuXHJcbmlvbi1jb250ZW50e1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCh0byB0b3AsICMzNGU2N2UsICNhYmY4NTMgODAlKTtcclxufVxyXG4ud2VsY29tZS1ib3JkZXJ7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICBwYWRkaW5nLWJvdHRvbTogMTAlO1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuNiApO1xyXG5ib3gtc2hhZG93OiAwIDhweCAzMnB4IDAgcmdiYSggMzEsIDM4LCAxMzUsIDAuMzcgKTtcclxuYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4td2Via2l0LWJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuYm9yZGVyLXJhZGl1czogMTBweDtcclxuYm9yZGVyOiAxcHggc29saWQgcmdiYSggMjU1LCAyNTUsIDI1NSwgMC4xOCApO1xyXG5tYXJnaW4tdG9wOiAxMCU7XHJcbn1cclxuLnByb2ZpbGUtc3RhdHVzLW1lc3NzYWdle1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbn1cclxuLnByb2ZpbGUtc3RhdHVze1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuNiApO1xyXG4gIGJveC1zaGFkb3c6IDAgOHB4IDMycHggMCByZ2JhKCAzMSwgMzgsIDEzNSwgMC4zNyApO1xyXG4gIGJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuICAtd2Via2l0LWJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuMTggKTtcclxuICBtYXJnaW4tbGVmdDogMTAlO1xyXG4gIG1hcmdpbi1yaWdodDogMTAlO1xyXG4gIG1hcmdpbi10b3A6IDUlO1xyXG4gIH1cclxuXHJcbi5pdGVte1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuNiApO1xyXG4gIGJveC1zaGFkb3c6IDAgOHB4IDMycHggMCByZ2JhKCAzMSwgMzgsIDEzNSwgMC4zNyApO1xyXG4gIGJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuICAtd2Via2l0LWJhY2tkcm9wLWZpbHRlcjogYmx1ciggMi41cHggKTtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoIDI1NSwgMjU1LCAyNTUsIDAuMTggKTtcclxuICBoZWlnaHQ6IDQwJTtcclxuICB3aWR0aDogNDAlO1xyXG4gIG1hcmdpbjo4cHggNXB4IDBweCAzcHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDYlO1xyXG59XHJcbi5mbGV4LWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmbGV4LXdyYXA6d3JhcDtcclxuICBoZWlnaHQ6IDQwJTtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcbi5pdGVtLXRpdGxle1xyXG4gIG1hcmdpbi10b3A6IDNweDtcclxuXHJcbn1cclxuLnNlY19mbGV4LWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmbGV4LXdyYXA6d3JhcDtcclxuICBtYXJnaW4tbGVmdDogMTAlO1xyXG4gIG1hcmdpbi1yaWdodDogMTAlO1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcbi5pbWFnZXtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW4tbGVmdDogMjclO1xyXG59XHJcbi5sb2dvdXR7XHJcbiAgYmFja2dyb3VuZDogcmdiYSggMjU1LCAyNTUsIDI1NSwgMC42ICk7XHJcbiAgYm94LXNoYWRvdzogMCA4cHggMzJweCAwIHJnYmEoIDMxLCAzOCwgMTM1LCAwLjM3ICk7XHJcbiAgYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4gIC13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOiBibHVyKCAyLjVweCApO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSggMjU1LCAyNTUsIDI1NSwgMC4xOCApO1xyXG4gIGhlaWdodDogMzAlO1xyXG4gIHdpZHRoOiA0MCU7XHJcbiAgbWFyZ2luOjVweCAwcHggMHB4IDNweDtcclxuICBwYWRkaW5nLWJvdHRvbTogMiU7XHJcbn1cclxuaW9uLXRvb2xiYXIge1xyXG4gIC0tYmFja2dyb3VuZDogI2FiZjg1MztcclxuXHJcbn1cclxuaW9uLXRpdGxle1xyXG4gIGZvbnQtZmFtaWx5OkFxdWlyZUJvbGQgO1xyXG4gIGZvbnQtc2l6ZTogMjVweDtcclxufVxyXG5pb24tYnV0dG9ue1xyXG4gIHdpZHRoOiA0MCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDMwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDMwJTtcclxuICBtYXJnaW4tdG9wOiAxMCU7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 6052:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/drugstore-drugs-page/drugstore-drugs-page.page.html ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"drugstore-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>drugstore-drugs-page</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"drugs\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"6\">\n          <h1 style=\"font-size:14px\">Name</h1>\n        </ion-col>\n        <ion-col>\n\n        </ion-col>\n        <ion-col>\n          <h1 style=\"font-size:14px\">#Amount</h1>\n        </ion-col>\n      </ion-row>\n      <ion-row *ngFor=\"let drug of this.drugs\" (click)=\"edit_amount(drug)\">\n        <ion-col size=\"6\">\n          <h1>{{drug.name}}</h1>\n        </ion-col>\n        <ion-col>\n\n        </ion-col>\n        <ion-col>\n          <h1>{{drug.count}}</h1>\n\n        </ion-col>\n      </ion-row>\n\n    </ion-grid>\n\n  <ion-button expand=\"block\" fill=\"solid\" shape=\"round\" (click)=\"showPrompt()\">\n    Add A Drug\n  </ion-button>\n  </div>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_drugstore-drugs-page_drugstore-drugs-page_module_ts.js.map