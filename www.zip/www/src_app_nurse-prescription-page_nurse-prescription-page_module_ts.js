(self["webpackChunkHabco"] = self["webpackChunkHabco"] || []).push([["src_app_nurse-prescription-page_nurse-prescription-page_module_ts"],{

/***/ 9935:
/*!***********************************************************************************!*\
  !*** ./src/app/nurse-prescription-page/nurse-prescription-page-routing.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NursePrescriptionPagePageRoutingModule": () => (/* binding */ NursePrescriptionPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _nurse_prescription_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nurse-prescription-page.page */ 221);




const routes = [
    {
        path: '',
        component: _nurse_prescription_page_page__WEBPACK_IMPORTED_MODULE_0__.NursePrescriptionPagePage
    }
];
let NursePrescriptionPagePageRoutingModule = class NursePrescriptionPagePageRoutingModule {
};
NursePrescriptionPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NursePrescriptionPagePageRoutingModule);



/***/ }),

/***/ 6009:
/*!***************************************************************************!*\
  !*** ./src/app/nurse-prescription-page/nurse-prescription-page.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NursePrescriptionPagePageModule": () => (/* binding */ NursePrescriptionPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _nurse_prescription_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nurse-prescription-page-routing.module */ 9935);
/* harmony import */ var _nurse_prescription_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nurse-prescription-page.page */ 221);







let NursePrescriptionPagePageModule = class NursePrescriptionPagePageModule {
};
NursePrescriptionPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _nurse_prescription_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.NursePrescriptionPagePageRoutingModule
        ],
        declarations: [_nurse_prescription_page_page__WEBPACK_IMPORTED_MODULE_1__.NursePrescriptionPagePage]
    })
], NursePrescriptionPagePageModule);



/***/ }),

/***/ 221:
/*!*************************************************************************!*\
  !*** ./src/app/nurse-prescription-page/nurse-prescription-page.page.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NursePrescriptionPagePage": () => (/* binding */ NursePrescriptionPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_nurse_prescription_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./nurse-prescription-page.page.html */ 6704);
/* harmony import */ var _nurse_prescription_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nurse-prescription-page.page.scss */ 7188);
/* harmony import */ var _nurse_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../nurse.service */ 337);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);





/* eslint-disable @typescript-eslint/naming-convention */


let NursePrescriptionPagePage = class NursePrescriptionPagePage {
    constructor(router, http, doctor_service) {
        this.router = router;
        this.http = http;
        this.doctor_service = doctor_service;
        this.app_token = '';
    }
    ngOnInit() {
        this.app_token = localStorage.getItem('app-token');
    }
    get_prescriptions() {
    }
    add_pres_click() {
        this.router.navigate(['doctor-add-prescription']);
    }
};
NursePrescriptionPagePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _nurse_service__WEBPACK_IMPORTED_MODULE_2__.NurseService }
];
NursePrescriptionPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-nurse-prescription-page',
        template: _raw_loader_nurse_prescription_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_nurse_prescription_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], NursePrescriptionPagePage);



/***/ }),

/***/ 7188:
/*!***************************************************************************!*\
  !*** ./src/app/nurse-prescription-page/nurse-prescription-page.page.scss ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("p {\n  font-family: \"HelloKetta\";\n  font-size: 30px;\n}\n\nion-title {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 16px;\n}\n\nion-card {\n  margin-top: 10%;\n  font-family: \"Gilroy\", cursive;\n}\n\nion-button {\n  margin-left: 30%;\n  margin-right: 30%;\n  width: 40%;\n  font-family: \"Gilroy-bold\", cursive;\n}\n\nion-card-subtitle {\n  font-family: \"Gilroy-bold\";\n}\n\nion-select-option {\n  font-family: \"Gilroy\";\n}\n\nion-item {\n  font-family: \"PlusJakarta-bold\", cursive;\n  font-size: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51cnNlLXByZXNjcmlwdGlvbi1wYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLHlCQUFBO0VBQ0EsZUFBQTtBQUFGOztBQUVBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxlQUFBO0VBQ0EsOEJBQUE7QUFFRjs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0VBQ0EsbUNBQUE7QUFFRjs7QUFDQTtFQUNFLDBCQUFBO0FBRUY7O0FBQ0E7RUFDRSxxQkFBQTtBQUVGOztBQUNBO0VBQ0Usd0NBQUE7RUFDQSxlQUFBO0FBRUYiLCJmaWxlIjoibnVyc2UtcHJlc2NyaXB0aW9uLXBhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbnB7XHJcbiAgZm9udC1mYW1pbHk6ICdIZWxsb0tldHRhJztcclxuICBmb250LXNpemU6MzBweDtcclxufVxyXG5pb24tdGl0bGV7XHJcbiAgZm9udC1mYW1pbHk6ICdQbHVzSmFrYXJ0YS1ib2xkJywgY3Vyc2l2ZTtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuaW9uLWNhcmR7XHJcbiAgbWFyZ2luLXRvcDogMTAlO1xyXG4gIGZvbnQtZmFtaWx5OiAnR2lscm95JywgY3Vyc2l2ZTtcclxuXHJcbn1cclxuaW9uLWJ1dHRvbntcclxuICBtYXJnaW4tbGVmdDogMzAlO1xyXG4gIG1hcmdpbi1yaWdodDogMzAlO1xyXG4gIHdpZHRoOiA0MCU7XHJcbiAgZm9udC1mYW1pbHk6ICdHaWxyb3ktYm9sZCcsIGN1cnNpdmU7XHJcblxyXG59XHJcbmlvbi1jYXJkLXN1YnRpdGxle1xyXG4gIGZvbnQtZmFtaWx5OiAnR2lscm95LWJvbGQnO1xyXG5cclxufVxyXG5pb24tc2VsZWN0LW9wdGlvbntcclxuICBmb250LWZhbWlseTogJ0dpbHJveSc7XHJcblxyXG59XHJcbmlvbi1pdGVte1xyXG4gIGZvbnQtZmFtaWx5OiAnUGx1c0pha2FydGEtYm9sZCcsIGN1cnNpdmU7XHJcbiAgZm9udC1zaXplOiAxMHB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 6704:
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/nurse-prescription-page/nurse-prescription-page.page.html ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"nurse-home-page\">Back</ion-back-button>\n    </ion-buttons>\n    <ion-title>Presciptions</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-button (click)=\"add_pres_click()\">Add new</ion-button>\n  <ion-card *ngFor=\"let prescription of this.doctor_service.prescriptions_list\">\n    <ion-card-header>\n      <ion-card-subtitle>Patient:\n        <ion-item>\n          {{prescription.patient.user.fname}} {{prescription.patient.user.lname}}\n        </ion-item>\n\n      </ion-card-subtitle>\n      <ion-card-subtitle>Date:\n        <ion-item>\n          <ion-datetime disabled  value=\"{{prescription.created_at}}\" display-timezone=\"utc\"></ion-datetime>\n        </ion-item>\n\n      </ion-card-subtitle>\n    </ion-card-header>\n\n    <ion-card-content>\n      <ion-card-subtitle>Text:</ion-card-subtitle>\n      <p>\n        {{prescription.text}}\n      </p>\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_nurse-prescription-page_nurse-prescription-page_module_ts.js.map